package executeTS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import calculationMethods.CalculateBestCaseSave;
import changeRequest.ReadFailCR;
import changeRequest.ReadFailJavaTs;
import changeRequest.ReadFailSize;
import changeRequest.ReadFailTest;
import changeRequest.ReadMatrix;
import exeRecord.ExeRecord;
//import manageRuls.OneToOneRule;
//import manageRuls.ReadinAllRules;
import testSuites.TestSuite;

public class ExecuteTestSuites 
{
	private double all_TSnumber = 0;
	private double all_failNumber=0;
	private double all_ExeTime = 0;
	
	private double executed_TSnumber = 0;
	private double executed_failNumber=0;
	private double executed_ExeTime = 0;

	private TestSuite lastTs = new TestSuite(0);
	private TestSuite currentTs;
	
    private ReadMatrix matrix = new ReadMatrix();
	
	private ReadFailTest readFailTest = new ReadFailTest();
	private List<Integer> failTest = readFailTest.getCR();  // total 287
	
	private ReadFailCR readFailCR = new ReadFailCR();
	private List<Integer> failCR = readFailCR.getFailCR();  // commits that has failed test suites (total 1324)
	
	private ReadFailJavaTs javaTs = new ReadFailJavaTs(); // now has been updated to all
	
	
	//for all the fail test suites rules --> single rule
//	private OneToOneRule singleRule = new OneToOneRule();	
	private Map<String, Integer> singleItemMap = new HashMap<String, Integer>(); //map for 1 itemset: TestId
	
//	private ReadinAllRules readRule = new ReadinAllRules();
	
	private ReadFailSize readSize = new ReadFailSize();
	private Map<Integer, boolean[]> isSizeFail = readSize.readSize();
	
	private double ftotal;
	private double ftotal_exeTime;
	
	private double allFailExeTime;
	
	Map<Integer, Double> map = new HashMap<Integer, Double>();
	
//	private int 
//	
	private ExeRecord exeRec = new ExeRecord();	
//	private CombineCommits combineCommits;
	private PrioritizeCommits prioritizeCommits;
//	private StoreCommits storeCommits;
	
	/*
	 * normalize the timeline
	 */
	private Timestamp startTime;
	private Timestamp endTime;
	private double lastTsExeTime;
//	private double totalTime;
	private boolean isFirstTs;
	private double totalTimeLine;
	private StoreCommits storeCommits;
	private SimulateCommitsExecution simulateCommitExe;
	private boolean isIntra;
	
	public ExecuteTestSuites(ExeRecord exeRec, int pqSize, String selectedStage, double trainingSize, boolean isIntra) 
	{
		super();
		prioritizeCommits = new PrioritizeCommits();
//		combineCommits = new CombineCommits(pqSize, selectedStage, trainingSize);
		this.exeRec = exeRec;
		this.storeCommits = new StoreCommits(selectedStage); 
		this.isFirstTs = true;
		this.isIntra = isIntra;
		
	}


	public void executeTestSuites(ResultSet rs, int failWindow, int executionWindow,String failmmhh, String executemmhh, String selectedStage,int distinctTsNum, String alwaysExecutedStage, int numOfProcessor, double rate) throws ParseException
	{	
		matrix.getMatrix();
		javaTs.getCR();
		
	    
//		for(Integer i: isSizeFail.keySet())
//		{
//			boolean[] isFailSize = isSizeFail.get(i);
//			System.out.println(i+"," + isFailSize[0] + "," + isFailSize[1] + "," + isFailSize[2]);
//		}
		
//		singleRule.get11Rules();
//		this.singleItemMap = singleRule.getItemset();
//		for(String s: singleItemMap.keySet())
//		{
//			System.out.println(s +": " + singleItemMap.get(s));;
//		}
		
//		readRule.getRules();
		
		boolean isFirst = true;
		
		//for updating the exeRecord
//		exeRec.initializeRecord(distinctTsNum);
		
		Timestamp launchTime;
		int currentId;
		String stage;
		String status;
		long executionTime;
		int changeRequest;
		String size;
		String testName;
		String language;
		int shardNumber;
		int runNumber;
		
		GetStartTime failTime = new GetStartTime();
		Timestamp failStartTime;
		
		GetStartTime exeTime = new GetStartTime();
		Timestamp executeStartTime;
		
		try {
				while(rs.next())
				{	
//					System.out.println("aaaa");
					testName = rs.getString("TestSuite");
					currentId= rs.getInt("T_number");
					launchTime= rs.getTimestamp("LaunchTime");				
					stage = rs.getString("Stage");
					status = rs.getString("Status_test");
					shardNumber = rs.getInt("Shared_number");
					runNumber = rs.getInt("Run_number");
					executionTime = rs.getInt("ExecutionTime");
					changeRequest = rs.getInt("ChangeRequest");
					size = rs.getString("size");
					language = rs.getString("Language_test");
				
					//update currentTs
					currentTs = new TestSuite( currentId, testName, launchTime, stage, status, executionTime, changeRequest, size, language, shardNumber,runNumber);	
//					currentTs = new TestSuite( currentId, launchTime, stage, status, executionTime, changeRequest, size, language);	
					
					//for initialization
					if(isFirst == true)
					{				
						isFirst = false;	
						lastTs = currentTs;
					}
					else
					{		
						/*
						 * Set the failStartTime
						 */
//						failStartTime=failTime.window(lastTs.getLast_launchTime(), failWindow, failmmhh);  //this is for minutes
						
						/*
						 * Set the executeStartTime
						 */		
//						executeStartTime=exeTime.window(lastTs.getLast_launchTime(), executionWindow, executemmhh); // this is for hours
						
						//coalesce the shards
						if(lastTs.getTsId()==currentId && lastTs.getLast_launchTime().equals(currentTs.getLast_launchTime()) )
						{	
							currentTs = lastTs;
							// update the execution time of the certain testSuite
							long tempExeTime = lastTs.getLast_executionTime() + executionTime;
							currentTs.setLast_executionTime(tempExeTime);			
							if(status.equals("FAILED"))
							{
								currentTs.setLast_failTime(currentTs.getLast_launchTime());
								currentTs.setLast_status("FAILED");
								currentTs.setFail(true);
							}
							lastTs = currentTs;
							continue;
						}	
						else
						{
							/*
							 * update the number of TestSuite and the execution time of TestSuite by calling the methods in UpdateTs
							 */		
//							combineCommits.selectTs(matrix, failTest, failCR, javaTs, lastTs, selectedStage, exeRec, alwaysExecutedStage, isSizeFail, failWindow, executionWindow, prioritizeCommits);
							
							/*
							 * Store Commits first
							 */
							this.storeCommits.storeAllCommits(matrix, failTest, failCR, javaTs, lastTs, selectedStage, exeRec, alwaysExecutedStage, isSizeFail, failWindow, executionWindow);
//							this.storeCommits.storeAllCommits2(matrix, failTest, failCR, javaTs, lastTs, selectedStage, exeRec, alwaysExecutedStage, isSizeFail, failWindow, executionWindow);
							// get the start Time of the first ts
							if(isFirstTs)
							{
//								System.out.println("last date:"+currentTs.getLast_launchTime());
								startTime = currentTs.getLast_launchTime();
								isFirstTs = false;
							}
							
							
							
							//update
							lastTs = currentTs;
						}
						
//						/*
//						 * Prioritize commits in a queue
//						 */
//						if( CountCommits.getCommitsNum() > executionWindow)
//						{
//							proceee;
//							
//						}
							
						
					}					
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		/*
//		 * update the number of TestSuite and the execution time of TestSuite
//		 */		
//		//update
////		lastTs = currentTs;		
//		combineCommits.selectTs(matrix, failTest, failCR, javaTs, lastTs, selectedStage, exeRec, alwaysExecutedStage, isSizeFail, failWindow, executionWindow, prioritizeCommits);
//		combineCommits.processLastCommit( selectedStage, exeRec, failWindow, executionWindow, prioritizeCommits);		
//		this.all_TSnumber = combineCommits.getAccumulateAll().getCountNumber();
//		this.all_failNumber=combineCommits.getAccumulateAll().getCountFailNumber();
//		this.all_ExeTime = combineCommits.getAccumulateAll().getCountExeTime();
//		this.allFailExeTime = combineCommits.getAccumulateAll().getAllFailExeTime();
//		
//		this.executed_TSnumber = combineCommits.getAccumulateExe().getCountNumber();
//		this.executed_failNumber=combineCommits.getAccumulateExe().getCountFailNumber();
//		this.executed_ExeTime = combineCommits.getAccumulateExe().getCountExeTime();	
//		
//		this.ftotal = combineCommits.getAccumulateExe().getFtotal();
//		this.ftotal_exeTime = combineCommits.getAccumulateExe().getFtotal_exeTime();
//		this.map = combineCommits.getAccumulateExe().getMap();
		
		
//		this.storeCommits.storeAllCommits2(matrix, failTest, failCR, javaTs, lastTs, selectedStage, exeRec, alwaysExecutedStage, isSizeFail, failWindow, executionWindow);
//		this.storeCommits.percentTime();
		/*
		 * newly updated for simulate the real time execution 
		 */
		//add the last test suites
		
//		System.out.println("last date:"+lastTs.getLast_launchTime());
		this.storeCommits.storeAllCommits(matrix, failTest, failCR, javaTs, lastTs, selectedStage, exeRec, alwaysExecutedStage, isSizeFail, failWindow, executionWindow);
		this.storeCommits.storeLastCommit();//add the last commit
//		this.storeCommits.avgCommitDuration();
		
//		System.out.println("allCommitDur: "+this.storeCommits.getAllCommitsDuration());
//		System.out.println("avgCommitDur: "+this.storeCommits.getAvgCommitDuration());
		
//		/*
//		 * (1) first version: normalize the timeline
//		 */
//		this.endTime = lastTs.getLast_launchTime(); // get the end time of the lastTs
//		this.lastTsExeTime = lastTs.getLast_executionTime();
////		System.out.println(startTime + ";" + endTime + ";" + lastTsExeTime);
//		this.totalTimeLine = endTime.getTime() - startTime.getTime() + this.lastTsExeTime ; // millisecond
		
		/*
		 * (2) second version: normalize the timeline --: add in the shift arrival time
		 */
		
//		System.out.println("old start time: "+ startTime );
		this.startTime = this.storeCommits.getPq().peek().commitArrivalTime();	
//		System.out.println("new start time: "+ startTime);
		this.endTime = lastTs.getLast_launchTime(); // get the end time of the lastTs
		this.lastTsExeTime = lastTs.getLast_executionTime();
//		System.out.println("endTime: "+ this.endTime);
//		System.out.println(startTime + ";" + endTime + ";" + lastTsExeTime);
		this.totalTimeLine = endTime.getTime() - startTime.getTime() + lastTsExeTime; // millisecond
		
//		System.out.println();
		
		
//		
//		
		/*
		 * process the commits
		 */
		
		if(selectedStage.equals("pres"))
			totalTimeLine = (double)1906241540.00;
		else 
			totalTimeLine = (double)4192794408.00;
		
//		totalTimeLine = this.storeCommits.getAllCommitsDuration();
		
		System.out.println("get all time: "+ totalTimeLine);
		
		this.simulateCommitExe = new SimulateCommitsExecution(this.storeCommits, this.totalTimeLine,  this.isIntra);
//		this.simulateCommitExe.setConcurrent();
		//prioritize
		this.simulateCommitExe.simulateProcess(prioritizeCommits, exeRec, failWindow, executionWindow, numOfProcessor, failTest, javaTs, isSizeFail, rate);
		
		// system the % of time with queue size
//		this.simulateCommitExe.simulateProcess();
		
		
		
//		System.out.println("exeCommit" + this.simulateCommitExe.getNumOfCommitExe());
//		System.out.println(this.totalTimeLine + ";" + this.lastTsExeTime);
//		
//		System.out.println(this.simulateCommitExe.getQueue().size());
		
//		System.out.println("current Time" + simulateCommitExe.getCurrentTime());
		
		
		this.all_TSnumber = storeCommits.getAccumulateAll().getCountNumber();
		this.all_failNumber = storeCommits.getAccumulateAll().getCountFailNumber();
		this.all_ExeTime = storeCommits.getAccumulateAll().getCountExeTime();
		this.allFailExeTime = storeCommits.getAccumulateAll().getAllFailExeTime();
		
		this.executed_TSnumber = simulateCommitExe.getAccumulateExe().getCountNumber();
		this.executed_failNumber=simulateCommitExe.getAccumulateExe().getCountFailNumber();
		this.executed_ExeTime = simulateCommitExe.getAccumulateExe().getCountExeTime();	
//		
		this.ftotal = simulateCommitExe.getAccumulateExe().getFtotal();
		this.ftotal_exeTime = simulateCommitExe.getAccumulateExe().getFtotal_exeTime();
		this.map = simulateCommitExe.getAccumulateExe().getMap();
		
		
		
		
		
		
		
	}

	
	

	public double getAll_TSnumber() {
		return all_TSnumber;
	}

	public void setAll_TSnumber(double all_TSnumber) {
		this.all_TSnumber = all_TSnumber;
	}

	public double getAll_failNumber() {
		return all_failNumber;
	}

	public void setAll_failNumber(double all_failNumber) {
		this.all_failNumber = all_failNumber;
	}

	public double getAll_ExeTime() {
		return all_ExeTime;
	}

	public void setAll_ExeTime(long all_ExeTime) {
		this.all_ExeTime = all_ExeTime;
	}

	public double getExecuted_TSnumber() {
		return executed_TSnumber;
	}

	public void setExecuted_TSnumber(double executed_TSnumber) {
		this.executed_TSnumber = executed_TSnumber;
	}

	public double getExecuted_failNumber() {
		return executed_failNumber;
	}

	public void setExecuted_failNumber(double executed_failNumber) {
		this.executed_failNumber = executed_failNumber;
	}

	public double getExecuted_ExeTime() {
		return executed_ExeTime;
	}

	public void setExecuted_ExeTime(long executed_ExeTime) {
		this.executed_ExeTime = executed_ExeTime;
	}

	public TestSuite getLastTs() {
		return lastTs;
	}

	public void setLastTs(TestSuite lastTs) {
		this.lastTs = lastTs;
	}

	public TestSuite getCurrentTs() {
		return currentTs;
	}

	public void setCurrentTs(TestSuite currentTs) {
		this.currentTs = currentTs;
	}


	public ExeRecord getExeRec() {
		return exeRec;
	}


	public void setExeRec(ExeRecord exeRec) {
		this.exeRec = exeRec;
	}


//	public CombineCommits getSelectTests() {
//		return combineCommits;
//	}
//
//
//	public void setSelectTests(CombineCommits selectTests) {
//		this.combineCommits = selectTests;
//	}


	public double getFtotal() {
		return ftotal;
	}


	public void setFtotal(double ftotal) {
		this.ftotal = ftotal;
	}


	public double getFtotal_exeTime() {
		return ftotal_exeTime;
	}


	public void setFtotal_exeTime(double ftotal_exeTime) {
		this.ftotal_exeTime = ftotal_exeTime;
	}


	public double getAllFailExeTime() {
		return allFailExeTime;
	}


	public void setAllFailExeTime(double allFailExeTime) {
		this.allFailExeTime = allFailExeTime;
	}


	public Map<Integer, Double> getMap() {
		return map;
	}


	public void setMap(Map<Integer, Double> map) {
		this.map = map;
	}


//	public CombineCommits getCombineCommits() {
//		return combineCommits;
//	}
//
//
//	public void setCombineCommits(CombineCommits combineCommits) {
//		this.combineCommits = combineCommits;
//	}


	public SimulateCommitsExecution getSimulateCommitExe() {
		return simulateCommitExe;
	}


	public void setSimulateCommitExe(SimulateCommitsExecution simulateCommitExe) {
		this.simulateCommitExe = simulateCommitExe;
	}


	public double getTotalTimeLine() {
		return totalTimeLine;
	}


	public void setTotalTimeLine(double totalTimeLine) {
		this.totalTimeLine = totalTimeLine;
	}
	
	
		
}
