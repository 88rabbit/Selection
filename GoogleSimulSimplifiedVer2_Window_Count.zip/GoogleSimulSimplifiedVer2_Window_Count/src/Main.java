import java.sql.SQLException;

import parsingCommandLine.Cli;
import simulate.Simulation;


public class Main 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{	
		//adding options for command lines
		/*
		 * -a,--failureWindow <arg>        set the failureWindow(integers)
			 -b,--executionWindow <arg>      set the executionWindow(integers)
			 -c,--failmmhh <arg>             set the minutes or hours for failure
			                                 window('minutes' or 'hours')
			 -d,--executemmhh <arg>          set the minutes or hours for execution
			                                 window('minutes' or 'hours')
			 -e,--alwaySelectedStage <arg>   set the stage('pres' or 'post' or '') in
			                                 which the tests will always execute.
			 -h,--help                       show help
			 -s,--selectedStage <arg>        set the selected stage('pres' or 'post'
			                                 or 'presAndPost')
		 */
				
		Cli cli = new Cli(args);
		cli.parse();
		
		String[] newString = cli.getArgs();
		
		//setting the sql
//		private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData ORDER BY LaunchTime, T_number, Shared_number";
		/*
		 * Most recently used
		 */
		String sql = "SELECT ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number,  TestId FROM AllData WHERE LaunchTime <'2014-01-16' ORDER BY LaunchTime, T_number, Shared_number";
		
//		String sql = "SELECT ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number,  TestId FROM AllData ORDER BY LaunchTime, T_number, Shared_number";
//		private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData Where T_Number = '3430' ORDER BY LaunchTime, T_number, Shared_number";
		/*
		 * Commit level
		 */
//		String sql = "SELECT ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number,  TestId FROM AllData WHERE LaunchTime <'2014-01-16' ORDER BY ChangeRequest, LaunchTime, T_number, Shared_number";
		
		int distinctTsNum = 5556;
		
		String alwaysExecutedStage = newString[0];
		
		int failWindow=Integer.parseInt(newString[1]);
		int executionWindow=Integer.parseInt(newString[2]);
		
		// setting the followings, Strings should be "minutes" or "hours"
		String failmmhh= newString[3];
		String executemmhh = newString[4];
		
		// setting the phase of testSuites
		String selectedStage = newString[5];	
		
		double deltaExe =Double.parseDouble( newString[6]);
		double deltaFail= Double.parseDouble(newString[7]);
		
		Simulation simulation = new Simulation();
	
		simulation.simulate(sql, failWindow, executionWindow, failmmhh, executemmhh, selectedStage, distinctTsNum, alwaysExecutedStage, deltaExe, deltaFail);		
	}
}
						
