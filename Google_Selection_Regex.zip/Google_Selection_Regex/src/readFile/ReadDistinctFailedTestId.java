package readFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Set;

public class ReadDistinctFailedTestId 
{
	
	private int total = 0;
	
	public Set<Integer> ReadInDistinctFailedTestId(String selectPhase)
	{
		Set<Integer> failedIds = new HashSet<Integer>();
		try
		{
			FileReader fs = selectPhase.equals("post")? new FileReader("../data/PostFailTestId.txt") : new FileReader("../data/PresFailTestId.txt");
			    
			BufferedReader br = new BufferedReader(fs);
			
			String testInfo = br.readLine();
			int testId = 0;
			while(testInfo!=null &&!testInfo.isEmpty())
			{		
				total ++;
				//parse file contents
				testId = Integer.parseInt(testInfo);
				
				failedIds.add(testId);
							
				testInfo = br.readLine();			
			
			}
			System.out.println("total number of distinct fail test suite is: " + total);
		}
		catch(Exception e)
		{
			System.out.print(e.toString());
		}
		
		return failedIds;
	}

}
