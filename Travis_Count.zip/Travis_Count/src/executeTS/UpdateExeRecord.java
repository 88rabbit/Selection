package executeTS;

//import testSuites.TestSuite_Google;
import testSuites.TestSuite_Travis;
//import exeRecord.ExeRecord_Google;
import exeRecord.ExeRecord_Travis;

public class UpdateExeRecord 
{
	private Accumulation accumulateExe;
	
	public void updateDetails_Travis(ExeRecord_Travis exeRec, TestSuite_Travis currentTs, Accumulation accumulateExe, 
			 boolean isExe)
	{
		if(isExe)
		{
			exeRec.updateTsRecord(currentTs);
			currentTs.setExecuted(true);
			
			//counting
			accumulateExe.counting_Travis(currentTs);		
			this.accumulateExe = accumulateExe;
		}
		else
		{
			exeRec.updateGrow(currentTs);
		}
	}

	
	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}
	
}
