package changeRequest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadFailJavaTs 
{
	private List<Integer> smallJava = new ArrayList<Integer>();
	private List<Integer> mediumJava = new ArrayList<Integer>();
	private List<Integer> largeJava = new ArrayList<Integer>();
	
	private Map<Integer, String> failTestLanguage = new HashMap<Integer, String>();
		
	public void getCR()
	{
		
	try
	{

//		FileReader fs = new FileReader("../data/failJavaTs.txt");
//		FileReader fs = new FileReader("../data/allTsFailTs.txt");
		FileReader fs = new FileReader("../data/allFailTsSizeLan.txt");

		BufferedReader br = new BufferedReader(fs);
		
		String testInfo = br.readLine();
	
		while(testInfo!=null &&!testInfo.isEmpty())
		{		
			//parse file contents
			String[] eachLine = testInfo.split(",");
			
			if(eachLine[1].equals("SMALL"))
				smallJava.add(Integer.parseInt(eachLine[0]));
			else if(eachLine[1].equals("MEDIUM"))
				mediumJava.add(Integer.parseInt(eachLine[0]));
			else if(eachLine[1].equals("LARGE"))
				largeJava.add(Integer.parseInt(eachLine[0]));
			
			String language = eachLine[2];
			failTestLanguage.put(Integer.parseInt(eachLine[0]), language);
						
			testInfo = br.readLine();			
		
		}
//		System.out.println("No." + total);	
//		System.out.println(c + "records have been inserted");
	}
	catch(Exception e)
	{
		System.out.print(e.toString());
	}
	}
	
	//this method is to record:
	/*
	 * tsId:
	 * 		int[0]: pass number in a commit
	 * 		int[1]: fail number in a commit
	 * 		
	 */
	public Map<Integer, int[]> getMap()
	{
		Map<Integer, int[]> map= new HashMap<Integer, int[]>();
		
		
		for(Integer i: smallJava)
		{
			int[] s = new int[3];  //last used for store small: 1, medum 2, large 3
			s[2] = 1;
			map.put(i, s);
//			System.out.println(s[1]);
		}
			
		for(Integer i: mediumJava)
		{
			int[] s = new int[3];
			s[2] = 2;
			map.put(i, s);
//			System.out.println(s[1]);
		}
			
		for(Integer i: largeJava)
		{
			int[] s = new int[3];
			s[2] = 3;
			map.put(i, s);
//			System.out.println(s[1]);
		}
		
		
		return map;
	}

	public List<Integer> getSmallJava() {
		return smallJava;
	}

	public void setSmallJava(List<Integer> smallJava) {
		this.smallJava = smallJava;
	}

	public List<Integer> getMediumJava() {
		return mediumJava;
	}

	public void setMediumJava(List<Integer> mediumJava) {
		this.mediumJava = mediumJava;
	}

	public List<Integer> getLargeJava() {
		return largeJava;
	}

	public void setLargeJava(List<Integer> largeJava) {
		this.largeJava = largeJava;
	}

	public Map<Integer, String> getFailTestLanguage() {
		return failTestLanguage;
	}

	public void setFailTestLanguage(Map<Integer, String> failTestLanguage) {
		this.failTestLanguage = failTestLanguage;
	}


}
