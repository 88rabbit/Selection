1. This project reads data from a dataset. If you want to run this project, you need first setup a database, insert data into the database, and update the data retrieving information in the corresponding project.

2. Steps to run the project.
   1) Download this project to your local machine.
   2) Update related database retrieving information.
   3) Build paths for the external libraries. (Check the Google_Selection_Regex/lib directory).
   4) Run Google_Selection_Regex/Script/run.sh file in the terminal.

 




