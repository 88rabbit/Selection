//package globalValues;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//public class PredictionSet 
//{
//	public static Set<Integer> set328 = new HashSet<Integer>();
//	public static Set<Integer> set3166 = new HashSet<Integer>();
//	public static Set<Integer> set3500 = new HashSet<Integer>();
//	
//	public static Map<Integer, Integer> circle1 = new HashMap<Integer, Integer>();  // implies each other
//	public static Map<Integer, Integer> circle2 = new HashMap<Integer, Integer>();
//	
//	public PredictionSet()
//	{
//		// for java
//		this.set328.add(102);		
//		this.set328.add(496);		
//		this.set328.add(503);		
//		this.set328.add(644);		
//		this.set328.add(528);
//		
//		//add all the other test suites
//		this.set328.add(3166);	
//		this.set328.add(306);	
//		this.set328.add(226);
//		this.set328.add(864);
//		this.set328.add(4930);	
//		this.set328.add(190);
//		this.set328.add(487);
//		this.set328.add(4904);
//		
//		
//		
//		
//		//for 3166
//		this.set3166.add(2949);	
//		this.set3166.add(976);	
//		this.set3166.add(4930);	
//		
//		//for 3500
//		this.set3500.add(2057);
//		
//		
//		//for circle 1 --> in order: increasing exe time
//		/*
//		 *  294	 	    383234.34
//			290	Large	493363.44
//			279	Large	533354.7
//			278	Large	619028.4
//			276	Large	1087265.4
//
//		 */
//		circle1.put(294,0);
//		circle1.put(290,1);
//		circle1.put(279,2);
//		circle1.put(278,3);
//		circle1.put(276,4);
//		
//		
//		//for circle2--> in order: increasing exe time
//		/*
//		 *  1102	Medium	1280.6685
//			1093	Large	38670.535
//			4406	Large	58628.945
//			1116	Small	76582.98
//		 * 
//		 */
//		circle2.put(1102,0);
//		circle2.put(1093,1);
//		circle2.put(4406,2);
//		circle2.put(1116,3);
//	}
//
//}
