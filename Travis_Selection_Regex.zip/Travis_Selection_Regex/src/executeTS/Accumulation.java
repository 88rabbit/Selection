package executeTS;

import java.math.BigDecimal;

import testSuites.TestSuite_Travis;

public class Accumulation 
{
	private double countNumber=0;
	private long countExeTime=0;
	private double countTsDuration_Travis=0;
	private double failErrorNumber = 0;
	private double errorNumber = 0;
	private double FailNumber=0;
	
	private String[] status;
	private double[] pf_transition;
	private double[] pe_transition;
	private double[] pfe_transition;
	
	private double totalTests = 3372093.0;
	private static double countTests = 0;
	
	public Accumulation(int distinctTsNum) 
	{
		super();
		//For calculation
		status = new String[distinctTsNum];
		pf_transition = new double[distinctTsNum];
		pe_transition = new double[distinctTsNum];
		pfe_transition = new double[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
			status[i] = "N";
			pf_transition[i] = 0;
			pe_transition[i] = 0;
			pfe_transition[i] = 0;
		}
	}
	
	public void counting_Travis_All(TestSuite_Travis ts)
	{
		countNumber++;
		countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();	
		
//		System.out.println(ts.getTs_state());
//		if(ts.getTs_state().equals("failed"))
//			FailNumber++;
//		if(ts.getTs_state().equals("errored"))
//			errorNumber ++;
//		if(ts.getTs_state().equals("failed and errored") )
//			failErrorNumber ++;
		countTests ++;
		if(ts.isFail_Ts())
		{
			FailNumber++;
//			System.out.println(ts.getTsId() + "," + (double)countTests*100/totalTests);
		}
		else if(ts.isError_Ts())
		{
			errorNumber ++;
//			System.out.println(ts.getTsId() + "," + (double)countTests*100/totalTests);
		}
		else if(ts.isFailError_Ts())
		{
			failErrorNumber ++;
//			System.out.println(ts.getTsId() + "," + (double)countTests*100/totalTests);
		}
		
		//calculate all the pf_transition/pe_transition/pef_transition number 
				if(this.status[ts.getTsId()].equals("passed") )  // if previous is passed and current is failed ==> transition PF
				{
					if(ts.isFail_Ts())
					{
						pf_transition[ts.getTsId()] ++;
//						System.out.println(ts.getTsId() + ", "+ ts.getTs_state() + ", " + pf_transition[ts.getTsId()] );
					}
					else if(ts.isError_Ts())
					{
						pe_transition[ts.getTsId()] ++;
//						System.out.println(ts.getTsId() + ", "+ ts.getTs_state() + ", " + pe_transition[ts.getTsId()] );
					}
					else if(ts.isFailError_Ts())
						pfe_transition[ts.getTsId()] ++;
				}
				this.status[ts.getTsId()] = ts.getTs_state();	
				
				
				
	}
	
	public void counting_Travis_Exe(Boolean isMoving, TestSuite_Travis ts)
	{
		countNumber++;
		countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();	
	
		
		if(ts.isFail_Ts())
		{
			FailNumber++;
//			if(isMoving)
//				System.out.println(ts.getTsId() +","+ (double)countTests*100/totalTests);
		}
		else if(ts.isError_Ts())
		{
			errorNumber ++;
//			if(isMoving)
//				System.out.println(ts.getTsId() + "," + (double)countTests*100/totalTests);
		}
		else if(ts.isFailError_Ts())
		{
			failErrorNumber ++;
//			if(isMoving)
//				System.out.println(ts.getTsId() + "," + (double)countTests*100/totalTests);
		}
		
		
		//calculate all the pf_transition/pe_transition/pef_transition number 
				if(this.status[ts.getTsId()].equals("passed") )  // if previous is passed and current is failed ==> transition PF
				{
					if(ts.isFail_Ts())
					{
						pf_transition[ts.getTsId()] ++;
//						System.out.println(ts.getTsId() + ", "+ ts.getTs_state() + ", " + pf_transition[ts.getTsId()] );
					}
					else if(ts.isError_Ts())
					{
						pe_transition[ts.getTsId()] ++;
//						System.out.println(ts.getTsId() + ", "+ ts.getTs_state() + ", " + pe_transition[ts.getTsId()] );
					}
					else if(ts.isFailError_Ts())
						pfe_transition[ts.getTsId()] ++;
				}
				this.status[ts.getTsId()] = ts.getTs_state();		
	}


	public double getCountNumber() {
		return countNumber;
	}


	public void setCountNumber(double countNumber) {
		this.countNumber = countNumber;
	}


	public long getCountExeTime() {
		return countExeTime;
	}


	public void setCountExeTime(long countExeTime) {
		this.countExeTime = countExeTime;
	}


	public double getCountTsDuration_Travis() {
		return countTsDuration_Travis;
	}


	public void setCountTsDuration_Travis(double countTsDuration_Travis) {
		this.countTsDuration_Travis = countTsDuration_Travis;
	}


	public double getFailErrorNumber() {
		return failErrorNumber;
	}


	public void setFailErrorNumber(double failErrorNumber) {
		this.failErrorNumber = failErrorNumber;
	}


	public double getErrorNumber() {
		return errorNumber;
	}


	public void setErrorNumber(double errorNumber) {
		this.errorNumber = errorNumber;
	}


	public double getFailNumber() {
		return FailNumber;
	}


	public void setFailNumber(double failNumber) {
		FailNumber = failNumber;
	}
	
	public String[] getStatus() {
		return status;
	}

	public void setStatus(int id, String status) {
		this.status[id] = status;
//		System.out.println(status[1]);
	}

	public double[] getPf_transition() {
		return pf_transition;
	}

	public void setPf_transition(double[] pf_transition) {
		this.pf_transition = pf_transition;
	}

	public double[] getPe_transition() {
		return pe_transition;
	}

	public void setPe_transition(double[] pe_transition) {
		this.pe_transition = pe_transition;
	}

	public double[] getPfe_transition() {
		return pfe_transition;
	}

	public void setPfe_transition(double[] pfe_transition) {
		this.pfe_transition = pfe_transition;
	}

	public double getTotalTests() {
		return totalTests;
	}

	public void setTotalTests(double totalTests) {
		this.totalTests = totalTests;
	}

	public double getCountTests() {
		return countTests;
	}

	public void setCountTests(double countTests) {
		this.countTests = countTests;
	}
	

	
}

//public class Accumulation 
//{
//	private double countNumber=0;
//	private double countFailNumber=0;
//	private long countExeTime=0;
//	private double countTsDuration_Travis=0;
//	
//	/*
//	 * For Travis
//	 */
//	public void counting_Travis(TestSuite_Travis ts)
//	{
//		
////		countNumber++;
////		countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();	
//		
//		/*
//		 * This time we only consider failed test suite, but not considering "errored"
//		 */
//		
//		/*
//		 * This time we only consider failed test suite, but not considering "errored"
//		 */
//		
//		if(ts.getTs_state().equals("errored"))
//		{
////			System.out.println("a");
//		}
//		else
//		{
//			countNumber++;
//			countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();	
////			countExeTime_Travis = countExeTime_Travis.add(new BigDecimal(ts.getTs_duration()));
////			System.out.println(countExeTime_Travis);
////			System.out.println(countTsDuration_Travis+";"+ ts.getTs_duration());		
//		}
//		
//		
//		
////		if(ts.isFail_Ts() == true)
//		if(ts.getTs_state().equals("failed and errored") ||ts.getTs_state().equals("failed"))
//		{
//			countFailNumber++;
//		}
//	}
//	
//
//	public double getCountNumber() {
//		return countNumber;
//	}
//
//	public void setCountNumber(double countNumber) {
//		this.countNumber = countNumber;
//	}
//
//	public long getCountExeTime() {
//		return countExeTime;
//	}
//
//	public void setCountExeTime(long countExeTime) {
//		this.countExeTime = countExeTime;
//	}
//
//	public double getCountFailNumber() {
//		return countFailNumber;
//	}
//
//	public void setCountFailNumber(double countFailNumber) {
//		this.countFailNumber = countFailNumber;
//	}
//
//	public double getCountTsDuration_Travis() {
//		return countTsDuration_Travis;
//	}
//
//	public void setCountTsDuration_Travis(double countTsDuration_Travis) {
//		this.countTsDuration_Travis = countTsDuration_Travis;
//	}
//	
//	
//}
