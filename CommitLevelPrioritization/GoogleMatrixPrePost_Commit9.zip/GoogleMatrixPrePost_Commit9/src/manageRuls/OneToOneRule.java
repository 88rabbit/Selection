//package manageRuls;
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//public class OneToOneRule 
//{
////	private Map<String,Integer> itemset = new HashMap<String, Integer>(); // for a items 189=F 15   store it as key: 189=F 15; value: 189
//	private Map<String, Integer> itemset = new HashMap<String, Integer>(); // contains all single itemsets
//	private Map<Integer, String> itemsetS = new HashMap<Integer, String>(); // contains all single itemsets
//	
//	private int total = 0;
//		
//	public Map<String, Integer> get11Rules()
//	{
//		
//	try
//	{
////		
////		FileReader fs = new FileReader("../data/1itemsets.txt"); // the commits contains test suites that has failure history(does not mean it fails)
//
//		FileReader fs = new FileReader("../data/SMLFail4081itemsets.txt");
//		
//		BufferedReader br = new BufferedReader(fs);
//		
//		String testInfo = br.readLine();
//	
//		while(testInfo!=null &&!testInfo.isEmpty())
//		{		
//			total ++;
////			testInfo = testInfo.replaceAll("\\s","");
//			testInfo = testInfo.split(" ")[0];
////			System.out.println(testInfo);
//			int value = Integer.parseInt(testInfo.split("=")[0]);
//			itemset.put(testInfo, value);
//			itemsetS.put(value, testInfo);
////			itemset.put(testInfo, value);
//						
//			testInfo = br.readLine();			
//		
//		}
//		System.out.println("No.of single itemses: " + total);	
//	}
//	catch(Exception e)
//	{
//		System.out.print(e.toString());
//	}
//	return itemset;
//	}
//
//	public Map<Integer, String> getItemsetS() {
//		return itemsetS;
//	}
//
//	public void setItemsetS(Map<Integer, String> itemsetS) {
//		this.itemsetS = itemsetS;
//	}
//	
//
//	
//
//	
//	
//}
//
////output of the itemset map
//
///*
// * 976=S:976
//226=L:226
//3637=M:3637
//294=L:294
//644=L:644
//287=L:287
//4508=M:4508
//724=L:724
//1102=M:1102
//647=M:647
//3166=L:3166
//4406=L:4406
//2949=S:2949
//277=L:277
//190=M:190
//189=M:189
//528=M:528
//290=L:290
//5272=M:5272
//1116=L:1116
//306=L:306
//496=L:496
//4930=L:4930
//487=M:487
//102=L:102
//4778=L:4778
//2057=M:2057
//503=S:503
//328=L:328
//5273=M:5273
//278=L:278
//282=L:282
//3500=M:3500
//288=L:288
//279=L:279
//281=L:281
//1093=S:1093
//4904=L:4904
//276=L:276
//864=M:864
//*/
