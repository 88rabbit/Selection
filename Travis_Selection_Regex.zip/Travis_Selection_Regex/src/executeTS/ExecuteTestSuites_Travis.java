package executeTS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import exeRecord.ExeRecord_Travis;
import testSuites.TestSuite_Travis;

public class ExecuteTestSuites_Travis 
{
	private double all_TSnumber = 0;
	private double all_failNumber=0;
	private double all_errorNumber=0;
	private double all_failErrorNumber=0;
	private double all_ExeTime_Travis=0;
	
	private double executed_TSnumber = 0;
	private double executed_failNumber=0;
	private double executed_errorNumber=0;
	private double executed_failErrorNumber=0;
	private double executed_ExeTime_Travis=0;

	private TestSuite_Travis currentTs;
	
	private ExeRecord_Travis exeRec;
	private SelectTestSuites selectTests;
	
	
	

	public ExecuteTestSuites_Travis(int distinctTsNum) {
		super();
		selectTests = new SelectTestSuites(distinctTsNum);
		exeRec = new ExeRecord_Travis();
	}

	public void executeTestSuites(ResultSet rs, int distinctTsNum, double percent)
	{	
		
		//for updating the exeRecord
		
		exeRec.initializeRecord(distinctTsNum);
		
		String ts_state;
		int currentId;
		double ts_duration; 
		int ts_runs; 
		int ts_assertions; 
		int ts_failures;
		int ts_errors;
		int ts_skips; 
		Timestamp ts_start_time;
		int build_id;
		int build_number;
		String build_state;
		Timestamp build_start_time; 
		Timestamp build_finish_time; 
		double build_duration; 
		
		int job_id;
		int job_number; 
		String job_state; 
		Timestamp job_start_time; 
		Timestamp job_finish_time;
		double job_duration; 
		int job_allow_failure;
		int repository_id; 
		int commit_id; 
		String commit_sha; 
		String commit_short_sha;
		
		
//		GetStartTime failTime = new GetStartTime();
//		Timestamp failStartTime;
//		
//		GetStartTime exeTime = new GetStartTime();
//		Timestamp executeStartTime;
//		
//		GetStartTime repetTime = new GetStartTime();
//		Timestamp repetitiveStartTime;
		
		try {
				while(rs.next())
				{	
//					testName = rs.getNString("TestSuite");
					currentId= rs.getInt("Ts_id");
					ts_start_time= rs.getTimestamp("Ts_start_time");				
					ts_duration = rs.getDouble("Ts_duration");
					ts_runs = rs.getInt("Ts_runs"); 
					ts_assertions = rs.getInt("Ts_assertions"); 
					ts_failures = rs.getInt("Ts_failures");
					ts_errors = rs.getInt("Ts_errors");
					ts_skips = rs.getInt("Ts_skips"); 
					
					build_id = rs.getInt("Build_id");
					build_number = rs.getInt("Build_number");
					build_state = rs.getString("Build_state");
					build_start_time = rs.getTimestamp("Build_start_time"); 
					build_finish_time = rs.getTimestamp("Build_finish_time"); 
					build_duration = rs.getDouble("Build_duration"); 
					
					job_id = rs.getInt("Job_id");
					job_number = rs.getInt("Job_number"); 
				    job_state = rs.getString("Job_state"); 
					job_start_time = rs.getTimestamp("Job_start_time"); 
					job_finish_time = rs.getTimestamp("Job_finish_time");
					job_duration = rs.getDouble("Job_duration"); 
					job_allow_failure = rs.getInt("Job_allow_failure");
					
					repository_id = rs.getInt("Repository_id"); 
					commit_id = rs.getInt("Commit_id"); 
					commit_sha = rs.getString("Commit_sha"); 
					commit_short_sha = rs.getString("Commit_short_sha");
					
				
					//update currentTs
//					currentTs = new TestSuite_Travis(currentId, ts_duration, ts_runs, ts_assertions, ts_failures, ts_errors, ts_skips, 
//							ts_start_time, build_id, build_number, build_state, build_start_time, build_finish_time, build_duration, job_id,
//							job_number, job_state, job_start_time, job_finish_time, job_duration, repository_id, commit_id, commit_sha,  
//							commit_short_sha);		
					
					currentTs = new TestSuite_Travis(currentId, ts_duration, ts_runs, ts_assertions, ts_failures, ts_errors, ts_skips, 
							ts_start_time, build_number, build_state, build_start_time, build_finish_time, build_duration, job_id,
							job_state, job_start_time, job_finish_time, job_allow_failure, commit_sha);
					
					ts_state = currentTs.getTs_state();
					
					selectTests.selectTs_Travis(currentTs, exeRec, percent);
					
					/*
					 * Statements used in the previous time window version 
					 */
//					/*
//					 * Set the failStartTime
//					 */
//					failStartTime=failTime.window_Travis(currentTs.getTs_start_time(), failWindow, failmmhh);  //this is for minutes
//					
//					/*
//					 * Set the executeStartTime
//					 */		
//					executeStartTime=exeTime.window_Travis(currentTs.getTs_start_time(), executionWindow, executemmhh); // this is for hours
//					
//					/*
//					 * Set the repetitiveStartTime
//					 */
//					repetitiveStartTime=repetTime.window_Travis(currentTs.getTs_start_time(), repetiveWindow, repetivemmhh);
//					
//					/*
//					 * update the number of TestSuite and the execution time of TestSuite by calling the methods in UpdateTs
//					 */		
//					selectTests.selectTs_Travis(currentTs, failStartTime, executeStartTime, exeRec, repetitiveStartTime, coeff_f, coeff_e, comparedNum, coeff_s);
					
				}					
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.all_TSnumber = selectTests.getAccumulateAll().getCountNumber();
		this.all_failNumber=selectTests.getAccumulateAll().getFailNumber();
		this.all_errorNumber = selectTests.getAccumulateAll().getErrorNumber();
		this.all_failErrorNumber = selectTests.getAccumulateAll().getFailErrorNumber();
		this.all_ExeTime_Travis = selectTests.getAccumulateAll().getCountTsDuration_Travis();
//		System.out.println(this.all_ExeTime_Travis);
		
		this.executed_TSnumber = selectTests.getAccumulateExe().getCountNumber();
		this.executed_failNumber=selectTests.getAccumulateExe().getFailNumber();
		this.executed_errorNumber = selectTests.getAccumulateExe().getErrorNumber();
		this.executed_failErrorNumber = selectTests.getAccumulateExe().getFailErrorNumber();
		this.executed_ExeTime_Travis= selectTests.getAccumulateExe().getCountTsDuration_Travis();	
	}

	public double getAll_TSnumber() {
		return all_TSnumber;
	}

	public void setAll_TSnumber(double all_TSnumber) {
		this.all_TSnumber = all_TSnumber;
	}

	public double getAll_failNumber() {
		return all_failNumber;
	}

	public void setAll_failNumber(double all_failNumber) {
		this.all_failNumber = all_failNumber;
	}

	public double getAll_ExeTime_Travis() {
		return all_ExeTime_Travis;
	}

	public void setAll_ExeTime_Travis(double all_ExeTime_Travis) {
		this.all_ExeTime_Travis = all_ExeTime_Travis;
	}

	public double getExecuted_TSnumber() {
		return executed_TSnumber;
	}

	public void setExecuted_TSnumber(double executed_TSnumber) {
		this.executed_TSnumber = executed_TSnumber;
	}

	public double getExecuted_failNumber() {
		return executed_failNumber;
	}

	public void setExecuted_failNumber(double executed_failNumber) {
		this.executed_failNumber = executed_failNumber;
	}

	public double getExecuted_ExeTime_Travis() {
		return executed_ExeTime_Travis;
	}

	public void setExecuted_ExeTime_Travis(double executed_ExeTime_Travis) {
		this.executed_ExeTime_Travis = executed_ExeTime_Travis;
	}

	public TestSuite_Travis getCurrentTs() {
		return currentTs;
	}

	public void setCurrentTs(TestSuite_Travis currentTs) {
		this.currentTs = currentTs;
	}

	public ExeRecord_Travis getExeRec() {
		return exeRec;
	}

	public void setExeRec(ExeRecord_Travis exeRec) {
		this.exeRec = exeRec;
	}

	public SelectTestSuites getSelectTests() {
		return selectTests;
	}

	public void setSelectTests(SelectTestSuites selectTests) {
		this.selectTests = selectTests;
	}
	
	public double getAll_errorNumber() {
		return all_errorNumber;
	}

	public void setAll_errorNumber(double all_errorNumber) {
		this.all_errorNumber = all_errorNumber;
	}

	public double getAll_failErrorNumber() {
		return all_failErrorNumber;
	}

	public void setAll_failErrorNumber(double all_failErrorNumber) {
		this.all_failErrorNumber = all_failErrorNumber;
	}

	public double getExecuted_errorNumber() {
		return executed_errorNumber;
	}

	public void setExecuted_errorNumber(double executed_errorNumber) {
		this.executed_errorNumber = executed_errorNumber;
	}

	public double getExecuted_failErrorNumber() {
		return executed_failErrorNumber;
	}

	public void setExecuted_failErrorNumber(double executed_failErrorNumber) {
		this.executed_failErrorNumber = executed_failErrorNumber;
	}

	


}
