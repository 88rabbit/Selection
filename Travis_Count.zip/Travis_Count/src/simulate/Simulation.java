package simulate;

import java.sql.ResultSet;
import java.sql.SQLException;
import databaseInfo.DatabaseInformation;
import executeTS.ExecuteTestSuites_Travis;
//import executeTS.ExecuteTestSuites_Travis;
//import executeTS.ReadAllRecords_Travis;

public class Simulation 
{	
	public void simulate_Travis(String sql, int failWindow,int executionWindow, String failmmhh,String executemmhh, int distinctTsNum, int repetiveWindow, String repetivemmhh, 
			double coeff_f, double coeff_e, double comparedNum, double coeff_s) throws ClassNotFoundException, SQLException
	{	
		String url = "jdbc:mysql://localhost:3306/Travis_CI";
//		String url = "jdbc:mysql://localhost:3306/test_Travis";
		String username = "root";
		String password = "";
		
		//connect database
		DatabaseInformation dbInfo = new DatabaseInformation();
		ResultSet rs = dbInfo.connectDatabase(sql,url, username, password);
			
		//execute TestSuites
		ExecuteTestSuites_Travis executeTs = new ExecuteTestSuites_Travis(distinctTsNum);
		executeTs.executeTestSuites(rs, failWindow, executionWindow,failmmhh,executemmhh, distinctTsNum, repetiveWindow, repetivemmhh, coeff_f, coeff_e, comparedNum, coeff_s);
		
		
		
//		ReadAllRecords_Travis executeTs = new ReadAllRecords_Travis(distinctTsNum);
////		executeTs.execute(failWindow, executionWindow,failmmhh,executemmhh, distinctTsNum);
//		executeTs.execute(failWindow, executionWindow,failmmhh,executemmhh, distinctTsNum, repetiveWindow, repetivemmhh, coeff_f, coeff_e, comparedNum, coeff_s);
//		
		
		
		//counting numbers of testsuites
				double all_TSnumber = executeTs.getAll_TSnumber();
				double all_failNumber=executeTs.getAll_failNumber();
				double all_errorNumber = executeTs.getAll_errorNumber();
				double all_failErrorNumber = executeTs.getAll_failErrorNumber();
				double all_ExeTime_Travis = executeTs.getAll_ExeTime_Travis();
				double all_fail_error_failError = all_failNumber + all_errorNumber + all_failErrorNumber;
				
				double executed_TSnumber = executeTs.getExecuted_TSnumber();
				double executed_failNumber = executeTs.getExecuted_failNumber();
				double executed_errorNumber = executeTs.getExecuted_errorNumber();
				double executed_failErrorNumber = executeTs.getExecuted_failErrorNumber();
				double executed_ExeTime_Travis = executeTs.getExecuted_ExeTime_Travis();
				double executed_fail_error_failError = executed_failNumber + executed_errorNumber + executed_failErrorNumber;
				
				System.out.println("Number of allTestSuites: "+all_TSnumber);
				System.out.println("Number of executedTests: "+executed_TSnumber);
				System.out.println("allExeTime: "+all_ExeTime_Travis);
				System.out.println("executedTSTime: "+executed_ExeTime_Travis);
				System.out.println("allFailTests: "+ all_failNumber);
				System.out.println("failTests: "+ executed_failNumber);
				System.out.println("allErrorTests: "+ all_errorNumber);
				System.out.println("errorTests: "+ executed_errorNumber);
				System.out.println("allFailErrorTests: "+ all_failErrorNumber);
				System.out.println("failErrorTests: "+ executed_failErrorNumber);
				System.out.println("all fail/error/failErrorTests: " + all_fail_error_failError);
				System.out.println("fail/error/failErrorTests: " + executed_fail_error_failError );
				System.out.println();
				
				double percentOfSelectedTS = executed_TSnumber/all_TSnumber;
				System.out.println("Percentage of test suites selected is: "+percentOfSelectedTS*100);
				double percentOfExeTime = executed_ExeTime_Travis/all_ExeTime_Travis;
				System.out.println("Percentage of execution time is: "+ percentOfExeTime*100);
				double percentOfFailDetected = executed_failNumber/all_failNumber;
				System.out.println("Percentage of failure detected is: " + percentOfFailDetected*100);
				double percentOfErrorDetected = executed_errorNumber/all_errorNumber;
				System.out.println("Percentage of error detected is: " + percentOfErrorDetected*100);
				double percentOfFailErrorDetected = executed_failErrorNumber/all_failErrorNumber;
				System.out.println("Percentage of failError detected is: " + percentOfFailErrorDetected*100);
				double percentOfF_E_FE =  executed_fail_error_failError/all_fail_error_failError;
				System.out.println("Percentage of fail/error/failError detected is: " + percentOfF_E_FE*100);
				
				System.out.println();
				double totalDistinctTestSuites = 0;
				double detectedNewFail = 0;
				double detectedNewError = 0;
				double detectedNewFailError = 0;
				
				double PassToFailTransitions = 0;
				double PassToErrorTransitions = 0;
				double PassToFailErrorTransitions = 0;
				double PassToOthers = 0;
				
				double All_PassToFailTransitions = 0;
				double All_PassToErrorTransitions = 0;
				double All_PassToFailErrorTransitions = 0;
				double All_PassToOthers = 0;
				System.out.println("****");
				for(int i=1; i<distinctTsNum; i++)
				{
//					System.out.println(executeTs.getExeRec().getTs_exeNum()[i]);
					if(executeTs.getExeRec().getIsExecuted()[i])
					{
						totalDistinctTestSuites ++;
						
						PassToFailTransitions += executeTs.getSelectTests().getAccumulateExe().getPf_transition()[i];
						PassToErrorTransitions += executeTs.getSelectTests().getAccumulateExe().getPe_transition()[i];
						PassToFailErrorTransitions += executeTs.getSelectTests().getAccumulateExe().getPfe_transition()[i];
						
						All_PassToFailTransitions += executeTs.getSelectTests().getAccumulateAll().getPf_transition()[i];
						All_PassToErrorTransitions += executeTs.getSelectTests().getAccumulateAll().getPe_transition()[i];
						All_PassToFailErrorTransitions += executeTs.getSelectTests().getAccumulateAll().getPfe_transition()[i];
						
						if(executeTs.getExeRec().getIsFail_Ts()[i])
							detectedNewFail ++;
						if(executeTs.getExeRec().getIsError_Ts()[i])
							detectedNewError ++;
						if(executeTs.getExeRec().getIsFailError_Ts()[i])
							detectedNewFailError ++;
					}
				}
				PassToOthers = PassToFailTransitions + PassToErrorTransitions + PassToFailErrorTransitions;
				All_PassToOthers = All_PassToFailTransitions + All_PassToErrorTransitions + All_PassToFailErrorTransitions;
				System.out.println("****");
				System.out.println("Total Distinct Test Suites: " + totalDistinctTestSuites);
				System.out.println("Number of distinct Detected new Distinct Fail: "+ detectedNewFail);
				System.out.println("Number of distinct new Distinct Error: "+ detectedNewError);
				System.out.println("Number of distinct new Distinct FailError: "+ detectedNewFailError);
				System.out.println();;
				
				System.out.println("Number of Pass -> Fail transitions: " + PassToFailTransitions );
				System.out.println("Number of Pass ->Error transitions: " + PassToErrorTransitions );
				System.out.println("Number of Pass ->FailError transitions: " + PassToFailErrorTransitions );
				System.out.println("Number of Pass -> Fail/Error/FailErrors: " + PassToOthers);
				
				System.out.println();
				double percentNewDistinctFail = detectedNewFail*100/(double)191;
				double percentNewDistinctError = detectedNewError*100/(double)262;
				double percentNewDistinctFailError = detectedNewFailError*100/(double)100;
				System.out.println("Percentage of distinct Detected new Distinct Fail: "+ percentNewDistinctFail);
				System.out.println("Percentage of distinct new Distinct Error: "+ percentNewDistinctError);
				System.out.println("Percentage of distinct new Distinct FailError: "+ percentNewDistinctFailError);
				
//				double allToFailTrans = 2305.0;
//				double allToErrorTrans = 5217.0;
//				double allToFailErrorTrans = 1432.0;
				
				
			    
			    
				double percentToFailTransitions = PassToFailTransitions*100/All_PassToFailTransitions;
				double percentToErrorTransitions = PassToErrorTransitions*100/All_PassToErrorTransitions;
				double percentToFailErrorTransitions = PassToFailErrorTransitions*100/All_PassToFailErrorTransitions;
				double percentToFail_Error_FailError = PassToOthers*100/All_PassToOthers;
				System.out.println("Percentage of Pass -> Fail transitions: "+ percentToFailTransitions);
				System.out.println("Percentage of Pass ->Error transitions "+ percentToErrorTransitions);
				System.out.println("Percentage of Pass ->FailError transitions: "+ percentToFailErrorTransitions);
				System.out.println("Percentage of Pass ->Fail/Error/FailError transitions: "+ percentToFail_Error_FailError);
				
				
				System.out.println();
				System.out.println(percentOfSelectedTS*100);
				System.out.println(percentOfExeTime*100);
				System.out.println(percentOfFailDetected*100);
				System.out.println(percentOfErrorDetected*100);
				System.out.println(percentOfFailErrorDetected*100);
				
				System.out.println(percentOfF_E_FE*100); //%all detect
				

//				System.out.println(percentNewDistinctFail);
//				System.out.println(percentNewDistinctError);
//				System.out.println(percentNewDistinctFailError);
				
				System.out.println(percentToFailTransitions);
				System.out.println(percentToErrorTransitions);
				System.out.println(percentToFailErrorTransitions);
				
				System.out.println(percentToFail_Error_FailError);
				
				
				
				
				
//		//counting numbers of testsuites
//		double all_TSnumber = executeTs.getAll_TSnumber();
//		double all_failNumber=executeTs.getAll_failNumber();
//		double all_ExeTime_Travis = executeTs.getAll_ExeTime_Travis();
//		
//		double executed_TSnumber = executeTs.getExecuted_TSnumber();
//		double executed_failNumber = executeTs.getExecuted_failNumber();
//		double executed_ExeTime_Travis = executeTs.getExecuted_ExeTime_Travis();
//		
//		System.out.println("Number of allTestSuites: "+all_TSnumber);
//		System.out.println("Number of executedTests: "+executed_TSnumber);
//		System.out.println("allExeTime: "+all_ExeTime_Travis);
//		System.out.println("executedTSTime: "+executed_ExeTime_Travis);
//		System.out.println("allFailTests: "+ all_failNumber);
//		System.out.println("failTests: "+ executed_failNumber);
//		System.out.println();
//		
//		double percentOfSelectedTS = executed_TSnumber/all_TSnumber;
//		System.out.println("Percentage of test suites selected is: "+percentOfSelectedTS*100);
//		double percentOfExeTime = executed_ExeTime_Travis/all_ExeTime_Travis;
//		System.out.println("Percentage of execution time is: "+ percentOfExeTime*100);
//		double percentOfFailDetected = executed_failNumber/all_failNumber;
//		System.out.println("Percentage of failure detected is: " + percentOfFailDetected*100);
//		System.out.println();
//		System.out.println(percentOfSelectedTS*100);
//		System.out.println(percentOfExeTime*100);
//		System.out.println(percentOfFailDetected*100);
//		
////		System.out.println(executeTs.getExeRec().countDistinctFails());
////		System.out.println();
//		
//		
//		
//		System.out.println();
//
//		
//		
////		double numOfExeWithFail=0;
////		for(int i=1; i<distinctTsNum; i++)
////		{
////			if(executeTs.getExeRec().getIsFail_Ts()[i])
////			{
//////			 System.out.println(executeTs.getExeRec().getTs_failureNum()[i]);
////			 numOfExeWithFail = numOfExeWithFail + executeTs.getExeRec().getNumOfExe()[i];
////			}
////		}
////		System.out.println((double)(numOfExeWithFail/all_TSnumber)*100);
////		System.out.println((double)(executeTs.getExeRec().getExeAfterFail()/all_TSnumber)*100);
////		System.out.println((double)(numOfExeWithFail/executed_TSnumber)*100);
////		System.out.println((double)(executeTs.getExeRec().getExeAfterFail()/executed_TSnumber)*100);
////		
////		
////		
////		
////		
////		
//////		System.out.println(executeTs.getSelectTests().getNew_Pass());
//////		System.out.println(executeTs.getSelectTests().getNew_Fail());
//////		System.out.println(executeTs.getSelectTests().getPass_Pass());
//////		System.out.println(executeTs.getSelectTests().getPass_Fail());
//////		System.out.println(executeTs.getSelectTests().getFail_Pass());
//////		System.out.println(executeTs.getSelectTests().getFail_Fail());
////		
		
		
	}
	
	
}
