package executeTS;

public class Processor 
{
	private boolean isAvalable;
	private double restTime;
	private Commit temp;
	
	public Processor() 
	{
		super();
		this.isAvalable = true;
		this.restTime = 0;
	}
	
	public void startProcessing(Commit commit, double commitDuration)
	{
		this.isAvalable = false;
		this.restTime = commitDuration;
		this.temp = commit;
	}
	
	public void setTimer()
	{	
		this.restTime --;		
		if(restTime == 0)  // if the commit has finished the executing, then the processor is released
			this.isAvalable = true;
		
		
	}
	
	public void setTimer(double time)
	{
		this.restTime -= time;		
		if(restTime <= 0)
		{// if the commit has finished the executing, then the processor is released
			this.isAvalable = true;
			this.restTime = 0;
		}
	}
	

	public boolean isAvalable() {
		return isAvalable;
	}

	public double getRestTime() {
		return restTime;
	}

	public Commit getTemp() {
		return temp;
	}

	public void setTemp(Commit temp) {
		this.temp = temp;
	}
	
}
