package exeRecord;

import java.sql.Timestamp;
import java.util.ArrayList;

import testSuites.TestSuite;

public class ExeRecord 
{
	private boolean[] isExecuted;
	private boolean[] isFail ;
	
	private int[] tsId;
	private String[] stage;
	private String[] status;
	private Timestamp[] last_launchTime;
	private  Timestamp[] last_failTime;
	
	private int distinctTsNum;
	//Used for counting execution times and failure times
//	private double[] timesSinceLastExe;//each test suite has a counter inter
	private double numSinceLastExe=0;  //for inter
	private double[] timesSinceLastFail;
	
	private double[] numOfFail;
	private double[] numOfExe;
	
	
	//calculate the distances
	private ArrayList<Double> distance_list = new ArrayList<Double>();
	private double dis = 0;
	private double failNo = 0;
	
	private double[] commitsSinceLastExe;
	private double[] commitsSinceLastFail;
	
	
	public void initializeRecord(int distinctTsNum)
	{
		this.distinctTsNum = distinctTsNum;
		isExecuted = new boolean[distinctTsNum];
		isFail = new boolean[distinctTsNum];
		tsId = new int[distinctTsNum];
		stage= new String[distinctTsNum];
		status=new String[distinctTsNum];
		last_launchTime = new  Timestamp[distinctTsNum];
		last_failTime = new  Timestamp[distinctTsNum];
		
//		timesSinceLastExe = new double[distinctTsNum];
		timesSinceLastFail = new double[distinctTsNum];
		
		numOfFail = new double[distinctTsNum];
		numOfExe = new double[distinctTsNum];
		
		commitsSinceLastExe = new double[distinctTsNum];
		commitsSinceLastFail = new double[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
			isExecuted[i] = false;
			isFail[i] = false;
			
			tsId[i]=i;
			stage[i] = "N";
			status[i] = "N";	
			
//			timesSinceLastExe[i] = 0;
			timesSinceLastFail[i] = -1;
			
			numOfFail[i] = 0;
			numOfExe[i] = 0;
			
			commitsSinceLastExe[i] = 0;
			commitsSinceLastFail[i] = 0;
			
		}
	}
		
	public void updateTsRecord(TestSuite ts, int numOfCommit)
	{
		this.isExecuted[ts.getTsId()] = true;
		
		this.stage[ts.getTsId()] = ts.getLast_stage();
		this.status[ts.getTsId()] = ts.getLast_status();
		this.last_launchTime[ts.getTsId()] =ts.getLast_launchTime();
		
//		timesSinceLastExe[ts.getTsId()]=0;
		numOfExe[ts.getTsId()]++;
		
		numSinceLastExe=0;
		
		commitsSinceLastExe[ts.getTsId()] = numOfCommit;
		
		if(ts.isFail()==true)
		{
			this.last_failTime[ts.getTsId()] = ts.getLast_failTime();
			this.isFail[ts.getTsId()] = true;
			
			timesSinceLastFail[ts.getTsId()]=1;
			numOfFail[ts.getTsId()]++;
			
			commitsSinceLastFail[ts.getTsId()] = numOfCommit;			
		}
		else
		{
//			System.out.println(0);
			if(timesSinceLastFail[ts.getTsId()]>=0)
			{
				timesSinceLastFail[ts.getTsId()]++;
			}
//			
//			dis++;
			
//			if(ts.getTsId()==289)
//			{
////			    System.out.println(ts.getTsId());
//				System.out.println(1);
////				System.out.println(ts.getLast_launchTime());
//			}
		}
		
//		accumulateTimesOfExeFail(ts.getTsId()); //update all the others
	}
	
	public void updateSkip(TestSuite ts)
	{
//		accumulateTimesOfExeFail(-1); //update all
		numSinceLastExe++;
		if(timesSinceLastFail[ts.getTsId()]>=0)
		{
			timesSinceLastFail[ts.getTsId()]++;
		}
//		if(ts.getTsId()==289)
//		{
////		    System.out.println(ts.getTsId());
//			System.out.println(0);
////			System.out.println(ts.getLast_launchTime());
//		}
	}
		
	
//	public void accumulateTimesOfExeFail(int tsId)
//	{
//		for(int i=0; i<distinctTsNum; i++)
//		{
//			if(i!=tsId)
//			{
//				timesSinceLastExe[i]++;
//				
////				if(timesSinceLastFail[i]>=0)
////				{
////					timesSinceLastFail[i]++;
////				}	
//			}
//		}
//	}
	
	
	public double getMean()
	{
		double size = this.distance_list.size();
		double totalDis = 0;
		for(int i=0; i<size; i++)
		{
			totalDis +=this.distance_list.get(i);
//			System.out.println(totalDis);
		}
		double mean = (double)(totalDis/size);
		return mean;
	}
	
	public double getVariance()
	{
		double size = this.distance_list.size();
		double mean = getMean();
		double totalSquaredDis=0;
		for(int i=0; i<size; i++)
		{
			totalSquaredDis += Math.pow(this.distance_list.get(i)-mean, 2);
		}
		double variance = (double)(totalSquaredDis/size);
		return variance;
	}
	
	public double getStandardDeviation()
	{
		return Math.sqrt(getVariance());
	}
	
	public double getSkewness()
	{
		double n = this.distance_list.size();
		double temp = 0;
		double mean = getMean();
		
		for(int i=0; i<n; i++)
		{
			temp += Math.pow(this.distance_list.get(i)-mean, 3);
		}
		double cubSD = Math.pow(getStandardDeviation(), 3);
		double skewness = (double)(n*temp)/(double)((n-1)*(n-2)*cubSD);
		return skewness;
	}
	
	public double getKurtosis()
	{
		double n = this.distance_list.size();
		double temp = 0;
		double mean = getMean();
		
		for(int i=0; i<n; i++)
		{
			temp += Math.pow(this.distance_list.get(i)-mean, 4);
		}
		double doubleSquareSD = Math.pow(getStandardDeviation(), 4);
		double kurtosis_1 = (double)(n*(n+1)*temp)/(double)(((n-1)*(n-2)*(n-3)*doubleSquareSD));
		double kurtosis_2= (double)(3*Math.pow(n-1,2))/(double)((n-2)*(n-3));
		
		double kurtosis = kurtosis_1 - kurtosis_2;	
		return kurtosis;
	}
	
	
	public ArrayList<Double> getDistance_list() {
		return distance_list;
	}

	public void setDistance_list(ArrayList<Double> distance_list) {
		this.distance_list = distance_list;
	}

	public double getFailNo() {
		return failNo;
	}

	public void setFailNo(int failNo) {
		this.failNo = failNo;
	}

	public boolean[] getIsExecuted() {
		return isExecuted;
	}
	
	public boolean[] getIsFail() {
		return isFail;
	}

	public int[] getTsId() {
		return tsId;
	}
	
	public String[] getStage() {
		return stage;
	}

	public String[] getStatus() {
		return status;
	}

	public Timestamp[] getLast_launchTime() {
		return last_launchTime;
	}

	public Timestamp[] getLast_failTime() {
		return last_failTime;
	}

//	public double[] getTimesSinceLastExe() {
//		return timesSinceLastExe;
//	}
//
//	public void setTimesSinceLastExe(double[] timesSinceLastExe) {
//		this.timesSinceLastExe = timesSinceLastExe;
//	}

	public double[] getTimesSinceLastFail() {
		return timesSinceLastFail;
	}

	public double getNumSinceLastExe() {
		return numSinceLastExe;
	}

	public void setNumSinceLastExe(double numSinceLastExe) {
		this.numSinceLastExe = numSinceLastExe;
	}

	public void setTimesSinceLastFail(double[] timesSinceLastFail) {
		this.timesSinceLastFail = timesSinceLastFail;
	}

	public double[] getNumOfFail() {
		return numOfFail;
	}

	public void setNumOfFail(double[] numOfFail) {
		this.numOfFail = numOfFail;
	}

	public double[] getNumOfExe() {
		return numOfExe;
	}

	public void setNumOfExe(double[] numOfExe) {
		this.numOfExe = numOfExe;
	}

	public double[] getCommitsSinceLastExe() {
		return commitsSinceLastExe;
	}

	public void setCommitsSinceLastExe(double[] commitsSinceLastExe) {
		this.commitsSinceLastExe = commitsSinceLastExe;
	}

	public double[] getCommitsSinceLastFail() {
		return commitsSinceLastFail;
	}

	public void setCommitsSinceLastFail(double[] commitsSinceLastFail) {
		this.commitsSinceLastFail = commitsSinceLastFail;
	}

	
}
