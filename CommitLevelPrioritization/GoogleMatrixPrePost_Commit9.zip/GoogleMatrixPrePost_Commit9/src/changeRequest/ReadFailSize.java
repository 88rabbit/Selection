package changeRequest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class ReadFailSize 
{
	//this class is used to read the SML.txt file: the first column: Commit ID, rest three columns are "Small"Medium"Large", if there exists one fail, the commit fails
	//In a certain commit, the faults may be caused by "small" or "medium" or "large", or both or all. "1" represent the certain size is fail, "0" certain size only pass
	Map<Integer, boolean[]>  map= new HashMap<Integer, boolean[]>();
	public Map<Integer, boolean[]> readSize()
	{
		try
		{

			FileReader fs = new FileReader("../data/SML.txt");
			

			BufferedReader br = new BufferedReader(fs);
			
			String testInfo = br.readLine(); 
			testInfo = br.readLine();// no need the first row
		
			while(testInfo!=null &&!testInfo.isEmpty())
			{		
				//parse file contents
				String[] eachLine = testInfo.split(",");
				int commitId = Integer.parseInt(eachLine[0]);
				
				boolean[] isSizeFail = new boolean[3];
				
				if(Integer.parseInt(eachLine[1]) == 1)
					isSizeFail[0] = true; // isSmallFail
				if(Integer.parseInt(eachLine[2]) == 1)
					isSizeFail[1] = true; // isMediumFail
				if(Integer.parseInt(eachLine[3]) == 1)
					isSizeFail[2] = true;
				
				map.put(commitId, isSizeFail);
							
				testInfo = br.readLine();			
			
			}
//			System.out.println("No." + total);	
//			System.out.println(c + "records have been inserted");
		}
		catch(Exception e)
		{
			System.out.print(e.toString());
		}
		return  map;
	}

}
