package executeTS;

public class CountFailures 
{
	private int withinFail;
	private int outExe;
	private int skip;
	
	
	public CountFailures() {
		super();
		this.withinFail = 0;
		this.outExe = 0;
		this.skip = 0;
	}
	
//	public void setWithinFail() 
//	{
//		this.withinFail ++;
//	}
//	public void setOutExe() 
//	{
//		this.outExe ++;
//	}
//	
//	public void setSkip() 
//	{
//		this.skip ++;
//	}
	
	
	
	public int getWithinFail() {
		return withinFail;
	}
	
	public int getOutExe() {
		return outExe;
	}
	
	public int getSkip() {
		return skip;
	}
	
	
	

}
