package executeTS;

import java.sql.Timestamp;
import java.util.Random;

import exeRecord.ExeRecord_Travis;
import testSuites.TestSuite_Travis;

public class SelectTestSuites 
{	
	
	//for counting number of all TestSuites
	private Accumulation accumulateAll;
			
	//for counting number of executed TestSuites
	private Accumulation accumulateExe;	
	private UpdateExeRecord updateExeRecords = new UpdateExeRecord();
	private Accumulation accumulateTemp;
	
//	private int consecutiveExe=0;
//	private int consecutiveSkip=0;
	
	private Random r = new Random();
//	private double random_zeroToOne;
	private double windowSize = 0;//warm up
	
	public SelectTestSuites(int distinctTsNum) {
		super();
		this.accumulateAll = new Accumulation(distinctTsNum);
		this.accumulateExe = new Accumulation(distinctTsNum);
		this.accumulateTemp = new Accumulation(distinctTsNum);
		
	}
	
	public void selectTs_Travis(TestSuite_Travis currentTs, ExeRecord_Travis exeRec, 
			double percent)
	{
		/*
		 * Dynamic range case
		 */
		double min_p = 1;
		double max_f = 1;
		double max_e = 1;
		double max_b = 1;
		double max_p = 1;
		double min_p_delta = 1;
		
//		double percent = 0.30;
//		double percent = 0;	
		windowSize = percent * 1734.689189; //30% of median number of test suites execution times
//		windowSize = percent * 12; //30% of median number of test suites execution times
		
//		System.out.println(exeRec.getNumberOfFailTimesWithinWindow()[lastTs.getTsId()] + "," + exeRec.getFailNumberWithinWindow());
		min_p_delta = Math.min(windowSize, exeRec.getMin_p()[currentTs.getTsId()]);
		
		if(exeRec.getHasMax_f()[currentTs.getTsId()])
			max_f = exeRec.getMax_f()[currentTs.getTsId()];
		
//		/*
//		 * For 1% selection
//		 */
//		double totalTs = 3199155;
//		double percentOfSelection = accumulateExe.getCountNumber()*100/totalTs;
//		if(percentOfSelection > 1)
//		{
//			//skip
//			this.accumulateAll.counting_Travis_All(currentTs);
////			System.out.println(accumulateExe.getCountNumber() + ","+ accumulateAll.getCountNumber());
//		}
//		else
		{
		
		//1. warm up
		if(exeRec.getIsExecuted()[currentTs.getTsId()] == false || exeRec.getTs_exeNum()[currentTs.getTsId()] < windowSize)
		{
//			System.out.println("<<<<");
			updateExeRecords.updateDetails_Travis(false, exeRec, currentTs, accumulateTemp, true);
//			System.out.println("xxx");
			exeRec.setPreExeTimes(currentTs.getTsId(), 0);

			accumulateAll.setStatus(currentTs.getTsId(), currentTs.getTs_state());
//			System.out.println("exe");
			accumulateExe.setStatus(currentTs.getTsId(), currentTs.getTs_state());
			
			
		}
		else
		{
			this.accumulateAll.counting_Travis_All(currentTs);
		/*
		 * selection
		 * if test suite does not have fail history, WE = (1+0.5X)*We_start
		 * if test suite has fail/error/failError history, WE = Min(WindowSize, Min_p)
		 */
		
		if(!exeRec.getIsFail_Ts()[currentTs.getTsId()] 
				&& !exeRec.getIsError_Ts()[currentTs.getTsId()]
				&& !exeRec.getIsFailError_Ts()[currentTs.getTsId()]
				&& exeRec.getTimesSinceLastExe()[currentTs.getTsId()] >= ((0.5*exeRec.getPreExeTimes()[currentTs.getTsId()]+1)*windowSize))
		{
			//counting
//			this.accumulateAll.counting_Travis_All(currentTs);
			updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);
		}
		else if((exeRec.getIsFail_Ts()[currentTs.getTsId()] 
				|| exeRec.getIsError_Ts()[currentTs.getTsId()]
				|| exeRec.getIsFailError_Ts()[currentTs.getTsId()])
				&& exeRec.getTimesSinceLastExe()[currentTs.getTsId()] >= min_p_delta)
		{
			//counting
//			this.accumulateAll.counting_Travis_All(currentTs);
			updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);
		}
		else if(exeRec.getNumberOfFailTimesWithinWindow()[currentTs.getTsId()] > 0
				|| exeRec.getNumberOfErrorTimesWithinWindow()[currentTs.getTsId()] > 0
				|| exeRec.getNumberOfFailErrorTimesWithinWindow()[currentTs.getTsId()] > 0)
//		else if((exeRec.getTimesSinceLastFail()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[currentTs.getTsId()]<=coeff_f)
//				|| (exeRec.getTimesSinceLastError()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastError()[currentTs.getTsId()]<=coeff_f)
//				|| (exeRec.getTimesSinceLastFailError()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastFailError()[currentTs.getTsId()]<=coeff_f))			
		{
			//counting
//			this.accumulateAll.counting_Travis_All(currentTs);
//			System.out.println(coeff_f);
			updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);
		}
//		for regex
		else 
		{	
			//counting
//			this.accumulateAll.counting_Travis_All(currentTs);
			
			if(exeRec.getHasMin_p()[currentTs.getTsId()])
				min_p = exeRec.getMin_p()[currentTs.getTsId()];
				
			if(exeRec.getHasMax_f()[currentTs.getTsId()])
				max_f = exeRec.getMax_f()[currentTs.getTsId()];
			if(exeRec.getHasMax_e()[currentTs.getTsId()])
				max_e = exeRec.getMax_e()[currentTs.getTsId()];
			if(exeRec.getHasMax_b()[currentTs.getTsId()])
				max_b = exeRec.getMax_b()[currentTs.getTsId()];
			
				/*
				 * Key: test id
				 * 
				 * Condition:
				 * if ti.numContinuousPass == min_p 
				 * 		|| 0 < ti.numContinuousFail < max_f
				 * 		|| 0 < ti.numContinuousError < max_e
				 * 		|| 0 < ti.numContinuousFailError < max_b
				 * 		execute
				 * else
				 * 		skip
				 * 
				 */
			if((exeRec.getIsFail_Ts()[currentTs.getTsId()] 
					||exeRec.getIsError_Ts()[currentTs.getTsId()] 
					|| exeRec.getIsFailError_Ts()[currentTs.getTsId()])
					&& exeRec.getPre_pass_times()[currentTs.getTsId()] == min_p) //min_p
			{ 
//				System.out.println("min_p: "+min_p);
				updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);
			}
			else if(exeRec.getPre_fail_times()[currentTs.getTsId()] > 0 && exeRec.getPre_fail_times()[currentTs.getTsId()] < max_f ) //max_f
			{
				updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);
			}
			else if(exeRec.getPre_error_times()[currentTs.getTsId()] > 0 && exeRec.getPre_error_times()[currentTs.getTsId()] < max_e ) //max_f
			{
				updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);	
			}
			else if(exeRec.getPre_failError_times()[currentTs.getTsId()] > 0 && exeRec.getPre_failError_times()[currentTs.getTsId()] < max_b ) //max_f
			{
//				System.out.println("max_f: "+max_f);
				updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, true);
			}
			else
			{
				updateExeRecords.updateDetails_Travis(true, exeRec, currentTs, accumulateExe, false);	
			}
		}
		
		
		}
		}
					
	}	
		

	public Accumulation getAccumulateAll() {
		return accumulateAll;
	}

	public void setAccumulateAll(Accumulation accumulateAll) {
		this.accumulateAll = accumulateAll;
	}

	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}
	
	
	
}
