package executeTS;

import java.sql.Timestamp;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

import changeRequest.ReadFailJavaTs;
import exeRecord.ExeRecord;
import testSuites.TestSuite;

//
public class PrioritizeCommits 
{
	
	private PriorityQueue<Commit> pq;
	private PriorityQueue<Commit> temp;
	
//	private Queue<Commit> pq;
//	private Queue<Commit> temp;

	public PrioritizeCommits() 
	{
		super();
//		this.pq = new LinkedList<Commit>();
		this.pq = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
			public int compare(Commit c1, Commit c2)
			{
				
				double c1_failRatio = c1.getFailRatio();
				double c1_exeRatio = c1.getExeRatio();
				
				double c2_failRatio = c2.getFailRatio();
				double c2_exeRatio = c2.getExeRatio();
				
				
				if(c1_failRatio < c2_failRatio)
					return 1;
				else if(c1_failRatio == c2_failRatio)
				{
					if(c1_exeRatio< c2_exeRatio)
						return 1;
					else if(c1_exeRatio == c2_exeRatio)
						return 0;
					else
						return -1;
				}
				else
					return -1;		
				
			}
		});
	}

	
	public void updateCommits(Commit c)
	{
		pq.offer(c);		
	}
	
	public void clearPq()
	{
		pq.clear();
	}
	
	public void updateInformInnerCommits(String selectedStage, ExeRecord exeRec, int failWindow, int executionWindow, 
			 List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, boolean[]> isSizeFail, int exeNumOfCommit)
	{
//		this.temp = new LinkedList<Commit>();;
		this.temp = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
			public int compare(Commit c1, Commit c2)
			{
				
				double c1_failRatio = c1.getFailRatio();
				double c1_exeRatio = c1.getExeRatio();
				
				double c2_failRatio = c2.getFailRatio();
				double c2_exeRatio = c2.getExeRatio();
				
				
				if(c1_failRatio < c2_failRatio)
					return 1;
				else if(c1_failRatio == c2_failRatio)
				{
					if(c1_exeRatio< c2_exeRatio)
						return 1;
					else if(c1_exeRatio == c2_exeRatio)
						return 0;
					else
						return -1;
				}
				else
					return -1;	
			}
		});
			
//		System.out.println(pq.size() + "size");
		Commit newCommit;
		while(!pq.isEmpty())
		{
			Commit c = pq.poll();
			newCommit = new Commit();
			newCommit.setCommitEnterQueueTime(c.getCommitEnterQueueTime());
//			double old = c.getDuration();
			
			newCommit.init(c.getAllTests().get(0), failTest, javaTs, isSizeFail, c.getNumOfConcurrent());	
			for(TestSuite ts: c.getAllTests())
			{
				newCommit.update(ts, selectedStage, exeRec, failWindow, executionWindow, exeNumOfCommit+1);	
			}
			this.temp.offer(newCommit);
//			newCommit.calculateDuration();
//			double ne = newCommit.getDuration();
			
//			if(old != ne)
//				System.out.println(newCommit.getId());
		}
//		System.out.println();
		
		this.pq = this.temp;
		
	}
	
	
//	
	public PriorityQueue<Commit> getPq() {
		return pq;
	}

	public void setPq(PriorityQueue<Commit> pq) {
		this.pq = pq;
	}


//	public Queue<Commit> getPq() {
//		return pq;
//	}

}






//public class PrioritizeCommits 
//{
//	
////	private PriorityQueue<Commit> pq;
////	private PriorityQueue<Commit> temp;
//	
//	private Queue<Commit> pq;
//	private Queue<Commit> temp;
//
//	public PrioritizeCommits() 
//	{
//		super();
//		this.pq = new LinkedList<Commit>();
//		/*
//		 * Optimal
//		 */
////		this.pq = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
////			public int compare(Commit c1, Commit c2)
////			{		
////				Timestamp c1_Arrive = c1.commitArrivalTime();
////				Timestamp c2_Arrive = c2.commitArrivalTime();
////				
////				/*
////				 * inner and inter optimal
////				 */
////				if((double)c1.getFailNumber()/(double)c1.getTotalNum() > (double)c2.getFailNumber()/(double)c2.getTotalNum())
////					return -1;
////				else if((double)c1.getFailNumber()/(double)c1.getTotalNum() == (double)c2.getFailNumber()/(double)c2.getTotalNum())
////					return 0;
////				else 
////					return 1;	
////				
////			}
////		});
//	}
//
//	
//	public void updateCommits(Commit c)
//	{
//		pq.offer(c);		
//	}
//	
//	public void clearPq()
//	{
//		pq.clear();
//	}
//	
//	public void updateInformInnerCommits(String selectedStage, ExeRecord exeRec, int failWindow, int executionWindow, 
//			 List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, boolean[]> isSizeFail, int exeNumOfCommit)
//	{
//		this.temp = new LinkedList<Commit>();;
//		
//		/*
//		 * Optimal
//		 * 
//		 */
////		this.temp = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
////			public int compare(Commit c1, Commit c2)
////			{		
////				Timestamp c1_Arrive = c1.commitArrivalTime();
////				Timestamp c2_Arrive = c2.commitArrivalTime();
////				
////				/*
////				 * inner and inter optimal
////				 */
////				if((double)c1.getFailNumber()/(double)c1.getTotalNum() > (double)c2.getFailNumber()/(double)c2.getTotalNum())
////					return -1;
////				else if((double)c1.getFailNumber()/(double)c1.getTotalNum() == (double)c2.getFailNumber()/(double)c2.getTotalNum())
////					return 0;
////				else 
////					return 1;	
////				
////			}
////		});
//			
////		System.out.println(pq.size() + "size");
//		Commit newCommit;
//		while(!pq.isEmpty())
//		{
//			Commit c = pq.poll();
//			newCommit = new Commit();
//          newCommit.setCommitEnterQueueTime(c.getCommitEnterQueueTime());
//			
////			System.out.println(c.getId());
//			
//			newCommit.init(c.getAllTests().get(0), failTest, javaTs, isSizeFail, c.getNumOfConcurrent());
//			for(TestSuite ts: c.getAllTests())
//			{
//				newCommit.update(ts, selectedStage, exeRec, failWindow, executionWindow, exeNumOfCommit+1);	
//			}
//			this.temp.offer(newCommit);
//		}
////		System.out.println();
//		
//		this.pq = this.temp;
//		
//	}
//	
//	
////	
////	public PriorityQueue<Commit> getPq() {
////		return pq;
////	}
//
//	public void setPq(PriorityQueue<Commit> pq) {
//		this.pq = pq;
//	}
//
//
//	public Queue<Commit> getPq() {
//		return pq;
//	}
//	
//}
