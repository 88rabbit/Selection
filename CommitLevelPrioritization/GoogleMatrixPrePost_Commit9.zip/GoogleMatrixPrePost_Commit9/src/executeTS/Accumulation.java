package executeTS;

import java.util.HashMap;
import java.util.Map;

import testSuites.TestSuite;

public class Accumulation 
{
	private double countNumber=0;
	private double countFailNumber=0;
	private double countExeTime=0;
	
	private double expected_ts = 0;
	private double expected_time = 0;
	
	private double lastPercent = 0;
	private double curPercent = 0;
	private double lastPercent_time = 0;
	private double curPercent_time = 0;
	
	private double ftotal = 0;
	private double ftotal_exeTime = 0;
	
	private double allFailExeTime = 0;
	private double FailExeTime = 0;
	double timePassed = -1;
	double commitNum = -1;
	
	private double start = 0;
	private double end = 0;
	private boolean isFirstFail=true;
	
	Map<Integer, Double> map = new HashMap<Integer, Double>();
	
	public void counting_all(TestSuite ts, String selectedStage)
	{
		if(selectedStage.equals("post") || selectedStage.equals("pres"))
		{
//			if(ts.getLast_stage().equals(selectedStage))
			{
				countNumber++;
				countExeTime = countExeTime + ts.getLast_executionTime();	
				if(ts.isFail() == true)
				{
					countFailNumber++;
					allFailExeTime +=  ts.getLast_executionTime();
//					System.out.println(ts.getTsId());
				}
			}
			
			
		
		}
		else if(selectedStage.equals("presAndpost"))
		{
			countNumber++;
			countExeTime = countExeTime + ts.getLast_executionTime();	
			if(ts.isFail() == true)
			{
				countFailNumber++;
				allFailExeTime +=  ts.getLast_executionTime();
			}
		}		
	}
	
	public void counting_exe(TestSuite ts, String selectedStage, int commitNum, double timePassed)
	{
		if(commitNum != this.commitNum)
		{
			this.commitNum = commitNum;
			this.timePassed = timePassed;
			isFirstFail = true;
			if(end-start>0)
//				System.err.println(end-start); //get the duration from the first failed test to the last failed test
			start=0;
			end=0;
		}
		
		if(selectedStage.equals("presAndpost"))
		{
			
//			if(ts.getLast_stage().equals(selectedStage))
//			{
				countNumber++;
				
				countExeTime = countExeTime + ts.getResetExeTime();	
				if(ts.isFail() == true)
				{
					countFailNumber++;
					ftotal += countNumber;
					ftotal_exeTime += countExeTime;
//					System.out.println(ts.getTsId());
				}
				
//				if(lastPercent )
				
//			}
		}
		else if(selectedStage.equals("post") || selectedStage.equals("pres"))
		{
//			System.out.println("a");
			
			countNumber++;
			countExeTime = countExeTime + ts.getResetExeTime();	
			
			this.timePassed +=  ts.getResetExeTime();
			if(ts.isFail() == true)
			{
				countFailNumber++;
				ftotal += countNumber;
				FailExeTime += ts.getResetExeTime();	;
				ftotal_exeTime += this.timePassed/(double)(1000*60*60);
				
				if(isFirstFail)
				{
					start = timePassed;
					isFirstFail = false;
				}
				end = this.timePassed;
				
				/*
				 * Generate % of failures
				 */
				double totalCommitsTime = 0;
				if(selectedStage.equals("pres"))
					totalCommitsTime = (double)1906241540.00;
				else 
					totalCommitsTime = (double)4192794408.00;
				
//				System.err.println(100*this.timePassed/totalCommitsTime + "," + ts.getTsId());
//				System.err.println(commitNum + ","+ ts.getTsId());
//				System.out.println(countNumber + "," + countFailNumber);
			}
			
//			double totalNumber;
//			double totalExe;
//			
//////			//post
////			totalNumber = 1495856;
////			totalExe = 47908919148.0;
//	
////			pres
//			totalNumber = 1112158.0;
//			totalExe = 25869310082.0;
//	
//			
//			curPercent = countNumber/totalNumber;
//			curPercent_time = countExeTime/totalExe;
//			
//			//time percent
//			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
//			{
////				System.out.println((int)(expected_time*100) + ","+ countFailNumber);
//				expected_time += 0.01;
//			}
//			//ts oercent
//			if(lastPercent <= expected_ts && curPercent >= expected_ts)
//			{
//				map.put((int)(expected_ts*100), countFailNumber);
////				System.out.println((int)(expected_ts*100) + ","+ countFailNumber);
//				expected_ts += 0.01;
//			}
//			
//			lastPercent = curPercent;
//			lastPercent_time = curPercent_time;
////			System.out.println(curPercent);
		}		
	}

	public double getCountNumber() {
		return countNumber;
	}

	public void setCountNumber(double countNumber) {
		this.countNumber = countNumber;
	}

	public double getCountExeTime() {
		return countExeTime;
	}

	public void setCountExeTime(long countExeTime) {
		this.countExeTime = countExeTime;
	}

	public double getCountFailNumber() {
		return countFailNumber;
	}

	public void setCountFailNumber(double countFailNumber) {
		this.countFailNumber = countFailNumber;
	}

	public double getFtotal() {
		return ftotal;
	}

	public void setFtotal(double ftotal) {
		this.ftotal = ftotal;
	}

	public double getFtotal_exeTime() {
		return ftotal_exeTime;
	}

	public void setFtotal_exeTime(double ftotal_exeTime) {
		this.ftotal_exeTime = ftotal_exeTime;
	}

	public double getAllFailExeTime() {
		return allFailExeTime;
	}

	public void setAllFailExeTime(double allFailExeTime) {
		this.allFailExeTime = allFailExeTime;
	}

	public Map<Integer, Double> getMap() {
		return map;
	}

	public void setMap(Map<Integer, Double> map) {
		this.map = map;
	}

	public double getFailExeTime() {
		return FailExeTime;
	}

	public void setFailExeTime(double failExeTime) {
		FailExeTime = failExeTime;
	}
	
	
}


//public class Accumulation 
//{
//	private double countNumber=0;
//	private double countFailNumber=0;
//	private double countExeTime=0;
//	
//	private double expected_ts = 0;
//	private double expected_time = 0;
//	
//	private double lastPercent = 0;
//	private double curPercent = 0;
//	private double lastPercent_time = 0;
//	private double curPercent_time = 0;
//	
//	private double ftotal = 0;
//	private double ftotal_exeTime = 0;
//	
//	private double allFailExeTime = 0;
//	
//	Map<Integer, Double> map = new HashMap<Integer, Double>();
//	
//	public void counting_all(TestSuite ts, String selectedStage)
//	{
//		if(selectedStage.equals("post") || selectedStage.equals("pres"))
//		{
////			if(ts.getLast_stage().equals(selectedStage))
//			{
//				countNumber++;
//				countExeTime = countExeTime + ts.getLast_executionTime();	
//				if(ts.isFail() == true)
//				{
//					countFailNumber++;
//					allFailExeTime +=  ts.getLast_executionTime();
////					System.out.println(ts.getTsId());
//				}
//			}
//			
//			
//		
//		}
//		else if(selectedStage.equals("presAndpost"))
//		{
//			countNumber++;
//			countExeTime = countExeTime + ts.getLast_executionTime();	
//			if(ts.isFail() == true)
//			{
//				countFailNumber++;
//				allFailExeTime +=  ts.getLast_executionTime();
//			}
//		}		
//	}
//	
//	public void counting_exe(TestSuite ts, String selectedStage)
//	{
//		
//		if(selectedStage.equals("presAndpost"))
//		{
//			
////			if(ts.getLast_stage().equals(selectedStage))
////			{
//				countNumber++;
//				
//				countExeTime = countExeTime + ts.getLast_executionTime();	
//				if(ts.isFail() == true)
//				{
//					countFailNumber++;
//					ftotal += countNumber;
//					ftotal_exeTime += countExeTime;
////					System.out.println(ts.getTsId());
//				}
//				
////				if(lastPercent )
//				
////			}
//		}
//		else if(selectedStage.equals("post") || selectedStage.equals("pres"))
////		else if(selectedStage.equals("presAndpost"))
//		{
////			System.out.println("a");
//			countNumber++;
//			countExeTime = countExeTime + ts.getLast_executionTime();	
//			if(ts.isFail() == true)
//			{
//				countFailNumber++;
//				ftotal += countNumber;
//				ftotal_exeTime += countExeTime;
////				System.out.println(countNumber + "," + countFailNumber);
//			}
//			
//			double totalNumber;
//			double totalExe;
//			
//////			//post
////			totalNumber = 1495856;
////			totalExe = 47908919148.0;
//	
////			pres
//			totalNumber = 1112158.0;
//			totalExe = 25869310082.0;
//	
//			
//			curPercent = countNumber/totalNumber;
//			curPercent_time = countExeTime/totalExe;
//			
//			//time percent
//			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
//			{
////				System.out.println((int)(expected_time*100) + ","+ countFailNumber);
//				expected_time += 0.01;
//			}
//			//ts oercent
//			if(lastPercent <= expected_ts && curPercent >= expected_ts)
//			{
//				map.put((int)(expected_ts*100), countFailNumber);
////				System.out.println((int)(expected_ts*100) + ","+ countFailNumber);
//				expected_ts += 0.01;
//			}
//			
//			lastPercent = curPercent;
//			lastPercent_time = curPercent_time;
////			System.out.println(curPercent);
//		}		
//	}
//
//	public double getCountNumber() {
//		return countNumber;
//	}
//
//	public void setCountNumber(double countNumber) {
//		this.countNumber = countNumber;
//	}
//
//	public double getCountExeTime() {
//		return countExeTime;
//	}
//
//	public void setCountExeTime(long countExeTime) {
//		this.countExeTime = countExeTime;
//	}
//
//	public double getCountFailNumber() {
//		return countFailNumber;
//	}
//
//	public void setCountFailNumber(double countFailNumber) {
//		this.countFailNumber = countFailNumber;
//	}
//
//	public double getFtotal() {
//		return ftotal;
//	}
//
//	public void setFtotal(double ftotal) {
//		this.ftotal = ftotal;
//	}
//
//	public double getFtotal_exeTime() {
//		return ftotal_exeTime;
//	}
//
//	public void setFtotal_exeTime(double ftotal_exeTime) {
//		this.ftotal_exeTime = ftotal_exeTime;
//	}
//
//	public double getAllFailExeTime() {
//		return allFailExeTime;
//	}
//
//	public void setAllFailExeTime(double allFailExeTime) {
//		this.allFailExeTime = allFailExeTime;
//	}
//
//	public Map<Integer, Double> getMap() {
//		return map;
//	}
//
//	public void setMap(Map<Integer, Double> map) {
//		this.map = map;
//	}
//	
//}







//package executeTS;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import testSuites.TestSuite;
//
//public class Accumulation 
//{
//	private double countNumber=0;
//	private double countFailNumber=0;
//	private double countExeTime=0;
//	
//	private double expected_ts = 0;
//	private double expected_time = 0;
//	
//	private double lastPercent = 0;
//	private double curPercent = 0;
//	private double lastPercent_time = 0;
//	private double curPercent_time = 0;
//	
//	private double ftotal = 0;
//	private double ftotal_exeTime = 0;
//	
//	private double allFailExeTime = 0;
//	
//	Map<Integer, Double> map = new HashMap<Integer, Double>();
//	
//	public void counting_all(TestSuite ts, String selectedStage)
//	{
//		if(selectedStage.equals("post") || selectedStage.equals("pres"))
//		{
////			if(ts.getLast_stage().equals(selectedStage))
//			{
//				countNumber++;
//				countExeTime = countExeTime + ts.getLast_executionTime();	
//				if(ts.isFail() == true)
//				{
//					countFailNumber++;
//					allFailExeTime +=  ts.getLast_executionTime();
////					System.out.println(ts.getTsId());
//				}
//			}
//			
//			
//		
//		}
//		else if(selectedStage.equals("presAndpost"))
//		{
//			countNumber++;
//			countExeTime = countExeTime + ts.getLast_executionTime();	
//			if(ts.isFail() == true)
//			{
//				countFailNumber++;
//				allFailExeTime +=  ts.getLast_executionTime();
//			}
//		}		
//	}
//	
//	public void counting_exe(TestSuite ts, String selectedStage, double passedTime, double totalTimeLine)
//	{
//		
//		if(selectedStage.equals("presAndpost"))
//		{
//			
////			if(ts.getLast_stage().equals(selectedStage))
////			{
//				countNumber++;
//				
//				countExeTime = countExeTime + ts.getLast_executionTime();	
//				if(ts.isFail() == true)
//				{
//					countFailNumber++;
//					ftotal += countNumber;
//					ftotal_exeTime += countExeTime;
////					System.out.println(ts.getTsId());
//				}
//				
////				if(lastPercent )
//				
////			}
//		}
//		else if(selectedStage.equals("post") || selectedStage.equals("pres"))
//		{
////			System.out.println("a");
//			countNumber++;
//			countExeTime = countExeTime + ts.getLast_executionTime();	
//			if(ts.isFail() == true)
//			{
//				countFailNumber++;
//				ftotal += countNumber;
//				ftotal_exeTime += countExeTime;
////				System.out.println(countNumber + "," + countFailNumber);
//			}
//			
//			double totalNumber;
//			double totalExe;
//			
//////			//post
////			totalNumber = 1495856;
////			totalExe = 47908919148.0;
//	
////			pres
//			totalNumber = 1112158.0;
//			totalExe = 25869310082.0;
//	
//			
//			curPercent = countNumber/totalNumber;
//			curPercent_time = countExeTime/totalExe;
//			
//			//time percent
//			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
//			{
////				System.out.println((int)(expected_time*100) + ","+ countFailNumber);
//				expected_time += 0.01;
//			}
//			//ts oercent
//			if(lastPercent <= expected_ts && curPercent >= expected_ts)
//			{
//				map.put((int)(expected_ts*100), countFailNumber);
////				System.out.println((int)(expected_ts*100) + ","+ countFailNumber);
//				expected_ts += 0.01;
//			}
//			
//			lastPercent = curPercent;
//			lastPercent_time = curPercent_time;
////			System.out.println(curPercent);
//		}		
//	}
//
//	public double getCountNumber() {
//		return countNumber;
//	}
//
//	public void setCountNumber(double countNumber) {
//		this.countNumber = countNumber;
//	}
//
//	public double getCountExeTime() {
//		return countExeTime;
//	}
//
//	public void setCountExeTime(long countExeTime) {
//		this.countExeTime = countExeTime;
//	}
//
//	public double getCountFailNumber() {
//		return countFailNumber;
//	}
//
//	public void setCountFailNumber(double countFailNumber) {
//		this.countFailNumber = countFailNumber;
//	}
//
//	public double getFtotal() {
//		return ftotal;
//	}
//
//	public void setFtotal(double ftotal) {
//		this.ftotal = ftotal;
//	}
//
//	public double getFtotal_exeTime() {
//		return ftotal_exeTime;
//	}
//
//	public void setFtotal_exeTime(double ftotal_exeTime) {
//		this.ftotal_exeTime = ftotal_exeTime;
//	}
//
//	public double getAllFailExeTime() {
//		return allFailExeTime;
//	}
//
//	public void setAllFailExeTime(double allFailExeTime) {
//		this.allFailExeTime = allFailExeTime;
//	}
//
//	public Map<Integer, Double> getMap() {
//		return map;
//	}
//
//	public void setMap(Map<Integer, Double> map) {
//		this.map = map;
//	}
//	
//}

