package changeRequest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

// this class read commits that contains fail history (# 3841), but does not mean they will fail
public class ReadCR 
{

	private List<Integer> crList = new ArrayList<Integer>();
	private int total = 0;
	private int eachCR;
		
	public List<Integer> getCR()
	{
		
	try
	{
//		
		FileReader fs = new FileReader("../data/failCommits.txt"); // the commits contains test suites that has failure history(does not mean it fails)

		BufferedReader br = new BufferedReader(fs);
		
		String testInfo = br.readLine();
	
		while(testInfo!=null &&!testInfo.isEmpty())
		{		
			total ++;
			//parse file contents
			eachCR = Integer.parseInt(testInfo);
			
			crList.add(eachCR);
						
			testInfo = br.readLine();			
		
		}
//		System.out.println("No.of commits that contains test suites with fail history(does not mean it fails)" + total);	
//		System.out.println(c + "records have been inserted");
	}
	catch(Exception e)
	{
		System.out.print(e.toString());
	}
	return crList;
	}

}
