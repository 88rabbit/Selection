# libDir=../lib
# srcDir=../src
# binDir=../bin

# inputParameter_1=0   #failWindow
# inputParameter_2=6  #exeWindow
# inputParameter_3=hours	#failmmhh
# inputParameter_4=hours # exemmhh
# inputParameter_7=30 #repetitiveWindow
# inputParameter_8=minutes #repetitivemmhh

# inputParameter_5=post	
# inputParameter_6=pres   #selected stage

# # dataset=googleDataset

# # for inputParameter_1 in 15 30
# for inputParameter_1 in 1 2 4 12 24 48 96
# do
# 	#compile the program
# 	javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

# 	# with option -h, the list of options will show up
# 	java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

# 	#run the program with parameters
# 	java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=googleDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -x=$inputParameter_7 -y=$inputParameter_8
# done

# # for travis

# # javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

# # # with option -h, the list of options will show up
# # java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

# # #run the program with parameters

# # java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=travisDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -x=$inputParameter_7 -y=$inputParameter_8

libDir=../lib
srcDir=../src
binDir=../bin

inputParameter_1=96   #failWindow
inputParameter_2=1	  #exeWindow
inputParameter_3=hours	#failmmhh
inputParameter_4=hours # exemmhh
inputParameter_7=1 #repetitiveWindow
inputParameter_8=hours #repetitivemmhh

inputParameter_5=pres	
inputParameter_6=pres  #selected stage

inputParameter_9=8     #coeff_f: previous coeff1 (previous b) failue
inputParameter_10=0	   # coeff_e: previous coeff3. a constant a (previous h) decay
inputParameter_11=0   # compared number
inputParameter_12=128    #coeff_s: previous coeff2   skip

# dataset=googleDataset
# for inputParameter_10 in 100
# for inputParameter_10 in 25 50 100 200 400 800
# do

# for inputParameter_9 in 2 4 8 16
# for inputParameter_9 in 32 64 128
# do
	# echo $inputParameter_10
	# for inputParameter_11 in 0.5 0.625 0.75 0.875 1 2 4 8 16 32 64
	# for inputParameter_11 in 0.625 0.75 0.875 20 24 28 36 40 44 48 52 56 60
	# for inputParameter_11 in 48
	# for inputParameter_12 in 1 2 4 8 16 32 64 128 256
	# for inputParameter_12 in 1 1.2 1.4 1.6 1.8 2 2.4 2.8 3 3.2 3.4 3.6 3.8 4 4.2 4.4 4.6 4.8 5 5.5 6

	# for inputParameter_9 in 2 4 8 16 32 64 128
	# for inputParameter_9 in 2 8 32 128 512 2048 8192
	
		# for inputParameter_12 in 2 4 8 16 32 64 128 256 512
		# for inputParameter_12 in 4096
		# for inputParameter_12 in 8 16 32 64 128 256 512
	#coeff2
	# for inputParameter_12 in 2 8 32 128 512 2048
	for inputParameter_12 in 4096
	do
		# coeff3
		# for inputParameter_10 in 131072
		for inputParameter_10 in 1000000000000000
		do
			#coeff1
			# for inputParameter_9 in 4096
			for inputParameter_9 in 2 8 32 128 512 1024 2048 4096
			# for inputParameter_9 in 256
			do
			#compile the program
			javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

			# with option -h, the list of options will show up
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

			#run the program with parameters
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=googleDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -x=$inputParameter_7 -y=$inputParameter_8 -B=$inputParameter_9 -H=$inputParameter_10 -C=$inputParameter_11 -t=$inputParameter_12

			done
	done
done
# # for travis

# javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

# # with option -h, the list of options will show up
# java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

# #run the program with parameters
# java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=travisDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -x=$inputParameter_7 -y=$inputParameter_8

