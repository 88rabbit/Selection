package exeRecord;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import testSuites.TestSuite;

public class AllCR 
{
	private RecordCR[] recordCR = new RecordCR[3841];
	private Map<Integer, Integer> listIdCr = new HashMap<Integer, Integer>();
	
	public void initialize(List<Integer> CR)
	{
		for(int i=0; i<CR.size(); i++)
		{
			recordCR[i] = new RecordCR(CR.get(i));
			listIdCr.put(CR.get(i), i);
//			System.out.println(recordCR[i]);
		}		
	}
	
	public void updateCR(TestSuite ts)
	{
//		System.out.println(ts.getTsId() + ","+ts.getChangeRequest());
//		System.out.println(listIdCr.get(ts.getChangeRequest()));
		recordCR[listIdCr.get(ts.getChangeRequest())].updateCRr(ts);
	} 
	
	public RecordCR[] getRecordCR() {
		return recordCR;
	}

	public void setRecordCR(RecordCR[] recordCR) {
		this.recordCR = recordCR;
	}

	public Map<Integer, Integer> getListIdCr() {
		return listIdCr;
	}

	public void setListIdCr(Map<Integer, Integer> listIdCr) {
		this.listIdCr = listIdCr;
	}

}
