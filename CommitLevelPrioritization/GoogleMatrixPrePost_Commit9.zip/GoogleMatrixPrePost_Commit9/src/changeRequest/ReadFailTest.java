package changeRequest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadFailTest 
{
	private List<Integer> crList = new ArrayList<Integer>();
	private int total = 0;
	private int eachCR;
		
	public List<Integer> getCR()
	{
		
	try
	{
//		
		FileReader fs = new FileReader("../data/fail.txt");

		BufferedReader br = new BufferedReader(fs);
		
		String testInfo = br.readLine();
	
		while(testInfo!=null &&!testInfo.isEmpty())
		{		
			total ++;
			//parse file contents
			eachCR = Integer.parseInt(testInfo);
			
			crList.add(eachCR);
						
			testInfo = br.readLine();			
		
		}
//		System.out.println("No." + total);	
//		System.out.println(c + "records have been inserted");
	}
	catch(Exception e)
	{
		System.out.print(e.toString());
	}
	return crList;
	}

}
