package executeTS;

import testSuites.TestSuite;
import exeRecord.ExeRecord;

public class UpdateExeRecord 
{
	private Accumulation accumulateExe;
	
	public void updateDetails(boolean isMoving, ExeRecord exeRec, TestSuite lastTs, Accumulation accumulateExe, String selectedStage, boolean isExe)
	{
		if(isExe)
		{
			exeRec.updateTsRecord(isMoving, lastTs);
			lastTs.setExecuted(true);
			
			//counting
			accumulateExe.counting(lastTs, selectedStage);		
			this.accumulateExe = accumulateExe;
		}
		else
		{
			exeRec.updateSkip(isMoving, lastTs);
		}
		
	}

	
	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}
}
