package changeRequest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadMatrix 
{
	private Map<Integer,Integer> failIndex = new HashMap<Integer,Integer>();
	private double[][] matrix = new double[287][287];
		
	public double[][] getMatrix()
	{
		ReadFailTest failList = new ReadFailTest();
		List<Integer> crList = failList.getCR();
		for(int i=0; i<crList.size(); i++)
		{
			failIndex.put(crList.get(i), i); //key is the test id, value is matrix index 
		}
		
	try
	{		
		FileReader fs = new FileReader("../data/failMatrix287.txt");

		BufferedReader br = new BufferedReader(fs);
		
		String testInfo = br.readLine();
		
		int row = 0;
//		int index2 = 0;
		while(testInfo!=null &&!testInfo.isEmpty())
		{		
			String[] array = testInfo.split(",");
//			System.out.println(array.length);
//			System.out.println(crList.size());
			
			for(int i=0; i<crList.size(); i++)
			{
//				System.out.println(array[i]);
				
				matrix[row][i] = Double.parseDouble(array[i]); 			
			}
			testInfo = br.readLine();		
			row ++; 
		
		}
//		System.out.println("No." + total);	
//		System.out.println(c + "records have been inserted");
	}
	catch(Exception e)
	{
		System.out.print(e.toString());
	}
	return matrix;
	}

	public double getPvalue(int i, int j) //use test id i and test id j to get the p value
	{
//		System.out.println(i + "," + j);
		int row = failIndex.get(i);
		int column = failIndex.get(j);
		return matrix[row][column];
	}

}
