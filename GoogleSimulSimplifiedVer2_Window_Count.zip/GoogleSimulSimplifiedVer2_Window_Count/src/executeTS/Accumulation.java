package executeTS;

import testSuites.TestSuite;

public class Accumulation 
{
	private double countNumber=0;
	private double countFailNumber=0;
	private long countExeTime=0;
	
	private String[] status;
	private double[] pf_transition;
	
	
	public Accumulation(int distinctTsNum) 
	{
		super();
		//For calculation
		status = new String[distinctTsNum];
		pf_transition = new double[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
			status[i] = "N";
			pf_transition[i] = 0;
		}
	}

	public void counting(TestSuite ts, String selectedStage)
	{
		if(selectedStage.equals("post") || selectedStage.equals("pres"))
		{
			if(ts.getLast_stage().equals(selectedStage))
			{
				countNumber++;
				countExeTime = countExeTime + ts.getLast_executionTime();	
				if(ts.isFail() == true)
				{
					countFailNumber++;
//					System.out.println(ts.getTsId());
				}
			}
			
			//calculate all the pf_transition number 
			if(this.status[ts.getTsId()].equals("PASSED") && ts.isFail()==true)  // if previous is passed and current is failed ==> transition PF
			{
				pf_transition[ts.getTsId()] ++;
			}
			this.status[ts.getTsId()] = ts.getLast_status();
			
		}
		else if(selectedStage.equals("pres and post"))
		{
			countNumber++;
			countExeTime = countExeTime + ts.getLast_executionTime();	
			if(ts.isFail() == true)
			{
				countFailNumber++;
			}
			
			//calculate all the pf_transition number 
			if(this.status[ts.getTsId()].equals("PASSED") && ts.isFail()==true)  // if previous is passed and current is failed ==> transition PF
			{
				pf_transition[ts.getTsId()] ++;
			}
			this.status[ts.getTsId()] = ts.getLast_status();
		}		
	}

	public double getCountNumber() {
		return countNumber;
	}

	public void setCountNumber(double countNumber) {
		this.countNumber = countNumber;
	}

	public long getCountExeTime() {
		return countExeTime;
	}

	public void setCountExeTime(long countExeTime) {
		this.countExeTime = countExeTime;
	}

	public double getCountFailNumber() {
		return countFailNumber;
	}

	public void setCountFailNumber(double countFailNumber) {
		this.countFailNumber = countFailNumber;
	}

	public double[] getPf_transition() {
		return pf_transition;
	}

	public void setPf_transition(double[] pf_transition) {
		this.pf_transition = pf_transition;
	}

	public String[] getStatus() {
		return status;
	}

	public void setStatus(int id, String status) {
		this.status[id] = status;
//		System.out.println(status[1]);
	}
}
