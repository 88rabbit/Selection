package executeTS;

//import testSuites.TestSuite_Google;
import testSuites.TestSuite_Travis;
//import exeRecord.ExeRecord_Google;
import exeRecord.ExeRecord_Travis;

public class UpdateExeRecord 
{
	private Accumulation accumulateExe;
	
	public UpdateExeRecord() {
		super();
	}


	public void updateDetails_Travis(boolean isMoving, ExeRecord_Travis exeRec, TestSuite_Travis currentTs, Accumulation accumulateExe, 
			 boolean isExe)
	{
		if(isExe)
		{
			exeRec.updateTsRecord(isMoving, currentTs);
			currentTs.setExecuted(true);
			
			//counting
			accumulateExe.counting_Travis_Exe(isMoving ,currentTs);		
			this.accumulateExe = accumulateExe;
		}
		else
		{
			exeRec.updateGrow(isMoving, currentTs);
		}
	}

	
	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}
	
}
