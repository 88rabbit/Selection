package executeTS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import exeRecord.ExeRecord;
import readFile.ReadInFailedTestSuiteRegularPatterns;
import testSuites.TestSuite;

public class ExecuteTestSuites 
{
	private double all_TSnumber = 0;
	private double all_failNumber=0;
	private long all_ExeTime = 0;
	
	private double executed_TSnumber = 0;
	private double executed_failNumber=0;
	private long executed_ExeTime = 0;

	private TestSuite lastTs = new TestSuite(0);
	private TestSuite currentTs;
	
	private SelectTestSuites selectTests;
	private ExeRecord exeRec = new ExeRecord();
	
	public ExecuteTestSuites(int distinctTsNum) {
		super();
		this.selectTests = new SelectTestSuites(distinctTsNum);
	}

	
	public void executeTestSuites(ResultSet rs, int failWindow, int executionWindow,String failmmhh, String executemmhh, String selectedStage,int distinctTsNum, String alwaysExecutedStage, double deltaExe, double deltaFail)
	{	
		boolean isFirst = true;
		
		//for updating the exeRecord
		
		exeRec.initializeRecord(distinctTsNum);
		
		Timestamp launchTime;
		int currentId;
		String stage;
		String status;
		long executionTime;
		
		GetStartTime failTime = new GetStartTime();
		Timestamp failStartTime;
		
		GetStartTime exeTime = new GetStartTime();
		Timestamp executeStartTime;
		
		ReadInFailedTestSuiteRegularPatterns rf = new ReadInFailedTestSuiteRegularPatterns();
		Map<Integer, Integer[]> id_max_min = rf.ReadInIdAndRepeatRange(selectedStage);
		
		try {
				while(rs.next())
				{	
//					testName = rs.getNString("TestSuite");
					currentId= rs.getInt("T_number");
					launchTime= rs.getTimestamp("LaunchTime");				
					stage = rs.getString("Stage");
					status = rs.getString("Status_test");
//					int shardNumber = rs.getInt("Shared_number");
					executionTime = rs.getInt("ExecutionTime");
				
					//update currentTs
					currentTs = new TestSuite(currentId, launchTime, stage, status, executionTime);	
					
					//for initialization
					if(isFirst == true)
					{				
						isFirst = false;	
						lastTs = currentTs;
					}
					else
					{		
						/*
						 * Set the failStartTime
						 */
						failStartTime=failTime.window(lastTs.getLast_launchTime(), failWindow, failmmhh);  //this is for minutes
						
						/*
						 * Set the executeStartTime
						 */		
						executeStartTime=exeTime.window(lastTs.getLast_launchTime(), executionWindow, executemmhh); // this is for hours
						
						//coalesce the shards
						if(lastTs.getTsId()==currentId && lastTs.getLast_launchTime().equals(currentTs.getLast_launchTime()))
						{	
							currentTs = lastTs;
							// update the execution time of the certain testSuite
							long tempExeTime = lastTs.getLast_executionTime() + executionTime;
							currentTs.setLast_executionTime(tempExeTime);			
							if(status.equals("FAILED"))
							{
								currentTs.setLast_failTime(currentTs.getLast_launchTime());
								currentTs.setLast_status("FAILED");
								currentTs.setFail(true);
							}
							lastTs = currentTs;
							continue;
						}	
						else
						{
							/*
							 * update the number of TestSuite and the execution time of TestSuite by calling the methods in UpdateTs
							 */		
							selectTests.selectTs(lastTs, failStartTime, executeStartTime, selectedStage, exeRec, alwaysExecutedStage, deltaExe, deltaFail, id_max_min);
							
							//update
							lastTs = currentTs;
						}						
						
					}					
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//update the last one
		/*
		 * Set the failStartTime
		 */
		failStartTime=failTime.window(lastTs.getLast_launchTime(), failWindow, failmmhh);  //this is for minutes			
		/*
		 * Set the executeStartTime
		 */		
		executeStartTime=exeTime.window(lastTs.getLast_launchTime(), executionWindow, executemmhh); // this is for hours
		/*
		 * update the number of TestSuite and the execution time of TestSuite
		 */		
		selectTests.selectTs(lastTs, failStartTime, executeStartTime, selectedStage, exeRec, alwaysExecutedStage, deltaExe, deltaFail, id_max_min);
		
		//update
		lastTs = currentTs;		
		
		this.all_TSnumber = selectTests.getAccumulateAll().getCountNumber();
		this.all_failNumber=selectTests.getAccumulateAll().getCountFailNumber();
		this.all_ExeTime = selectTests.getAccumulateAll().getCountExeTime();
		
		this.executed_TSnumber = selectTests.getAccumulateExe().getCountNumber();
		this.executed_failNumber=selectTests.getAccumulateExe().getCountFailNumber();
		this.executed_ExeTime = selectTests.getAccumulateExe().getCountExeTime();	
		
		System.out.println("************************");
		System.out.println(selectTests.getCountExe());
		System.out.println(selectTests.getCountFail());
		System.out.println(selectTests.getCountMinP());
		System.out.println(selectTests.getCountMaxF());
	}


	public double getAll_TSnumber() {
		return all_TSnumber;
	}

	public void setAll_TSnumber(double all_TSnumber) {
		this.all_TSnumber = all_TSnumber;
	}

	public double getAll_failNumber() {
		return all_failNumber;
	}

	public void setAll_failNumber(double all_failNumber) {
		this.all_failNumber = all_failNumber;
	}

	public long getAll_ExeTime() {
		return all_ExeTime;
	}

	public void setAll_ExeTime(long all_ExeTime) {
		this.all_ExeTime = all_ExeTime;
	}

	public double getExecuted_TSnumber() {
		return executed_TSnumber;
	}

	public void setExecuted_TSnumber(double executed_TSnumber) {
		this.executed_TSnumber = executed_TSnumber;
	}

	public double getExecuted_failNumber() {
		return executed_failNumber;
	}

	public void setExecuted_failNumber(double executed_failNumber) {
		this.executed_failNumber = executed_failNumber;
	}

	public long getExecuted_ExeTime() {
		return executed_ExeTime;
	}

	public void setExecuted_ExeTime(long executed_ExeTime) {
		this.executed_ExeTime = executed_ExeTime;
	}

	public TestSuite getLastTs() {
		return lastTs;
	}

	public void setLastTs(TestSuite lastTs) {
		this.lastTs = lastTs;
	}

	public TestSuite getCurrentTs() {
		return currentTs;
	}

	public void setCurrentTs(TestSuite currentTs) {
		this.currentTs = currentTs;
	}


	public SelectTestSuites getSelectTests() {
		return selectTests;
	}


	public void setSelectTests(SelectTestSuites selectTests) {
		this.selectTests = selectTests;
	}


	public ExeRecord getExeRec() {
		return exeRec;
	}


	public void setExeRec(ExeRecord exeRec) {
		this.exeRec = exeRec;
	}
		
}
