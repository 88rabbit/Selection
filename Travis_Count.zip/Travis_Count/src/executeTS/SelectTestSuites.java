package executeTS;

import java.sql.Timestamp;
import java.util.Random;

import exeRecord.ExeRecord_Travis;
import testSuites.TestSuite_Travis;

public class SelectTestSuites 
{	
	
	//for counting number of all TestSuites
	private Accumulation accumulateAll;
			
	//for counting number of executed TestSuites
	private Accumulation accumulateExe;
	
	//for counting number of executed TestSuites
	private Accumulation accumulateTemp;
	
	private UpdateExeRecord updateExeRecords = new UpdateExeRecord();
	
//	private int consecutiveExe=0;
//	private int consecutiveSkip=0;
	
	private Random r = new Random();
	private double random_zeroToOne;
	private double windowSize = 0;//warm up
	
	
	public SelectTestSuites(int distinctTsNum) {
		super();
		this.accumulateAll = new Accumulation(distinctTsNum);
		this.accumulateExe = new Accumulation(distinctTsNum);
		this.accumulateTemp = new Accumulation(distinctTsNum);
		
	}
	
	
	public void selectTs_Travis(TestSuite_Travis currentTs,Timestamp failStartTime,Timestamp executeStartTime, ExeRecord_Travis exeRec, 
			double coeff_f, double coeff_e, double comparedNum, double coeff_s )
	{
		/*
		 * for Warmups
		 */
//		deltaExe = warmUpNum;
		double totalNum = 3592266.0;
		double percent = 0.3;
		
		windowSize = percent * 1734.689189; //30% of median number of test suites execution times
//		windowSize = percent * 12; //30% of median number of test suites execution times
		
		/*
		 * For 1% selection
		 */		
		double totalTs = 3199155;
		double percentOfSelection = accumulateExe.getCountNumber()*100/totalTs;
//		if(percentOfSelection > 1)
//		{
//			//skip
//			this.accumulateAll.counting_Travis(currentTs);
////			System.out.println(accumulateExe.getCountNumber() + ","+ accumulateAll.getCountNumber());
//		}
//		else
		{
			//warm up part
//		if(exeRec.getIsExecuted()[currentTs.getTsId()] == false || exeRec.getTs_exeNum()[currentTs.getTsId()] < windowSize)
//		{
//			updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateTemp, true);
//			exeRec.setPf_num1(currentTs.getTsId(), 0);
//			exeRec.setPe_num1(currentTs.getTsId(), 0);
//			exeRec.setPef_num1(currentTs.getTsId(), 0);
//			
//			accumulateAll.setStatus(currentTs.getTsId(), currentTs.getTs_state());
////			System.out.println("exe");
//			accumulateExe.setStatus(currentTs.getTsId(), currentTs.getTs_state());
//			
//		}
//		else
		{
			/*
			 * update the number of TestSuite and the execution time of TestSuite
			 */
			
			//counting
			this.accumulateAll.counting_Travis(currentTs);
			
	//		double delta_comparedNum = Math.random();
			
			random_zeroToOne = r.nextInt(1001)*100/ 1000; // random number
			
			//1. for new tests
			if(exeRec.getIsExecuted()[currentTs.getTsId()] == false)
			{				
				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, true);	
						
			}
			/*
			 *  (1) long time not been executed
			 *  (2) recently failed
			 *  (3) recently errored
			 *  (4) recently failErrored
			 */
			else if (exeRec.getTimesSinceLastExe()[currentTs.getTsId()] >= coeff_e
					|| (exeRec.getTimesSinceLastFail()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[currentTs.getTsId()]<=coeff_f)
					|| (exeRec.getTimesSinceLastError()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastError()[currentTs.getTsId()]<=coeff_f)
					|| (exeRec.getTimesSinceLastFailError()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastFailError()[currentTs.getTsId()]<=coeff_f))
			{	
				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, true);	
						
			}
////			/*
////			 * Add one more condition for P->F, P->E, P->FE transition
////			 */
//			else if(exeRec.getPf_percent()[currentTs.getTsId()] >= random_zeroToOne
//					|| exeRec.getPe_percent()[currentTs.getTsId()] >= random_zeroToOne
//					|| exeRec.getPef_percent()[currentTs.getTsId()] >= random_zeroToOne) // one more condition for P->F, P->E, P->FE transition
//			{
//				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, true);	
//			}
			else // not execute
			{	
				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, false);
			//	System.out.println(exeRec.getCk()[currentTs.getTsId()]);
			}
			
		}}
		
			
//		//1. for new tests
//		if(!currentTs.getTs_state().equals("errored"))
//		{
//			if(exeRec.getIsExecuted()[currentTs.getTsId()] == false)
//			{				
//				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, true);	
//				
//			}
//			else if (exeRec.getTimesSinceLastExe()[currentTs.getTsId()] >= coeff_e
//					|| (exeRec.getTimesSinceLastFail()[currentTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[currentTs.getTsId()]<=coeff_f))
//			{	
//				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, true);	
//				
//			}
//			else // not execute
//			{	
//				updateExeRecords.updateDetails_Travis(exeRec, currentTs, accumulateExe, false);
//	//			System.out.println(exeRec.getCk()[currentTs.getTsId()]);
//			}
//		}
					
	}	
		

	public Accumulation getAccumulateAll() {
		return accumulateAll;
	}

	public void setAccumulateAll(Accumulation accumulateAll) {
		this.accumulateAll = accumulateAll;
	}

	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}
	
	
	
}
