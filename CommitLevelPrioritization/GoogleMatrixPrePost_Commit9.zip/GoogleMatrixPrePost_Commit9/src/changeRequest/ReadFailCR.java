package changeRequest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
// this class read commits that contains actually fails (#1324)
public class ReadFailCR 
{
	private List<Integer> failCrList = new ArrayList<Integer>();
	private int total = 0;
	private int eachCR;
		
	public List<Integer> getFailCR()
	{
		
	try
	{
//		
		FileReader fs = new FileReader("../data/commitsFail.txt"); // the commits contains test suites that contains at least one fail

		BufferedReader br = new BufferedReader(fs);
		
		String testInfo = br.readLine();
	
		while(testInfo!=null &&!testInfo.isEmpty())
		{		
			total ++;
			//parse file contents
			eachCR = Integer.parseInt(testInfo);
			
			failCrList.add(eachCR);
						
			testInfo = br.readLine();			
		
		}
//		System.out.println("No. of fail commits: " + total);	
//		System.out.println(c + "records have been inserted");
	}
	catch(Exception e)
	{
		System.out.print(e.toString());
	}
	return failCrList;
	}

}
