#!/bin/bash

libDir=../lib
srcDir=../src
binDir=../bin


inputParameter_1=96   # not used in this version
inputParameter_2=1	  # not used in this version
inputParameter_3=hours	# not used in this version
inputParameter_4=hours # not used in this version
inputParameter_7=1 # not used in this version
inputParameter_8=hours # not used in this version

inputParameter_5=post	# not used in this version
inputParameter_6=post   # not used in this version

inputParameter_9=8       # percentage of test suites selected for warm up
inputParameter_10=800	   # not used in this version
inputParameter_11=3     # not used in this version
inputParameter_12=2    # not used in this version

# for inputParameter_12 in 2 8 32 128 512 2048
# for inputParameter_12 in 4096 8192
# do
		# coeff3
		for inputParameter_10 in 0.3
		# for inputParameter_10 in 1 2 4 5 10 100
		do
			# #coeff1
			# # for inputParameter_9 in 1 2 4 5 10 100
			# for inputParameter_9 in 100
			# do
			#compile the program
			javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

			# with option -h, the list of options will show up
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

			#run the program with parameters
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=travisDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -x=$inputParameter_7 -y=$inputParameter_8 -B=$inputParameter_9 -H=$inputParameter_10 -C=$inputParameter_11 -t=$inputParameter_12
        # done 
	done
# done