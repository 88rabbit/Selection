import java.sql.SQLException;

import parsingCommandLine.Cli;
import simulate.Simulation;

public class TravisDataset 
{
	public void getTravisDataset(String[] newString) throws ClassNotFoundException, SQLException
	{
		//setting the sql
	//	private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData ORDER BY LaunchTime, T_number, Shared_number";
		String sql = "SELECT * FROM AllData ORDER BY Ts_start_time, Ts_id";
	//	private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData Where T_Number = '3430' ORDER BY LaunchTime, T_number, Shared_number";
				
		int distinctTsNum = 2712;
		
		int failWindow=Integer.parseInt(newString[1]);
		int executionWindow=Integer.parseInt(newString[2]);
		
		// setting the followings, Strings should be "minutes" or "hours"
		String failmmhh= newString[3];
		String executemmhh = newString[4];	
		
		int repetiveWindow = Integer.parseInt(newString[5]);
		String repetivemmhh = newString[6];
		
		String alwaysExecutedStage = newString[7];
		String selectedStage = newString[8];
		
		
		double coeff_f = Double.parseDouble(newString[9]);
		double coeff_e = Double.parseDouble(newString[10]);
		double comparedNum = Double.parseDouble(newString[11]);
		double coeff_s = Double.parseDouble(newString[12]);
		
//		int failWindow= 24;
//		int executionWindow=24;
//		
//		// setting the followings, Strings should be "minutes" or "hours"
//		String failmmhh= "hours";
//		String executemmhh = "hours";
		
		// setting the phase of testSuites		
		
		Simulation simulation = new Simulation();
		simulation.simulate_Travis(sql, failWindow, executionWindow, failmmhh, executemmhh, distinctTsNum, repetiveWindow, repetivemmhh, coeff_f, coeff_e, comparedNum, coeff_s);
	}
}
