package executeTS;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class GetStartTime 
{
	public Timestamp window(Timestamp launchTime, int setTime, String mmhh)
	{
		Date time = new Date(launchTime.getTime());
		Calendar calForFail = Calendar.getInstance();
		calForFail.setTime(time);
		calForFail.set(Calendar.YEAR, 2014);
		if(mmhh.equals("hours"))
		{
			calForFail.add(Calendar.HOUR, -setTime); 	
		}
		else if(mmhh.equals("minutes"))
		{
			calForFail.add(Calendar.MINUTE, -setTime); 	
		}					
		time = calForFail.getTime();					
		Timestamp startTime = new Timestamp(time.getTime());	
		
		return startTime;
	}
	
}
