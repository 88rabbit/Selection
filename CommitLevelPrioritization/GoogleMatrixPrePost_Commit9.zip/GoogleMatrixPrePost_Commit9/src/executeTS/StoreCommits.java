package executeTS;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

import changeRequest.ReadFailJavaTs;
import changeRequest.ReadMatrix;
import exeRecord.ExeRecord;
import readFile.readConcurrentNum;
import testSuites.TestSuite;

public class StoreCommits 
{
	private PriorityQueue<Commit> pq; // put all commits in
	private Accumulation accumulateAll = new Accumulation();
//	private Accumulation accumulateCurrent = new Accumulation();
    private int commitId = 0;
	
	
//	//last version
	private Commit exeCommit = new Commit();
	private boolean isFrist = true;// set the first ts
	
	private int numOfCommit = 0;
	private double allCommitsDuration;
	private double avgCommitDuration;
		
	private String selectedStage;
//	private double totalExeTime;
//	private double startPercentTime;
	
	private readConcurrentNum rcn;
	private Map<Integer, Integer> concurrentMap;
	private int numOfConcurrent;
//	private double delta;
	
	private int[] testFails;
	
	private double totalTests;
	
//	private Map<Integer, Commit> optimalMap = new HashMap<Integer, Commit>();
	public StoreCommits(String selectedStage) 
	{
		super();
//		this.updateExeRecords = new UpdateExeRecord();
		this.rcn = new readConcurrentNum();
		this.concurrentMap = rcn.getNumOfConcurrent();
//		this.delta = delta;
		
		this.selectedStage = selectedStage;
//		if(this.selectedStage.equals("pres"))
//			totalExeTime = 24356365871.0;
//		else if(this.selectedStage.equals("post"))
//			totalExeTime = 46506268797.0; 
//		this.startPercentTime = 0;

		this.pq = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
			public int compare(Commit c1, Commit c2)
			{				
				Timestamp c1_Arrive = c1.commitArrivalTime();
				Timestamp c2_Arrive = c2.commitArrivalTime();
//				System.out.println(c1_Arrive + ";" + c2_Arrive);
				if(c1_Arrive.before(c2_Arrive))
					return -1;
				else if(c1_Arrive.equals(c2_Arrive))
					return 0;
				else 
					return 1;	
			}
		});
		/*
		 * For optimal
		 */
//		this.pq = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
//			public int compare(Commit c1, Commit c2)
//			{		
//				Timestamp c1_Arrive = c1.commitArrivalTime();
//				Timestamp c2_Arrive = c2.commitArrivalTime();
//				
//				/*
//				 * inner and inter optimal
//				 */
//				if((double)c1.getFailNumber()/(double)c1.getTotalNum() > (double)c2.getFailNumber()/(double)c2.getTotalNum())
//					return -1;
//				else if((double)c1.getFailNumber()/(double)c1.getTotalNum() == (double)c2.getFailNumber()/(double)c2.getTotalNum())
//					return 0;
//				else 
//					return 1;	
//				
//			}
//		});
		
		testFails = new int[5557];
	}

	public void storeLastCommit()
	{
		exeCommit.calculateDuration();
		allCommitsDuration += exeCommit.getDuration(); //durtion is different from exetime
//		System.out.println("duration:"+exeCommit.getDuration());
//		allCommit.offer(exeCommit);
//		allCommit.offerLast(exeCommit);// put it into queue's end
		pq.offer(exeCommit);
		
//		totalTests += exeCommit.getAllTests().size();
//		System.err.println(exeCommit.getFailNumber());
//		System.out.println(exeCommit.getAllTests().size());
//		System.out.println(exeCommit.getTotalNum() +","+  exeCommit.getId());
		
		System.out.println(numOfCommit);
//		System.out.println(accumulateAll.getCountNumber() + ";" + accumulateAll.getCountExeTime());
//		startPercentTime = accumulateCurrent.getCountExeTime()/this.totalExeTime;
////		exeCommit.setPercentStartTime(startPercentTime);// set the start time for the next commit
//		System.out.println(accumulateCurrent.getCountNumber() + ";" + accumulateCurrent.getCountExeTime());
//		System.out.println("starttime: "+startPercentTime);
		
		System.out.println("avg number of tests in a commit: "+ totalTests/(double)numOfCommit);
		System.out.println("total: "+allCommitsDuration);
		avgCommitDuration = allCommitsDuration/(double)numOfCommit;
		System.out.println("avg: "+avgCommitDuration);
		
//		for(int i=0; i<5557; i++)
//			System.out.println(testFails[i]);
	}

	
	public void storeAllCommits(ReadMatrix matrix, List<Integer> failTest, List<Integer> failCR, ReadFailJavaTs javaTs,TestSuite lastTs, String selectedStage, ExeRecord exeRec, 
			String alwaysExecutedStage, Map<Integer, boolean[]> isSizeFail, int failWindow, int executionWindow) throws ParseException
	{
		
		//count all test suites
		this.accumulateAll.counting_all(lastTs, selectedStage);		
		
		if(isFrist)
		{
			numOfCommit ++;
			commitId = lastTs.getChangeRequest();
			numOfConcurrent = concurrentMap.get(commitId);
			exeCommit.init(lastTs, failTest, javaTs, isSizeFail,numOfConcurrent, testFails);	
//			exeCommit.setPercentStartTime(startPercentTime);
			isFrist = false;				
		}			
				
		if(commitId == lastTs.getChangeRequest())
		{
			exeCommit.storeTestsInCommit(lastTs, selectedStage); //add a test suite to the commit
//			accumulateCurrent.counting_all(lastTs, selectedStage); // count the current num and time
		}
		else
		{
//			System.out.println(exeCommit.getPercentStartTime());
			exeCommit.calculateDuration();
			allCommitsDuration += exeCommit.getDuration(); //durtion is different from exetime
//			if(exeCommit.getDuration()<0)
//				System.out.print("dur:" + exeCommit.getDuration() + ";");
//			exeCommit.calculateDuration();
//			System.out.println("now:" + exeCommit.getDuration());
			pq.offer(exeCommit);
			
//			totalTests += exeCommit.getAllTests().size();
//			System.err.println(exeCommit.getFailNumber());
//			System.out.println(exeCommit.getAllTests().size());
//			System.out.println(exeCommit.getTotalNum() + ","+ exeCommit.getId());
//			if(exeCommit.getId() == 87 )
//			{
//				for(TestSuite ts: exeCommit.getAllTests())
//					System.out.println(ts.getLast_launchTime() + ":" + ts.getLast_executionTime());
//			}
				
			numOfCommit ++;
			exeCommit = new Commit();
			numOfConcurrent = concurrentMap.get(commitId);
			exeCommit.init(lastTs, failTest, javaTs, isSizeFail, numOfConcurrent, testFails);
			
			// after initialize a new teste suite, update the start percent of time of this commit
//			startPercentTime = accumulateCurrent.getCountExeTime()/this.totalExeTime;
//			exeCommit.setPercentStartTime(startPercentTime);// set the start time for the next commit
			
			
			exeCommit.storeTestsInCommit(lastTs, selectedStage); //add a test suite to the commit
//			accumulateCurrent.counting_all(lastTs, selectedStage); // count the current num and time			
			
			commitId = exeCommit.getId();
		
		}
		
		
		
		
		
	}

	
	public double getAvgCommitDuration()
	{
		avgCommitDuration = allCommitsDuration/(double)numOfCommit;
		
		return avgCommitDuration;
	}

	
	
//	private boolean isF = true;
//	private Timestamp buildStartTime;
//	private Calendar calForFail = Calendar.getInstance();
//	private Timestamp currentTime;
//	private double lastPercent_time = 0;
//	private double expected_time = 0;
//	private double curPercent_time = 0;
////	private double totalTimeLine;
//	private Queue<TestSuite> all = new LinkedList<TestSuite>();
//	public void storeAllCommits2(ReadMatrix matrix, List<Integer> failTest, List<Integer> failCR, ReadFailJavaTs javaTs,TestSuite lastTs, String selectedStage, ExeRecord exeRec, 
//			String alwaysExecutedStage, Map<Integer, boolean[]> isSizeFail, int failWindow, int executionWindow) throws ParseException
//	{
//		
//		//count all test suites
//		this.accumulateAll.counting_all(lastTs, selectedStage);		
//		all.offer(lastTs);
//		
//		System.out.println("xxxxx");
//	}
//////	public void percentTime()
////	{
////		double restTime = this.totalTimeLine;
////		
////		if(selectedStage.equals("pres"))
////			totalTimeLine = 1267801360;
////		else
////			totalTimeLine = 1270800412;
////		buildStartTime = all.poll().getLast_launchTime();
////		calForFail.setTime(new Date(buildStartTime.getTime()));				
////		System.out.println(buildStartTime);
////		
////		currentTime =  new Timestamp(calForFail.getTime().getTime());		 
////		
////		int num = 0;
////		while(!all.isEmpty() || restTime > 0)
////		{
////			curPercent_time = ((double)currentTime.getTime()-(double)buildStartTime.getTime())/totalTimeLine;
////			
////			
//////			System.out.println(all.peek().getLast_launchTime()+ "size"+ all.size());
////			while(!all.isEmpty() && (all.peek().getLast_launchTime().before(currentTime) ||all.peek().getLast_launchTime().equals(currentTime)))
////			{
////				all.poll();
////				num ++;
////			}
////			
////			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
////			{
////	//			System.out.println((int)(expected_time*1000) + ","+ countFailNumber);
////	//			System.out.println((int)(expected_time*1000) + ": commits in the queue " +queue.size() + ": not arriving commits: " + allCommits.size());
////				System.out.println((double)(expected_time*100) + "," + num );
////				num = 0;
////				expected_time += 0.001;				
////			}
////			
////			lastPercent_time = curPercent_time;			
////			//update
////	//		calForFail.setTime(new Date(buildStartTime.getTime()));			
////			calForFail.add(Calendar.MILLISECOND, 1); 
////												
////			currentTime =  new Timestamp(calForFail.getTime().getTime());	
////			restTime --;
////		}
////		
////		System.out.println("restNumber:" + all.size());
////		
////	}
//	
//	
////	public Deque<Commit> getStoreCommit() {
////		return allCommit;
////	}

	public String getSelectedStage() {
		return selectedStage;
	}

	public void setSelectedStage(String selectedStage) {
		this.selectedStage = selectedStage;
	}

	public Accumulation getAccumulateAll() {
		return accumulateAll;
	}

	public void setAccumulateAll(Accumulation accumulateAll) {
		this.accumulateAll = accumulateAll;
	}

	public double getAllCommitsDuration() {
		return allCommitsDuration;
	}

	public void setAllCommitsDuration(double allCommitsDuration) {
		this.allCommitsDuration = allCommitsDuration;
	}

	public PriorityQueue<Commit> getPq() {
		return pq;
	}

	public void setPq(PriorityQueue<Commit> pq) {
		this.pq = pq;
	}

	public Commit getExeCommit() {
		return exeCommit;
	}

	public void setExeCommit(Commit exeCommit) {
		this.exeCommit = exeCommit;
	}
	
	
}
