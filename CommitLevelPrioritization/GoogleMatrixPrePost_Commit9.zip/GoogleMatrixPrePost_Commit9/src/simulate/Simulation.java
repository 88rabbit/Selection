package simulate;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import changeRequest.ReadMatrix;
import databaseInfo.DatabaseInformation;
import exeRecord.ExeRecord;
import exeRecord.RecordCR;
import executeTS.CountFailures;
import executeTS.ExecuteTestSuites;

public class Simulation 
{	
	
	public void simulate(String sql, int failWindow,int executionWindow, String failmmhh,String executemmhh, String selectedStage, 
			int distinctTsNum, String alwaysExecutedStage, int numOfProcessor, ExeRecord exeRec, double rate, boolean isIntra) throws ClassNotFoundException, SQLException, ParseException, FileNotFoundException, IOException
	{	
		
//		int testNum = 0;
//		int fieldNum = 0;
//		int preNum = 0;
//		String Sample = "";
//		try
//		{
//			FileReader fs = new FileReader("../Script/GooglePresCleanData.out"); ;
//			BufferedReader br = new BufferedReader(fs);
//			
//			String temp = br.readLine(); 
////			String testSuite = "";
//			
//			while(temp!=null &&!temp.isEmpty())
//			{
//				testNum++;
//				fieldNum = temp.split(",").length;	
////				System.out.println(temp.split(";")[8]+","+temp.split(";")[1]+","+ temp.split(";")[2]+","+ temp.split(";")[11]);
//				if(fieldNum != preNum)
//					System.out.println(fieldNum+","+preNum);
//				preNum = fieldNum;
//				temp = br.readLine();			
//			}
//			Sample = temp;
//		}		
//		catch(Exception e)
//		{
//			System.out.print(e.toString());
//		}
//		System.out.println(fieldNum);
//		System.out.println(Sample);
//		
		
		//connect database
		DatabaseInformation dbInfo = new DatabaseInformation();
		ResultSet rs = dbInfo.connectDatabase(sql);
			
		//execute TestSuites
		ExecuteTestSuites executeTs = new ExecuteTestSuites(exeRec,numOfProcessor, selectedStage, rate, isIntra);
		executeTs.executeTestSuites(rs, failWindow, executionWindow,failmmhh,executemmhh, selectedStage,distinctTsNum, alwaysExecutedStage, numOfProcessor, rate);
//		executeTs.
		
		//counting numbers of testsuites
		double all_TSnumber = executeTs.getAll_TSnumber();
		double all_failNumber=executeTs.getAll_failNumber();
		double all_ExeTime = executeTs.getAll_ExeTime();
		
		double executed_TSnumber = executeTs.getExecuted_TSnumber();
		double executed_failNumber = executeTs.getExecuted_failNumber();
		double executed_ExeTime = executeTs.getExecuted_ExeTime();
		
		double executed_failTestsTime = executeTs.getSimulateCommitExe().getAccumulateExe().getFailExeTime();
		
		System.out.println("Number of allTestSuites: "+all_TSnumber);
		System.out.println("Number of executedTests: "+executed_TSnumber);
		System.out.println("allExeTime: "+all_ExeTime);
		System.out.println("executedTSTime: "+executed_ExeTime);
		System.out.println("executed fail tests time: " + executed_failTestsTime);
		System.out.println("allFailTests: "+ all_failNumber);
		System.out.println("failTests: "+ executed_failNumber);
		System.out.println("all commits: " + executeTs.getSimulateCommitExe().getTotalNumOfCommits());
		System.out.println("fail commits detected: " + executeTs.getSimulateCommitExe().getDetectedFailCommits());
		System.out.println();
//		
//		double percentOfSelectedTS = executed_TSnumber/all_TSnumber;
//		System.out.println("Percentage of test suites selected is: "+percentOfSelectedTS*100);
//		float percentOfExeTime = (float)executed_ExeTime/(float)all_ExeTime;
//		System.out.println("Percentage of execution time is: "+ percentOfExeTime*100);
//		double percentOfFailDetected = executed_failNumber/all_failNumber;
//		System.out.println("Percentage of failure detected is: " + percentOfFailDetected*100);
////		System.out.println("Percentage of failureCommit detected is: " + (float)((double)executeTs.getSelectTests().getFailCommits()/(double)1323)*100);
//		System.out.println();
//		
//		
//		System.out.println(percentOfSelectedTS*100);	
//		System.out.println(percentOfExeTime*100);
//		System.out.println(percentOfFailDetected*100);
//		System.out.println((float)((double)executeTs.getSelectTests().getFailCommits()/(double)1323)*100);
//		
//		System.out.println();
//		System.out.println((float)executed_ExeTime/(float)executed_TSnumber);
//		
////		//FOR OLD CombineCommits class
////		System.out.println("total number of commits = " + executeTs.getCombineCommits().getNumOfCommit());
////		System.out.println("executed number of commits = " + executeTs.getCombineCommits().getExeNumOfCommit());
////		System.out.println("% of executed commits = " + 100*executeTs.getCombineCommits().getExeNumOfCommit()/executeTs.getCombineCommits().getNumOfCommit());
////		System.out.println("total number of failing commits = " +  executeTs.getCombineCommits().getFailCommits());
////		System.out.println("number of detected failing commits = " + executeTs.getCombineCommits().getDetectedFailCommits());
//		
//		//FOR SimulateCommitsExecution method
//		System.out.println("total number of commits = " + executeTs.getSimulateCommitExe().getTotalNumOfCommits());
//		System.out.println("executed number of commits = " + executeTs.getSimulateCommitExe().getNumOfCommitExe());
//		System.out.println("% of executed commits = " + 100*executeTs.getSimulateCommitExe().getNumOfCommitExe()/executeTs.getSimulateCommitExe().getTotalNumOfCommits());
//		System.out.println("total number of failing commits = " +  executeTs.getSimulateCommitExe().getFailCommits());
//		System.out.println("number of detected failing commits = " + executeTs.getSimulateCommitExe().getDetectedFailCommits());
//		
//		System.out.println();
//		double ftoal = executeTs.getFtotal();
//		double apfd = 1-(ftoal/(double)(all_failNumber*all_TSnumber)) + 1/(double)(2*all_TSnumber);
//		System.out.println("ts count based apfd: "+ apfd);
//		
		/*
		 * Number commits apfd
		 */
//		double ftotalCommit = executeTs.getSimulateCommitExe().getCommitFailApfd();
//		double allFailCommits = (double)executeTs.getSimulateCommitExe().getDetectedFailCommits();
//		double totalCommits = (double)executeTs.getSimulateCommitExe().getNumOfCommitExe();
////		System.out.println(ftotalCommit);
//		double apfdCommits =  1-(ftotalCommit/(double)(allFailCommits*totalCommits)) + 1/(double)(2*totalCommits);
//		System.out.println("Commit count based apfd: "+ apfdCommits);
////		System.out.println(apfdCommits);
////		System.out.println();
		
		
		
		double totalCommitsTime = 0;
		if(selectedStage.equals("pres"))
			totalCommitsTime = (double)1906241540.00/(double)(1000*60*60);
		else 
			totalCommitsTime = (double)4192794408.00/(double)(1000*60*60);
		
//		double totalTsExeTime = executed_ExeTime/(double)(1000*60*60);
		double allFailTestNum = executed_failNumber;
		
//			
//		
//		
		double ftotalTestTime = executeTs.getSimulateCommitExe().getAccumulateExe().getFtotal_exeTime();
//		double allFailCommitsNum = (double)executeTs.getSimulateCommitExe().getDetectedFailCommits();
		System.out.println("ftotalTestTime: " + ftotalTestTime);
//		System.out.println("totalCommitsTime:" + totalTsExeTime);
//		apfdCommits =  1-(totalCommitsTime/(double)(allFailCommits*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
		double apfdTestCost =  1-(ftotalTestTime/(double)(allFailTestNum*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
		System.out.println("Tests Time based apfd: "+ apfdTestCost);
//		System.out.println(apfdCommitsCost);
		System.out.println();
		
		
		
		
		
		
		/*
		 * time commits apfd
		 */
////		double 
//		double totalCommitsTime = 0;
//		if(selectedStage.equals("pres"))
//			totalCommitsTime = (double)1906241540.00/(double)(1000*60*60);
//		else 
//			totalCommitsTime = (double)2218688377.00/(double)(1000*60*60);
//			
//		double totalCommitsTime = (double)executeTs.getTotalTimeLine()/(double)(1000*60*60);
//		
		double ftotalCommitTime = executeTs.getSimulateCommitExe().getfApfd();
		double allFailCommitsNum = (double)executeTs.getSimulateCommitExe().getDetectedFailCommits();
		System.out.println("ftotalCommitTime: " + ftotalCommitTime);
		System.out.println("totalCommitsTime:" + totalCommitsTime);
//		apfdCommits =  1-(totalCommitsTime/(double)(allFailCommits*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
		double apfdCommitsCost =  1-(ftotalCommitTime/(double)(allFailCommitsNum*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
		System.out.println("Commit Time based apfd: "+ apfdCommitsCost);
//		System.out.println(apfdCommitsCost);
		System.out.println();
		
		System.out.println("ftotalCommitTime: " + (double)(ftotalCommitTime*60*60));
		System.out.println("totalCommitsTime:" + (double)(totalCommitsTime*60*60));
		
		
		
//		
//		XSSFWorkbook workbook = new XSSFWorkbook();
//        XSSFSheet sheet = workbook.createSheet("Java Books");
//         
//        Object[][] bookData = {
//                {"Head First Java", "Kathy Serria", 79},
//                {"Effective Java", "Joshua Bloch", 36},
//                {"Clean Code", "Robert martin", 42},
//                {"Thinking in Java", "Bruce Eckel", 35},
//        };
// 
//        int rowCount = 0;
//         
//        for (Object[] aBook : bookData) {
//            Row row = sheet.createRow(++rowCount);
//             
//            int columnCount = 0;
//             
//            for (Object field : aBook) {
//                Cell cell = row.createCell(++columnCount);
//                if (field instanceof String) {
//                    cell.setCellValue((String) field);
//                } else if (field instanceof Integer) {
//                    cell.setCellValue((Integer) field);
//                }
//            }
//             
//        }
//         
//         
//        try (FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx")) {
//            workbook.write(outputStream);
//        }
//		
//		
		
		
		
		
		
		
		
		
//		double percentOfSelectedTS = executed_TSnumber/all_TSnumber;
//		float percentOfExeTime = (float)executed_ExeTime/(float)all_ExeTime;
//		double percentOfFailDetected = executed_failNumber/all_failNumber;	
//		double ftoal = executeTs.getFtotal();
//		double apfd = 1-(ftoal/(double)(all_failNumber*all_TSnumber)) + 1/(double)(2*all_TSnumber);		
//		double ftotalCommit = executeTs.getCombineCommits().getCommitFailApfd();
//		double allFailCommits = (double)executeTs.getCombineCommits().getDetectedFailCommits();
//		double totalCommits = (double)executeTs.getCombineCommits().getExeNumOfCommit();		
//		double apfdCommits =  1-(ftotalCommit/(double)(allFailCommits*totalCommits)) + 1/(double)(2*totalCommits);
//		
//		System.out.println(apfdCommits);
		
//		System.out.println();
//		System.out.println();
		
		
		
		
		
		
		
		
		
		
		
		
//		System.out.println("allExeTime: "+all_ExeTime);
//		System.out.println("executedTSTime: "+executed_ExeTime);
		
//		System.out.println();		
//		double allFailExeTime = executeTs.getAllFailExeTime();
//		double ftoal_exeTime = executeTs.getFtotal_exeTime();
//		double apfd_exeTime = 1-(ftoal_exeTime/(double)(allFailExeTime*all_ExeTime)) + 1/(double)(2*all_ExeTime);
//		System.out.println("ts exetime based apfd: "+ apfd_exeTime);
//		System.out.println(allFailExeTime);
//		System.out.println((double)(allFailExeTime*all_ExeTime));
//		System.out.println((double)(ftoal_exeTime));
		
//		exeRec = executeTs.getExeRec();
//		System.out.println();
//		Map<Integer, Double> map =new TreeMap<Integer, Double>(executeTs.getMap());
//					
//		//for ts
//		for(Integer i: map.keySet())
//		{
////			System.out.println(i + ","+ map.get(i));
//			System.out.println( map.get(i));
//		}
//		
//		CountFailures cf = executeTs.getCombineCommits().getCf();
//		
//		System.out.println(cf.getWithinFail() + "," + cf.getOutExe() + "," + cf.getSkip());
		
		
		
		/*
		 * 
		 */
//		System.out.println(executeTs.getSelectTests().getNumOfRepetive());
//		Map<Integer, Integer> map = executeTs.getSelectTests().getRepCommit();
//		for(Integer i: map.keySet())
//		{
//			System.out.println(i);
//		}
		
		
		
//		//***************** for differnt language and corresponding small/medum/large test suites
//		System.out.println("BORGCFG"+ "," + executeTs.getSelectTests().getBORGCFG()[0] +"," + executeTs.getSelectTests().getBORGCFG()[1] +","+ executeTs.getSelectTests().getBORGCFG()[2]);
//		System.out.println("CC"+ "," + executeTs.getSelectTests().getCC()[0] +"," + executeTs.getSelectTests().getCC()[1] +","+ executeTs.getSelectTests().getCC()[2]);
//		System.out.println("WEB"+ "," + executeTs.getSelectTests().getWEB()[0] +"," + executeTs.getSelectTests().getWEB()[1] +"," + executeTs.getSelectTests().getWEB()[2]);
//		System.out.println("JAVA"+ "," + executeTs.getSelectTests().getJAVA()[0] + "," + executeTs.getSelectTests().getJAVA()[1] + "," +executeTs.getSelectTests().getJAVA()[2]);
//		System.out.println("GWT"+ "," + executeTs.getSelectTests().getGWT()[0] + "," + executeTs.getSelectTests().getGWT()[1] +","+ executeTs.getSelectTests().getGWT()[2]);
//		System.out.println("PY"+ "," + executeTs.getSelectTests().getPY()[0] +","+ executeTs.getSelectTests().getPY()[1] +","+ executeTs.getSelectTests().getPY()[2]);
//		System.out.println("SH"+ "," + executeTs.getSelectTests().getSH()[0] +","+ executeTs.getSelectTests().getSH()[1] +","+ executeTs.getSelectTests().getSH()[2]);
//		System.out.println("GO"+ "," + executeTs.getSelectTests().getGO()[0] +","+ executeTs.getSelectTests().getGO()[1] +","+ executeTs.getSelectTests().getGO()[2]);
//		
//		System.out.println(executeTs.getSelectTests().getB());
//		System.out.println(executeTs.getSelectTests().getCc());
//		System.out.println(executeTs.getSelectTests().getWeb());
//		System.out.println(executeTs.getSelectTests().getJava());
//		System.out.println(executeTs.getSelectTests().getGwt());
//		System.out.println(executeTs.getSelectTests().getPy());
//		System.out.println(executeTs.getSelectTests().getSh());
//		System.out.println(executeTs.getSelectTests().getGo());
//		
		
		//*************************
		
//		ReadMatrix readMatrix = new ReadMatrix();		
//		double[][] matrix = readMatrix.getMatrix();
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				System.out.print(matrix[i][j] + ",");
//			}
//			System.out.println();
//		}
//		
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		System.out.println(executeTs.getExeRec().getCrn());
//		System.out.println(executeTs.getExeRec().getSetCR().size());
//		
//		System.out.println();
//		for(Integer cr: executeTs.getExeRec().getSetCR() )
//		{
//			System.out.println(cr);
//		}
		
//		for(int i=0; i<3841; i++)
//		{
//			System.out.println("changeR="+executeTs.getExeRec().getAllcr().getRecordCR()[i].getCr()+":");
////			System.out.println("aaaaaa");
//			for(int j=0; j<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); j++)
//			{
//				System.out.println(" testId  "+executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j)+","+executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(j)+";");
//			}
//		}
//		
//		int totalPairs = 0;
//		int samePairs = 0;
//		int samePairsWithDifferentResult = 0;
////		
//		//to record each change request' repetive test suite id's status
//		Set<Integer> CRDiffResult = new HashSet<Integer>();
//		
//		List<Integer> failList = executeTs.getExeRec().getFailList();
//		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
//		int[] fl = new int[failList.size()]; //287
//		for(int i=0; i<failList.size(); i++)
//		{
//			fl[i] = failList.get(i);
//			map.put(fl[i], i); //get the position(i) by using the test suite id(fl[i])
//			System.out.print(fl[i] + ",");
//		}
//		System.out.println();
//		System.out.println(fl.length);
		
//		
//		System.out.println("************************** Each Change request contains how many small/median/large test suites**************");
//		
//		RecordCR eachCR;
//		int small = 0;
//		int medium = 0;
//		int large = 0;
//		
//		int totalFail =0;
//		for(int i=0; i<3841; i++)//for each request
//		{
//			eachCR = executeTs.getExeRec().getAllcr().getRecordCR()[i];
////			//first is total, second is fail number 
////			System.out.println(eachCR.getSmallSize()[0] + ", "+ eachCR.getSmallSize()[1] + ", "
////					+ eachCR.getMedianSize()[0] + ", "+ eachCR.getMedianSize()[1] + ", "
////							+ eachCR.getLargeSize()[0] + ", "+ eachCR.getLargeSize()[1]);
//			if(eachCR.getSmallSize()[1]>0 ||eachCR.getMedianSize()[1]>0 || eachCR.getLargeSize()[1]>0)
//			{
//				totalFail++;
//			}
//			
//			if(eachCR.getSmallSize()[1]>0)
//			{
//				System.out.print("1, ");
//				small ++;
//			}
//			else 
//			{
//				System.out.print("0, ");
//			}
//			
//			if(eachCR.getMedianSize()[1]>0)
//			{
//				System.out.print("1, ");
//				medium ++;
//			}
//			else 
//			{
//				System.out.print("0, ");
//			}
//			
//			if(eachCR.getLargeSize()[1]>0)
//			{
//				System.out.print("1, ");
//				large ++;
//			}
//			else 
//			{
//				System.out.print("0, ");
//			}
//				
//			
//			
////			System.out.println(eachCR.getCr());
//			
//		}
//		System.out.println();
//		
//		System.out.println(small + "  small test suites in cr detect failures");
//		System.out.println(medium + " medium test suites in  cr detect failures");
//		System.out.println(large + " large test suites in  cr detect failures");
//		System.out.println("total: " + totalFail);
//		
//		
//		int sm = 0;
//		int sl = 0;
//		int ml = 0;
//		int sml = 0;
//		
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			eachCR = executeTs.getExeRec().getAllcr().getRecordCR()[i];
////			//first is total, second is fail number 
////			System.out.println(eachCR.getSmallSize()[0] + ", "+ eachCR.getSmallSize()[1] + ", "
////					+ eachCR.getMedianSize()[0] + ", "+ eachCR.getMedianSize()[1] + ", "
////							+ eachCR.getLargeSize()[0] + ", "+ eachCR.getLargeSize()[1]);
//			
//			if(eachCR.getSmallSize()[1]>0 && eachCR.getMedianSize()[1]>0)
//			{
//				sm ++;
//			}
//			
//			
//			if(eachCR.getMedianSize()[1]>0 && eachCR.getLargeSize()[1]>0)
//			{
//				ml ++;
//			}
//			
//			if(eachCR.getSmallSize()[1]>0 && eachCR.getLargeSize()[1]>0)
//			{
//				sl ++;
//			}
//		
//			if(eachCR.getSmallSize()[1]>0 && eachCR.getMedianSize()[1]>0 && eachCR.getLargeSize()[1]>0)
//			{
//				sml ++;
//			}
//				
//			
//			
////			System.out.println(eachCR.getCr());
//			
//		}
//		System.out.println();
//		System.out.println(sm + " commits, small and medium both fail");
//		System.out.println(ml + " commits, medium and large both fail");
//		System.out.println(sl + " commits, small and large both fail");
//		System.out.println(sml + " commits, small, medium and large all fail");
//		
//		
//		int sm_all = 0;
//		int sl_all = 0;
//		int ml_all = 0;
//		int sml_all = 0;
//		
//		int sNm = 0;
//		int mNs = 0;
//		int mNl = 0;
//		int lNm = 0;
//		int sNl = 0;
//		int lNs =0;
//		
//		int sNml = 0;
//		int mNsl = 0;
//		int lNsm = 0;
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			eachCR = executeTs.getExeRec().getAllcr().getRecordCR()[i];
////			//first is total, second is fail number 
////			System.out.println(eachCR.getSmallSize()[0] + ", "+ eachCR.getSmallSize()[1] + ", "
////					+ eachCR.getMedianSize()[0] + ", "+ eachCR.getMedianSize()[1] + ", "
////							+ eachCR.getLargeSize()[0] + ", "+ eachCR.getLargeSize()[1]);
//			
//			if(eachCR.getSmallSize()[0]>0 && eachCR.getMedianSize()[0]>0)
//			{
//				if(eachCR.getSmallSize()[1]>0 && eachCR.getMedianSize()[1]==0)
//				{
//					sNm ++;
//				}
//				if(eachCR.getSmallSize()[1]==0 && eachCR.getMedianSize()[1]>0)
//				{
//					mNs ++;
//				}
//				
//				sm_all ++;
//			}
//			
//			
//			if(eachCR.getMedianSize()[0]>0 && eachCR.getLargeSize()[0]>0)
//			{
//				if(eachCR.getMedianSize()[1]>0 && eachCR.getLargeSize()[1]==0)
//				{
//					mNl ++;
//				}
//				if(eachCR.getMedianSize()[1]==0 && eachCR.getLargeSize()[1]>0)
//				{
//					lNm ++;
//				}
//				
//				ml_all ++;
//			}
//			
//			if(eachCR.getSmallSize()[0]>0 && eachCR.getLargeSize()[0]>0)
//			{
//				if(eachCR.getSmallSize()[1]>0 && eachCR.getLargeSize()[1]==0)
//				{
//					sNl ++;
//				}
//				if(eachCR.getSmallSize()[1]==0 && eachCR.getLargeSize()[1]>0)
//				{
//					lNs ++;
//				}
//				sl_all ++;
//			}
//		
//			if(eachCR.getSmallSize()[0]>0 && eachCR.getMedianSize()[0]>0 && eachCR.getLargeSize()[0]>0)
//			{
//				if(eachCR.getSmallSize()[1]>0 && eachCR.getMedianSize()[1]==0 && eachCR.getLargeSize()[1]==0)
//				{
//					sNml ++;
//				}
//				
//				if(eachCR.getSmallSize()[1]==0 && eachCR.getMedianSize()[1]>0 && eachCR.getLargeSize()[1]==0)
//				{
//					mNsl ++;
//				}
//				
//				if(eachCR.getSmallSize()[1]==0 && eachCR.getMedianSize()[1]==0 && eachCR.getLargeSize()[1]>0)
//				{
//					lNsm ++;
//				}
//				
//				sml_all ++;
//			}
//				
//			
//			
////			System.out.println(eachCR.getCr());
//			
//		}
//		System.out.println();
//		System.out.println(sm_all + " commits, small and medium both in the same commit");
//		System.out.println(ml_all + " commits, medium and large both in the same commit");
//		System.out.println(sl_all + " commits, small and large both in the same commit");
//		System.out.println(sml_all + " commits, small, medium and large all in the same commit");
//		System.out.println();
//		System.out.println(sNm + "commits, small and medium both exists, but s detects fail, m not");
//		System.out.println(mNs + "commits, small and medium both exists, but m detects fail, s not");
//		System.out.println(mNl + "commits, medium and large both exists, but m detects fail, l not");
//		System.out.println(lNm + "commits, medium and large both exists, but l detects fail, m not");
//		System.out.println(sNl + "commits, small and large both exists, but s detects fail, l not");
//		System.out.println(lNs + "commits, small and large both exists, but l detects fail, s not");
//		System.out.println();
//		System.out.println(sNml + " commits, all three exists, only s detects");
//		System.out.println(mNsl + " commits, all three exists, only m detects");
//		System.out.println(lNsm + " commits, all three exists, only l detects");
//		System.out.println();
//		
//		
//		int totalS = 0;
//		int totalM = 0;
//		int totalL = 0;
//		
//		int failS = 0;
//		int failM = 0;
//		int failL = 0;
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			eachCR = executeTs.getExeRec().getAllcr().getRecordCR()[i];
//			if(eachCR.getSmallSize()[0]>0 && eachCR.getMedianSize()[0]>0 && eachCR.getLargeSize()[0]>0) //commits that contain all three types
//			{
//				totalS += eachCR.getSmallSize()[0];
//				totalM += eachCR.getMedianSize()[0];
//				totalL += eachCR.getLargeSize()[0];
//				
//				failS += eachCR.getSmallSize()[1];
//				failM += eachCR.getMedianSize()[1];
//				failL += eachCR.getLargeSize()[1];
//				
//			}
//			
//		}
//		
//		System.out.println(totalS + " Small test suites in total");
//		System.out.println(totalM + " Medium test suites in total");
//		System.out.println(totalL + " Large test suites in total");
//		System.out.println(failS + " Small \"fail\" test suites in total");
//		System.out.println(failM + " Medium \"fail\" test suites in total");
//		System.out.println(failL + " Large \"fail\" test suites in total");
//		
//		
//		
//		
//		/*
//		 * This part is to calculate large/medium/small test suites in 6000 commits
//		 * 
//		 */
//		
//		int[] totalLarge = executeTs.getExeRec().getTotalLarge(); // first record total, second record total fail
//		int[] totalMedium = executeTs.getExeRec().getTotalMedium();
//		int[] totalSmall = executeTs.getExeRec().getTotalSmall();
//		
//		long largeTime = executeTs.getExeRec().getLargeTime();
//		long mediumTime = executeTs.getExeRec().getMediumTime();
//		long smallTime = executeTs.getExeRec().getSmallTime();
//		
//		System.out.println("largeSize total: " + totalLarge[0] + "; largeSize fail: " + totalLarge[1] + "; largeTime: "+ largeTime); //milisecond
//		System.out.println("mediumSize total: " + totalMedium[0] + "; mediumSize fail: " + totalMedium[1] + "; mediumTime: " + mediumTime);
//		System.out.println("smallSize total: " + totalSmall[0] + "; smallSize fail: " + totalSmall[1] + "; smallTime: " + smallTime);
		
		
		
		
		
		
		
//		int lNs =0;
//		
////		
////		
//		System.out.println("********************Total**************************");
//		
//		/*
//		 * Total execution number in the matrix
//		 */
//		
//		double[][] matrix = new double[287][287];
//		
//		for(int i=0; i<287; i++) //initialize the matrix
//		{
//			for(int j=0; j<287; j++)
//			{
//				matrix[i][j]=0;
//			}
//		}
//		
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			for(int j=0; j<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); j++)//each distinct CR contains a list of test suit ids and their corresponding status
//			{
//				for(int k=0; k<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); k++)
//				{					
////					System.out.println(map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j)));
////					System.out.println(map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)));
//					if(j!=k && map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))==map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)))
//					{
//						//the same tsId appears more than one time in a change request
//						matrix[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))] += 0.5;
//						samePairs++;
//						if(executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(j)!=executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(k))
//						{
//							samePairsWithDifferentResult++;
//							CRDiffResult.add(executeTs.getExeRec().getAllcr().getRecordCR()[i].getCr());
//						}
//					}
//					else
//					{
//						totalPairs++;
//						matrix[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))]++;
//					}					
//				}
//			}
//		}
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				System.out.print(matrix[i][j] + ",");				
//			}
//			System.out.println();
//		}
//		
////		
////		
////		
////		System.out.println("******************** Both fail *****************");
////		System.out.println();
////		
////		
////		/*
////		 *  Both Fail in the matrix
////		 */
//		//for fail
//		double[][] matrix2 = new double[287][287];
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				matrix2[i][j]=0;
//			}
//		}
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			for(int j=0; j<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); j++)
//			{
//				for(int k=0; k<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); k++)
//				{								
//					if(executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(j)==0 && executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(k)==0)
//					{
//						if(j!=k && map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))==map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)))
//						{
//							//the same tsId appears more than one time
//							matrix2[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))] += 0.5;
//						}
//						else
//						{
//							matrix2[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))]++;
//						}
//						
//					}
//					
//				}
//			}
//		}
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				System.out.print(matrix2[i][j] + ",");
//				
//			}
//			System.out.println();
//		}
	
//		/*
//		 * Calulate the matrix2/matrix1
//		 */
//		System.out.println("************************ ff/total ****************");
//		System.out.println();
//		
//		float[][] matrix3 = new float[287][287];
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				if(matrix[i][j]==0)
//				{
//					System.out.print("NaN"+",");
//				}
//				else
//				{
//					System.out.print((float)((float)matrix2[i][j]/(float)matrix[i][j])+",");
//				}
//				
//			}
//			System.out.println();
//		}
//		
//		
//		/*
//		 * Each column is fail, each row is pass in the matrix x_p y_f
//		 */
//		System.out.println();
//		System.out.println("********************x_p y_f******************");
//		
//	
//		//for fail
//		double[][] matrix4 = new double[287][287];
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				matrix4[i][j]=0;
//			}
//		}
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			for(int j=0; j<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); j++)
//			{
//				for(int k=0; k<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); k++)
//				{					
//					if(executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(j)==1 && executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(k)==0)
//					{
//						if(j!=k && map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))==map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)))
//						{
//							//the same tsId appears more than one time
//							matrix4[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))] ++;
//						}
//						else
//						{
//							matrix4[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))]++;
//						}
//						
//					}
//					
//				}
//			}
//		}
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				System.out.print(matrix4[i][j] + ",");
//				
//			}
//			System.out.println();
//		}
//		
//		
//
//		/*
//		 * Each row is fail, each column is pass in the matrix  x_f y_p
//		 */
//		System.out.println();
//		System.out.println("********************x_f y_p");
//		
		//for fail
//		double[][] matrix5 = new double[287][287];
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				matrix5[i][j]=0;
//			}
//		}
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			for(int j=0; j<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); j++)
//			{
//				for(int k=0; k<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); k++)
//				{					
////					System.out.println(map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j)));
////					System.out.println(map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)));
//					if(executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(j)==0 && executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(k)==1)
//					{
//						if(j!=k && map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))==map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)))
//						{
//							//the same tsId appears more than one time
//							matrix5[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))] ++;
//						}
//						else
//						{
//							matrix5[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))]++;
//					
//						}
//					}
//					
//				}
//			}
//		}
////		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				System.out.print(matrix5[i][j] + ",");
//			}
//			System.out.println();
//		}
////		
//		
//		/*
//		 * using matrix 2, 4 to calculate a new matrix
//		 */
//		System.out.println();
//		System.out.println("************************ff / x_p y_f + ff");
//		
////		float[][] matrix3 = new float[287][287];
//		
//		float result = 0;
//		int count = 0;
//		
//		for(int i=0; i<287; i++)
//		{
////			System.out.println(map.ge);
//			for(int j=0; j<287; j++)
//			{				
//				if(((float)matrix4[i][j]+(float)matrix2[i][j])!=0)
//				{
//					result = result + (((float)matrix2[i][j])/((float)matrix4[i][j]+(float)matrix2[i][j]));
//					count ++;
//					System.out.print((((float)matrix2[i][j])/((float)matrix4[i][j]+(float)matrix2[i][j]))+",");//right up area
//				}
//				else
//				{
//					System.out.print("NaN"+",");
//				}			
//			}
//			System.out.println();
//		}
//		
//		System.out.println();
//		System.out.println(result/(float)count);
//		
//		/*
//		 * using matrix 2, 5 to calculate a new matrix
//		 */
//		System.out.println();
//		System.out.println("************************ff / x_f y_p + ff");
//		
////		float[][] matrix3 = new float[287][287];
//		
//		Map<Integer, String> failTestLanguage = executeTs.getExeRec().getFailTestLanguage();
////		Iterator it2 = failTestLanguage.entrySet().iterator();
//		
//		for(int i=0; i<287; i++)
//		{
////			System.out.println(map.ge);
//			for(int j=0; j<287; j++)
//			{				
//				if(((float)matrix5[i][j]+(float)matrix2[i][j])!=0)
//				{
//					System.out.print((((float)matrix2[i][j])/((float)matrix5[i][j]+(float)matrix2[i][j]))+",");//right up area
//				}
//				else
//				{
//					System.out.print("NaN"+",");
//				}			
//			}
//			System.out.println();
////		}
//		
////		
//		
//		
//		
//		/*
//		 * all pass
//		 */
//		System.out.println();
//		System.out.println("********************all pass *****************");
//		
//		//for fail
//		double[][] matrix6 = new double[287][287];
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				matrix6[i][j]=0;
//			}
//		}
//		
//		for(int i=0; i<3841; i++)//for each request
//		{
//			for(int j=0; j<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); j++)
//			{
//				for(int k=0; k<executeTs.getExeRec().getAllcr().getRecordCR()[i].getSize(); k++)
//				{					
////					System.out.println(map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j)));
////					System.out.println(map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)));
//					if(executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(j)==1 && executeTs.getExeRec().getAllcr().getRecordCR()[i].getPf().get(k)==1)
//					{
//						if(j!=k && map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))==map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k)))
//						{
//							//the same tsId appears more than one time
//							matrix6[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))] += 0.5;
//						}
//						else
//						{
//							matrix6[map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(j))][map.get(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().get(k))]++;					
//						}
//					}					
//				}
//			}
//		}
//		
//		for(int i=0; i<287; i++)
//		{
//			for(int j=0; j<287; j++)
//			{
//				System.out.print(matrix6[i][j] + ",");
//			}
//			System.out.println();
//		}
//		
//		
//		System.out.println();
//		System.out.println("*************************");
//		int numCR=0;
//		for(int i=0; i<3841; i++)//for each request
//		{
//			if(executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsId().size() 
//					!= executeTs.getExeRec().getAllcr().getRecordCR()[i].getTsIdUnique().size())
//			{
//				numCR++;
//				System.out.println(executeTs.getExeRec().getAllcr().getRecordCR()[i].getCr());
//			}
//		}
//		System.out.println("***************");
//		System.out.println("Repetive number of CR = " + numCR);
//		System.out.println("Repetive % of CR = " + (float)numCR/(float)3841);
//		
//		System.out.println("total pairs = " + (long)totalPairs/2);
//		System.out.println("same testID pairs = " + (float)samePairs/2);
//		System.out.println("same testID pairs with different result = " + (float)samePairsWithDifferentResult/2);
//		
//		
//		Map<Integer, String> failTsSize = executeTs.getExeRec().getFailTsSize();
//	
//		int large = 0;
//		int medium = 0;
//		int small = 0;
//		Iterator it = failTsSize.entrySet().iterator();
//	    while (it.hasNext()) {
//	        Map.Entry pair = (Map.Entry)it.next();
////	        System.out.println(pair.getKey() + " = " + pair.getValue());
////	        System.out.println(pair.getValue());
//	        if(pair.getValue().equals("LARGE"))
//	        	large ++;
//	        else if(pair.getValue().equals("MEDIUM"))
//	        	medium ++;
//	        else if(pair.getValue().equals("SMALL"))
//	        	small ++;
//	    }
//	    
//	    System.out.println("large= "+ large);
//	    System.out.println("medium= "+ medium);
//	    System.out.println("small= "+ small);
//		
//	    System.out.println();;
//		System.out.println("number of change requests that contains different repetive test suites = "+CRDiffResult.size());
//		
//		Map<Integer, String> failTestName = executeTs.getExeRec().getFailTestName();
//		Iterator it2 = failTestName.entrySet().iterator();
//		while(it2.hasNext())
//		{
//			Map.Entry pair2 = (Map.Entry)it2.next();
////			System.out.println(pair2.getKey());
//			System.out.println(pair2.getValue());
//		}
//		
		
//		System.out.println(executeTs.getExeRec().getExeNum());
			
		
//		Map<Integer, String> failTestLanguage = executeTs.getExeRec().getFailTestLanguage();
//		Iterator it2 = failTestLanguage.entrySet().iterator();
//		while(it2.hasNext())
//		{
//			Map.Entry pair2 = (Map.Entry)it2.next();
////			System.out.println(pair2.getKey());
//			System.out.println(pair2.getValue());
//		}
//		
//		Map<Integer, Integer> map2 = new HashMap<Integer, Integer>();
//		int[] fl1 = new int[failList.size()]; //287
//		for(int i=0; i<failList.size(); i++)
//		{
//			fl1[i] = failList.get(i);
//			map2.put(i, fl1[i]); //get the position(i) by using the test suite id(fl[i])
////			System.out.print(fl1[i] + ",");
//		}
//		System.out.println();
//		
//		
//		Map<Integer, String> failTestLanguage = executeTs.getExeRec().getFailTestLanguage();
////		Iterator it2 = failTestLanguage.entrySet().iterator();
//		
//		float[][] matrixLan = new float[287][287];
//		for(int i=0; i<287; i++)
//		{
////			System.out.println(map.ge);
//			for(int j=0; j<287; j++)
//			{				
//				if(((float)matrix5[i][j]+(float)matrix2[i][j])!=0)
//				{
//					matrixLan[i][j] = ((float)matrix2[i][j])/((float)matrix5[i][j]+(float)matrix2[i][j]);
////					System.out.print((((float)matrix2[i][j])/((float)matrix5[i][j]+(float)matrix2[i][j]))+",");//right up area
//				}
//				else
//				{
//					matrixLan[i][j] = -1;
////					System.out.print("NaN"+",");
//				}			
//			}
//			System.out.println();
//		}
//		
//		float sameLanPs = 0;
//		float sameLanNums = 0;
//		
//		float diffLanPs = 0;
//		float diffLanNums = 0;
//		
//		Map<String, Float> lanSameP = new HashMap<String, Float>();
//		Map<String, Float> lanSameNum = new HashMap<String, Float>(); // each language to itself
//		
//		Map<String, Double> lanDiffP = new HashMap<String, Double>();
//		Map<String, Double> lanDiffNum = new HashMap<String, Double>(); // each language to itself
//		
//		
//		for(int i=0; i<287; i++)
//		{
////			System.out.println(map.ge);
//			for(int j=0; j<287; j++)
//			{	
//				if(failTestLanguage.get(map2.get(i)).equals(failTestLanguage.get(map2.get(j))))
//				{
////					if(matrixLan[i][j] > 0.5)
//					{
//						if(!lanSameP.containsKey(failTestLanguage.get(map2.get(i))))
//						{
//							lanSameP.put(failTestLanguage.get(map2.get(i)), (float) matrixLan[i][j]);
//							lanSameNum.put(failTestLanguage.get(map2.get(i)), (float) 1);
//						}
//						else
//						{
//							lanSameP.put(failTestLanguage.get(map2.get(i)), lanSameP.get(failTestLanguage.get(map2.get(i)))+matrixLan[i][j]);
//							lanSameNum.put(failTestLanguage.get(map2.get(i)), lanSameNum.get(failTestLanguage.get(map2.get(i)))+1);
//						}
//					}
//							
//				}
//				else
//				{
////					if(matrixLan[i][j] > 0.5)
//					{
//						if(!lanDiffP.containsKey(failTestLanguage.get(map2.get(i))))
//						{
//							lanDiffP.put(failTestLanguage.get(map2.get(i)), (double) matrixLan[i][j]);
//							lanDiffNum.put(failTestLanguage.get(map2.get(i)), (double) 1);
//						}
//						else
//						{
//							lanDiffP.put(failTestLanguage.get(map2.get(i)), lanDiffP.get(failTestLanguage.get(map2.get(i)))+matrixLan[i][j]);
//							lanDiffNum.put(failTestLanguage.get(map2.get(i)), lanDiffNum.get(failTestLanguage.get(map2.get(i)))+1);
//						}
//					}
//				}
//				
//				
//				
//				// for calculating all language: same to same; and diff
//				if(failTestLanguage.get(map2.get(i)).equals(failTestLanguage.get(map2.get(j))))
//				{
//					if(matrixLan[i][j] >=0)
//					{
//						sameLanPs += matrixLan[i][j];
//						sameLanNums ++;
//					}
//				}
//				else
//				{
//					if(matrixLan[i][j] >= 0)
//					{
//						diffLanPs += matrixLan[i][j];
//						diffLanNums ++;
//					}
//				}
//				
//			}
//		}
//		
//		System.out.println("The same language test suites average P is: " + (sameLanPs/sameLanNums)*100);
//		System.out.println("The different language test suites average P is: " + (diffLanPs/diffLanNums)*100);
//		
//		
//		System.out.println();
//		
//		Iterator it2 = lanSameP.entrySet().iterator();
//		while(it2.hasNext())
//		{
//			Map.Entry pair2 = (Map.Entry)it2.next();
////			System.out.print(pair2.getKey());
//			System.out.println(pair2.getValue());
//		}
//		
//		System.out.println();
//		
//		Iterator it3 = lanSameNum.entrySet().iterator();
//		while(it3.hasNext())
//		{
//			Map.Entry pair2 = (Map.Entry)it3.next();
////			System.out.print(pair2.getKey());
//			System.out.println(pair2.getValue());
//		}
//		System.out.println();
//		
//		Iterator it4 = lanDiffP.entrySet().iterator();
//		while(it4.hasNext())
//		{
//			Map.Entry pair2 = (Map.Entry)it4.next();
////			System.out.print(pair2.getKey());
//			System.out.println(pair2.getValue());
//		}
//		System.out.println();
//		
//		Iterator it5 = lanDiffNum.entrySet().iterator();
//		while(it5.hasNext())
//		{
//			Map.Entry pair2 = (Map.Entry)it5.next();
////			System.out.print(pair2.getKey());
//			System.out.println(pair2.getValue());
//		}
//		System.out.println();
		
//		for(int i=0; i<=distinctTsNum; i++)
//		{
//			System.out.println(executeTs.getExeRec().getNumOfFail()[i]);
////			System.out.println(executeTs.getExeRec().getNumOfExe()[i]);
//		}
		
//		System.out.println();
//		double nf = executeTs.getSelectTests().getNf();
//		double pf = executeTs.getSelectTests().getPf();
//		double ff = executeTs.getSelectTests().getFf();
//		
//		System.out.println(nf+ " ,"+pf+" ," + ff);
//		
//		
//		System.out.println((double)(nf/all_TSnumber)*100);
//		System.out.println((double)(pf/all_TSnumber)*100);
//		System.out.println((double)(ff/all_TSnumber)*100);
//		
//		System.out.println();
//		
//		System.out.println((double)(nf/executed_TSnumber)*100);
//		System.out.println((double)(pf/executed_TSnumber)*100);
//		System.out.println((double)(ff/executed_TSnumber)*100);
//		
//		System.out.println();
//		
//		System.out.println((double)(nf/all_failNumber)*100);
//		System.out.println((double)(pf/all_failNumber)*100);
//		System.out.println((double)(ff/all_failNumber)*100);
//		
//		
//		
//		System.out.println("AvgExeTime=" + (all_ExeTime/all_TSnumber)/1000);
//		
//		double numOfExeWithFail = 0;
//		double rateAll = 0;
//		int j = 0;
//		for(int i=0; i<distinctTsNum; i++)
//		{
//			if(executeTs.getExeRec().getIsFail()[i])
//			{
//				System.out.println(i);
//			}
//			
//		}
//		System.out.println("IntraArrivalTime="+(double)rateAll/j);
////		System.out.println((double)(numOfExeWithFail/executed_TSnumber)*100);
////		System.out.println((double)(executeTs.getExeRec().getExeAfterFail()/executed_TSnumber)*100);
////		System.out.println(numOfExeWithFail);
////		System.out.println(executeTs.getExeRec().getExeAfterFail());
//		
//		System.out.println("InterArrivalTime="+(double)(executeTs.getExeRec().allTime(executed_TSnumber)));
//		
	}
	
	private ExeRecord exeRec;
	


	public ExeRecord getExeRec() {
		return exeRec;
	}

	public void setExeRec(ExeRecord exeRec) {
		this.exeRec = exeRec;
	}
	
	
}
