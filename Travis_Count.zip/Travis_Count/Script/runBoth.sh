libDir=../lib
srcDir=../src
binDir=../bin

inputParameter_1=96   #failWindow
inputParameter_2=1	  #exeWindow
inputParameter_3=hours	#failmmhh
inputParameter_4=hours # exemmhh
inputParameter_7=1 #repetitiveWindow
inputParameter_8=hours #repetitivemmhh

inputParameter_5=post	
inputParameter_6=pres   #selected stage

# dataset=googleDataset

#compile the program
javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

# with option -h, the list of options will show up
java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

#run the program with parameters
java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=googleDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -x=$inputParameter_7 -y=$inputParameter_8


# for travis

javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

# with option -h, the list of options will show up
java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

#run the program with parameters
java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=travisDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -x=$inputParameter_7 -y=$inputParameter_8