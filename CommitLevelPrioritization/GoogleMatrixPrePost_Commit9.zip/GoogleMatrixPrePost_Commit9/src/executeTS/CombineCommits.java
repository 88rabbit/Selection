//package executeTS;
//
//import java.text.ParseException;
//import java.util.HashMap;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Map;
//import java.util.PriorityQueue;
//import java.util.Queue;
//
//import calculationMethods.CalculateBestCaseSave;
//import changeRequest.ReadFailCR;
//import changeRequest.ReadFailJavaTs;
//import changeRequest.ReadFailTest;
//import changeRequest.ReadMatrix;
//import exeRecord.ExeRecord;
//import testSuites.TestSuite;
//
//public class CombineCommits 
//{	
//	//for counting number of all TestSuites
//	private Accumulation accumulateAll = new Accumulation();
//			
//	//for counting number of executed TestSuites
//	private Accumulation accumulateExe = new Accumulation();
//	
////	private UpdateExeRecord updateExeRecords = new UpdateExeRecord();
//	
//	private int nf=0;
//	private int pf=0;
//	private int ff=0;
//	
//	private String preStatus = "";
//	
//	//prioritizing commits
//	
//    private int commitId = 0;
//    private int failCommits=0;
//    private int detectedFailCommits = 0;
//	
//	private CalculateBestCaseSave cbc = new CalculateBestCaseSave();
//	
////	//last version
//	private Commit exeCommit = new Commit();
//	private boolean isFrist = true;
//	
////	private int numOfCommit = 1694;
//	private int numOfCommit = 0;
//	private int exeNumOfCommit = 0;
//	
////	private int numOfCommit2 = 0;
//	
//	//language
//		private int[] BORGCFG = new int[3];
//		private int[] CC = new int[3];
//		private int[] JAVA = new int[3];
//		private int[] PY = new int[3];
//		private int[] SH = new int[3];
//		private int[] WEB = new int[3];
//		private int[] GWT = new int[3];
//		private int[] GO = new int[3];
//
//		private int b = 0;
//		private int cc = 0;
//		private int java = 0;
//		private int py = 0;
//		private int sh = 0;
//		private int web = 0;
//		private int gwt = 0;
//		private int go = 0;
//		
//		private double commitFailApfd = 0;
//		private double commitAllApfd = 0;
//		private double trainingSize;
//		private PrioritizeCommits tempCommitQueue;
////	
////	private int times = 5;
//		private Map<Integer, int[]> map;
//		
//		int numOfRepetive = 0;
//		private Map<Integer, Integer> repCommit = new HashMap<Integer,Integer>();
//		private Map<Integer, String> failTestLanguage = new HashMap<Integer, String>();
//		
//		private UpdateExeRecord updateExeRecords;
////		private CountFailures cf= new CountFailures();
//		
//		private Queue<Commit> q = new LinkedList<Commit>();
//		
//		private int pqSize;
//	
//		private String selectedStage;
//		private int allTsNum;
//		private double train;
//		
//		private Queue<Commit> storeCommit;
////		private PriorityQueue<Commit> pq;
//		
//		public CombineCommits(int pqSize, String selectedStage, double trainingSize) 
//		{
//			super();
//			this.pqSize = pqSize;
//			this.updateExeRecords = new UpdateExeRecord();
//			this.selectedStage = selectedStage;
//			if(this.selectedStage.equals("pres"))
//				allTsNum = 1694;
//			else if(this.selectedStage.equals("post"))
//				allTsNum = 4520; 
//			this.trainingSize = trainingSize;
//			this.train = (double)((double)trainingSize*(double)allTsNum);
//			this.tempCommitQueue = new PrioritizeCommits();
//			this.storeCommit = new LinkedList<Commit>();
//		}
//
//
//		
//
//		public void processLastCommit(String selectedStage, ExeRecord exeRec, int failWindow, int executionWindow, PrioritizeCommits prioritizeCommits)
//		{
//			
//			prioritizeCommits.updateCommits(exeCommit); // prioritize commits
//			while(! prioritizeCommits.getPq().isEmpty())
//			{
//				exeNumOfCommit ++;
//				Commit c =  prioritizeCommits.getPq().poll();					
//				c.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, exeNumOfCommit);
//							
//				commitAllApfd ++; 
//				if(c.isCheckFail())
//				{
//					commitFailApfd += commitAllApfd;
//					failCommits ++;
//					detectedFailCommits ++;
////					System.out.println(commitAllApfd);
//				}
////				System.out.println(failCommits);
//			}
//			
//			
//			
////			exeCommit.update3ProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords);
//		}
//		
//
//		
//	public void selectTs(ReadMatrix matrix, List<Integer> failTest, List<Integer> failCR, ReadFailJavaTs javaTs,TestSuite lastTs, String selectedStage, ExeRecord exeRec, 
//			String alwaysExecutedStage, Map<Integer, boolean[]> isSizeFail, int failWindow, int executionWindow, PrioritizeCommits prioritizeCommits) throws ParseException
//	{
//		/*
//		 * Newly updated
//		 */
//		//		//counting
//		this.accumulateAll.counting_all(lastTs, selectedStage);		
//		
////		//1. for new tests
////		//1. for new tests
////		if(exeRec.getIsExecuted()[lastTs.getTsId()] == false)
////		{	
////			updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
////		}
////		//for execution selection
////		else if(exeRec.getNumSinceLastExe()>=executionWindow 
////				|| (exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[lastTs.getTsId()]<=failWindow))
////		{
////			updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
////		}
////		// for skip selection
////		else
////		{
//////			System.out.println("a");
////			updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, false);	
////		}
//		
//		
//		/*
////		 * update the number of TestSuite and the execution time of TestSuite
////		 */
////		if(lastTs.getTsId()==276)
////		{
////		this.pqSize = pqSize;
//		
//		if(isFrist)
//		{
//			numOfCommit ++;
//			commitId = lastTs.getChangeRequest();
//			exeCommit.init(lastTs, failTest, javaTs, isSizeFail, 1,1);	
////			prioritizeCommits.updateCommits(exeCommit);
//			
//			isFrist = false;	
//			
//		}			
//				
//		if(commitId == lastTs.getChangeRequest())
//		{
//			exeCommit.update(lastTs, selectedStage, exeRec, failWindow, executionWindow, exeNumOfCommit+1);	
//		}
//		else
//		{
//			prioritizeCommits.updateCommits(exeCommit); // prioritize commits
////			System.out.println(exeCommit.getId());
//
//			if( prioritizeCommits.getPq().size() == this.pqSize) // prioritize window = 5
//			{
////				System.out.println(prioritizeCommits.getPq().size());
//				exeNumOfCommit ++;
//				Commit c =  prioritizeCommits.getPq().poll();					
//				c.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, exeNumOfCommit);
////				System.out.println(c.getId() + ":idididi" + prioritizeCommits.getPq().size());
//								
//				commitAllApfd ++; 
//				if(c.isCheckFail())
//				{
//					commitFailApfd += commitAllApfd;
//					failCommits ++;
//					detectedFailCommits ++;
////					System.out.println(commitAllApfd);
//				}
////					System.out.println(failCommits);
//	//				System.out.println("fail ratio: "+ c.getFailRatio()
//	//							   + ", exe ratio: " + c.getExeRatio() 
//	//							   + ", % of fail: " + c.getRatio_fail());
//					
//					
//					
//				//update the rest because one of the commit has been updated
//				prioritizeCommits.updateInformInnerCommits(selectedStage, exeRec, failWindow, executionWindow, failTest, javaTs, isSizeFail, exeNumOfCommit);			
//			}
//				
//			numOfCommit ++;
//			exeCommit = new Commit();
//			exeCommit.init( lastTs, failTest, javaTs, isSizeFail, 1,1);				
//			exeCommit.update(lastTs, selectedStage, exeRec, failWindow, executionWindow, exeNumOfCommit+1);		
////			
//			
//			commitId = exeCommit.getId();
//		
//		}
//		
////		
////		
//		
//		
//		
////		
//			
//}
//	
////	//for matrix
//////	private List<ArrayList<Integer>> changeR = new ArrayList<ArrayList<Integer>>();
////		public void selectTs3(ReadMatrix matrix, List<Integer> failTest, List<Integer> failCR, ReadFailJavaTs javaTs,TestSuite lastTs, String selectedStage, ExeRecord exeRec, 
////				String alwaysExecutedStage, Map<Integer, boolean[]> isSizeFail, int failWindow, int executionWindow, PrioritizeCommits prioritizeCommits, int pqSize) throws ParseException
////		{
////			/*
////			 * Newly updated
////			 */
////			
//////			//counting
////			this.accumulateAll.counting_all(lastTs, selectedStage);		
////			
////			if(isFrist)
////			{
////				numOfCommit2 ++;
////				exeCommit.init(cf,lastTs, failTest, javaTs, isSizeFail, numOfCommit2);	
//////				prioritizeCommits.updateCommits(exeCommit);
////				
////				isFrist = false;	
////				
////			}			
////					
////			if(commitId == lastTs.getChangeRequest())
////			{
////				exeCommit.update3(lastTs, accumulateExe, selectedStage, exeRec, failWindow, executionWindow);	
//////				exeCommit.update3(lastTs, accumulateExe, selectedStage);			
////			}
////			else
////			{
//////				System.out.println(exeCommit.getId());
////				
////				
////				CountCommits.updateCountsInQueue(); // update number
//////				q.offer(exeCommit);
////				exeCommit.update3ProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords);
//////				
////				
////				if(exeCommit.isCheckFail())
////					failCommits ++;
////				
////				numOfCommit2 ++;
////				exeCommit = new Commit();
////				exeCommit.init(cf, lastTs, failTest, javaTs, isSizeFail, numOfCommit2);				
////				exeCommit.update3(lastTs, accumulateExe, selectedStage, exeRec, failWindow, executionWindow);		
////			}
////			
////			commitId = exeCommit.getId();
////			
////				
////			}
//		
//		
////		public void processLastCommit3(String selectedStage, ExeRecord exeRec,CountCommits CountCommits, int failWindow, int executionWindow, PrioritizeCommits prioritizeCommits)
////		{
////			
////			CountCommits.updateCountsInQueue(); // update number
//////			q.offer(exeCommit);
////			exeCommit.update3ProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords);
////			System.out.println(CountCommits.getCommitsNum());
////			
////			
//////			while(!q.isEmpty())
//////			{
//////				Commit c = q.poll();
//////				prioritizeCommits.updateCommits(c); // prioritize commits
//////			}
////////			
//////			PriorityQueue<Commit> pq = prioritizeCommits.getPq();
//////			accumulateExe = new Accumulation();
//////			while(!pq.isEmpty())
//////			{
//////				Commit c = pq.poll();
//////				c.update3ProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords);
//////				
////////				System.out.println("fail ratio: "+ c.getFailRatio()
////////				   + ", exe ratio: " + c.getExeRatio() 
////////				   + ", % of fail: " + c.getRatio_fail());
////////				System.out.println(c.getNumTsSatisfy_fail() );
//////			}
//////				CountCommits.resetCounts();
//////				prioritizeCommits.clear();// remove the commit in the queue
//////			
////			
//////			exeCommit.update3ProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords);
////		}
////		
//		
////	}
//
//
//		
//	public Accumulation getAccumulateAll() {
//		return accumulateAll;
//	}
//
//	public void setAccumulateAll(Accumulation accumulateAll) {
//		this.accumulateAll = accumulateAll;
//	}
//
//	public Accumulation getAccumulateExe() {
//		return accumulateExe;
//	}
//
//	public void setAccumulateExe(Accumulation accumulateExe) {
//		this.accumulateExe = accumulateExe;
//	}
//
//	public int getNf() {
//		return nf;
//	}
//
//	public void setNf(int nf) {
//		this.nf = nf;
//	}
//
//	public int getPf() {
//		return pf;
//	}
//
//	public void setPf(int pf) {
//		this.pf = pf;
//	}
//
//	public int getFf() {
//		return ff;
//	}
//
//	public void setFf(int ff) {
//		this.ff = ff;
//	}
//
//	public CalculateBestCaseSave getCbc() {
//		return cbc;
//	}
//
//	public void setCbc(CalculateBestCaseSave cbc) {
//		this.cbc = cbc;
//	}	
//	
//	public int[] getBORGCFG() {
//		return BORGCFG;
//	}
//
//	public void setBORGCFG(int[] bORGCFG) {
//		BORGCFG = bORGCFG;
//	}
//
//	public int[] getCC() {
//		return CC;
//	}
//
//	public void setCC(int[] cC) {
//		CC = cC;
//	}
//
//	public int[] getJAVA() {
//		return JAVA;
//	}
//
//	public void setJAVA(int[] jAVA) {
//		JAVA = jAVA;
//	}
//
//	public int[] getPY() {
//		return PY;
//	}
//
//	public void setPY(int[] pY) {
//		PY = pY;
//	}
//
//	public int[] getSH() {
//		return SH;
//	}
//
//	public void setSH(int[] sH) {
//		SH = sH;
//	}
//
//	public int[] getWEB() {
//		return WEB;
//	}
//
//	public void setWEB(int[] wEB) {
//		WEB = wEB;
//	}
//
//	public int[] getGWT() {
//		return GWT;
//	}
//
//	public void setGWT(int[] gWT) {
//		GWT = gWT;
//	}
//
//	public int[] getGO() {
//		return GO;
//	}
//
//	public void setGO(int[] gO) {
//		GO = gO;
//	}
//
//	public int getB() {
//		return b;
//	}
//
//	public void setB(int b) {
//		this.b = b;
//	}
//
//	public int getCc() {
//		return cc;
//	}
//
//	public void setCc(int cc) {
//		this.cc = cc;
//	}
//
//	public int getJava() {
//		return java;
//	}
//
//	public void setJava(int java) {
//		this.java = java;
//	}
//
//	public int getPy() {
//		return py;
//	}
//
//	public void setPy(int py) {
//		this.py = py;
//	}
//
//	public int getSh() {
//		return sh;
//	}
//
//	public void setSh(int sh) {
//		this.sh = sh;
//	}
//
//	public int getWeb() {
//		return web;
//	}
//
//	public void setWeb(int web) {
//		this.web = web;
//	}
//
//	public int getGwt() {
//		return gwt;
//	}
//
//	public void setGwt(int gwt) {
//		this.gwt = gwt;
//	}
//
//	public int getGo() {
//		return go;
//	}
//
//	public void setGo(int go) {
//		this.go = go;
//	}
//
//	public int getNumOfRepetive() {
//		return numOfRepetive;
//	}
//
//	public void setNumOfRepetive(int numOfRepetive) {
//		this.numOfRepetive = numOfRepetive;
//	}
//
//	public Map<Integer, Integer> getRepCommit() {
//		return repCommit;
//	}
//
//	public void setRepCommit(Map<Integer, Integer> repCommit) {
//		this.repCommit = repCommit;
//	}
//
//	
//
//	public int getFailCommits() {
//		return failCommits;
//	}
//
//	public void setFailCommits(int failCommits) {
//		this.failCommits = failCommits;
//	}
//
//
//
//	public int getNumOfCommit() {
//		return numOfCommit;
//	}
//
//
//
//	public void setNumOfCommit(int numOfCommit) {
//		this.numOfCommit = numOfCommit;
//	}
//
//
//
//	public double getCommitFailApfd() {
//		return commitFailApfd;
//	}
//
//
//
//	public void setCommitFailApfd(double commitFailApfd) {
//		this.commitFailApfd = commitFailApfd;
//	}
//
//
//
//	public int getExeNumOfCommit() {
//		return exeNumOfCommit;
//	}
//
//
//
//	public void setExeNumOfCommit(int exeNumOfCommit) {
//		this.exeNumOfCommit = exeNumOfCommit;
//	}
//
//
//
//	public int getDetectedFailCommits() {
//		return detectedFailCommits;
//	}
//
//
//
//	public void setDetectedFailCommits(int detectedFailCommits) {
//		this.detectedFailCommits = detectedFailCommits;
//	}
//	
//	
//	
//}
