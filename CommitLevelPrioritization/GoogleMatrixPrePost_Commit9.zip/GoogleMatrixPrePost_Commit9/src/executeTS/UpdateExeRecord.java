package executeTS;

import testSuites.TestSuite;
import exeRecord.ExeRecord;

public class UpdateExeRecord 
{
	
	public void updateDetails(ExeRecord exeRec, TestSuite lastTs, Accumulation accumulateExe, String selectedStage, boolean isExe, int commitNum, double timePassed)
	{
		if(isExe)
		{
			exeRec.updateTsRecord(lastTs, commitNum);
			lastTs.setExecuted(true);
			
			//counting
			accumulateExe.counting_exe(lastTs, selectedStage, commitNum, timePassed);		
		}
		else
		{
			exeRec.updateSkip(lastTs);
		}
		
	}
}
