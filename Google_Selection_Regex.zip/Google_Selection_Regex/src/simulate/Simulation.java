package simulate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import databaseInfo.DatabaseInformation;
import executeTS.ExecuteTestSuites;
import readFile.ReadInFailedTestSuiteRegularPatterns;

public class Simulation 
{	
	public void simulate(String sql, int failWindow,int executionWindow, String failmmhh,String executemmhh, String selectedStage, int distinctTsNum, String alwaysExecutedStage, double percent, double deltaFail) throws ClassNotFoundException, SQLException
	{	

		//connect database
		DatabaseInformation dbInfo = new DatabaseInformation();
		ResultSet rs = dbInfo.connectDatabase(sql);
		
		//execute TestSuites
		ExecuteTestSuites executeTs = new ExecuteTestSuites(distinctTsNum);
		executeTs.executeTestSuites(rs, failWindow, executionWindow,failmmhh,executemmhh, selectedStage,distinctTsNum, alwaysExecutedStage, percent, deltaFail);
		
		//counting numbers of testsuites
		double all_TSnumber = executeTs.getAll_TSnumber();
		double all_failNumber=executeTs.getAll_failNumber();
		long all_ExeTime = executeTs.getAll_ExeTime();
		
		double executed_TSnumber = executeTs.getExecuted_TSnumber();
		double executed_failNumber = executeTs.getExecuted_failNumber();
		long executed_ExeTime = executeTs.getExecuted_ExeTime();
		
		System.out.println("Number of allTestSuites: "+all_TSnumber);
		System.out.println("Number of executedTests: "+executed_TSnumber);
		System.out.println("allExeTime: "+all_ExeTime);
		System.out.println("executedTSTime: "+executed_ExeTime);
		System.out.println("allFailTests: "+ all_failNumber);
		System.out.println("failTests: "+ executed_failNumber);
		System.out.println();
		
		double percentOfSelectedTS = executed_TSnumber/all_TSnumber;
		System.out.println("Percentage of test suites selected is: "+percentOfSelectedTS*100);
		float percentOfExeTime = (float)executed_ExeTime/(float)all_ExeTime;
		System.out.println("Percentage of execution time is: "+ percentOfExeTime*100);
		double percentOfFailDetected = executed_failNumber/all_failNumber;
		System.out.println("Percentage of failure detected is: " + percentOfFailDetected*100);
		System.out.println();
		
//		
		/*
		 * Get distinct failed test suites id
		 */
			int totalNumberOfDistinctFail = 0;
			int passToFailTransitions = 0;
			
			 int all_passFail_transitions = 0;
			 int exe_passFail_transitions = 0;
			 
			 double totalNumOfTsForFailTests = 0;
			    
			for(int i=1; i<executeTs.getExeRec().getIsFail().length; i++)
			{
				if(executeTs.getExeRec().getIsExecuted()[i])
				{
					all_passFail_transitions += executeTs.getSelectTests().getAccumulateAll().getPf_transition()[i];
					exe_passFail_transitions += 	executeTs.getSelectTests().getAccumulateExe().getPf_transition()[i];
					
					passToFailTransitions += executeTs.getExeRec().getPf_num()[i];
//					System.out.println(executeTs.getExeRec().getNumOfExe()[i]);
					
					if(executeTs.getExeRec().getIsFail()[i])
					{
//						System.out.println(i);
						totalNumberOfDistinctFail ++;
//						totalNumOfTsForFailTests += executeTs.getExeRec().getNumOfExe()[i];
					}	
					else
					{
						totalNumOfTsForFailTests += executeTs.getExeRec().getNumOfExe()[i];
					}
				
				}
				
			}
			 System.out.println("total number of Detected distinct fail test suite is: " + totalNumberOfDistinctFail);
			    int number_NF_PF = passToFailTransitions+totalNumberOfDistinctFail;
			    int number_PF = exe_passFail_transitions;
			    System.out.println("total number of New->Fail or Pass->Fail Transitions is: " + number_NF_PF);
			    System.out.println("total number of detected Pass->Fail Transitions is: " + number_PF);
			    
			    
			    int allToFailTransitions = 0;
			    int allPassToFail_afterWarmup = all_passFail_transitions;
			    System.out.println("total number of Pass->Fail Transitions is: " + allPassToFail_afterWarmup);
			    System.out.println();
			    
			    /*
			     * For 1% selectoin
			     */
//			    if(selectedStage.equals("post"))
//			    {
////			    	allToFailTransitions = 2096;
//			    	allPassToFail_afterWarmup = 1736;
//			    	all_TSnumber = 1044287.0;
//			    	all_failNumber = 4433.0;
//			   
//			    }
//			    else 
//			    {
////			    	allToFailTransitions = 1059;   // pass-> fail + new->fail
//			    	allPassToFail_afterWarmup = 676;// just 1. pass->fail  2. after 30%
//			    	all_TSnumber = 733502.0;
//			    	all_failNumber = 1185.0;
//			    }			  
//			    
//			    percentOfSelectedTS = executed_TSnumber/all_TSnumber;
//			    percentOfFailDetected = executed_failNumber/all_failNumber;
			    
			    System.out.println("Percent of New->Fail or Pass->Fail Detections: " + (double)(double)number_NF_PF*100/(double)allToFailTransitions);
			    System.out.println("Percent of Pass->Fail Detections after warmup: " + (double)(double)number_PF*100/(double)allPassToFail_afterWarmup);
			    System.out.println();
			
			    System.out.println(percentOfSelectedTS*100);	
			    System.out.println(percentOfExeTime*100);
			    System.out.println(percentOfFailDetected*100);
				
//			    if(selectedStage.equals("post"))
//			    {
////			    	System.out.println("% of new distinctFailDetected is: " + (double)(double)totalNumberOfDistinctFail*100/(double)154);
//			    	System.out.println( (double)(double)totalNumberOfDistinctFail*100/(double)154);
//			    }
//			    else
//			    {
//			    	System.out.println( (double)(double)totalNumberOfDistinctFail*100/(double)199);
//			    }
//			    System.out.println((double)(double)number_NF_PF*100/(double)allToFailTransitions);
				System.out.println((double)(double)number_PF*100/(double)allPassToFail_afterWarmup);
			
			    System.out.println();
			    
			    System.out.println(all_passFail_transitions);
			    System.out.println(exe_passFail_transitions);
		    
			    
			    System.out.println("totalTsFails:" + totalNumOfTsForFailTests);
		    
		    
		    
////		    int[] regexId;
//		    //Post
//		    Integer[] postIds = {4734,496,724,4930,102,288,306,285,226,1060,305,3500,328,4904,3141,487,279,278,4406,2959,1095,503,190,5440,1940,4825,976,647,3042,3166,864,287,1009,3516,282,294,2057};
//		    //Pres
//		    Integer[] presIds = {102,189,3166,647,4604,496,328,86,1095,4805,864,2949,2408,2968,4678,724,4930,190,976,306,4871,5462,4904,1281};
//		  
//		    Set<Integer> regexId;
//		    if(selectedStage.equals("post"))
//		    	regexId = new HashSet<Integer>(Arrays.asList(postIds));
//		    else
//		    	regexId = new HashSet<Integer>(Arrays.asList(presIds));
//		    double[] numOfFailsDetected = executeTs.getExeRec().getNumOfFail();
//		    for(int i=1; i<executeTs.getExeRec().getIsFail().length; i++)
//		    {
//		    	if(regexId.contains(i))
//		    	{
////		    		System.out.println(i + "," + numOfFailsDetected[i]);
//		    		System.out.println(numOfFailsDetected[i]);
//		    	}
//		    }
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
////		double numOfExeWithFail=0;
//////		System.out.println(executeTs.getExeRec().getNumOfFail().length);
////		for(int i=0; i<executeTs.getExeRec().getNumOfFail().length; i++)
////		{
////			if(executeTs.getExeRec().getIsFail()[i])
////			{
////				numOfExeWithFail = numOfExeWithFail + executeTs.getExeRec().getNumOfExe()[i];
//////				System.out.println(executeTs.getExeRec().getNumOfFail()[i]);
//////				System.out.println(executeTs.getExeRec().getNumOfExe()[i]);
////			}
////			
////		}
//		double numOfExeWithFail = 0;
//		for(int i=0; i<distinctTsNum; i++)
//		{
//			if(executeTs.getExeRec().getIsFail()[i])
//			{
//				numOfExeWithFail = numOfExeWithFail + executeTs.getExeRec().getNumOfExe()[i];
////				System.out.println(i);
////				System.out.println(executeTs.getExeRec().getRate(i));	
////				System.out.println(executeTs.getExeRec().getNumOfExe()[i]);
//			}
//		}
//		System.out.println((double)(numOfExeWithFail/executed_TSnumber)*100);
//		System.out.println((double)(executeTs.getExeRec().getExeAfterFail()/executed_TSnumber)*100);
////		System.out.println(numOfExeWithFail);
////		System.out.println(executeTs.getExeRec().getExeAfterFail());
//////		
////		System.out.println(executeTs.getExeRec().getMean());
////		System.out.println(executeTs.getExeRec().getVariance());
////		System.out.println(executeTs.getExeRec().getSkewness());
////		System.out.println(executeTs.getExeRec().getKurtosis());
////		
////		System.out.println(executeTs.getExeRec().getFailNo());
////		System.out.println(executeTs.getExeRec().getDistance_list().size());
//		
		
		
		
	}
}
