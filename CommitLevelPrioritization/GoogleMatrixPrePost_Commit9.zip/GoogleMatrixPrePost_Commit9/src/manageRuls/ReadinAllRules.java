//package manageRuls;
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//public class ReadinAllRules 
//{
//	//read item sets from oneToOne rule class
//	private OneToOneRule singleItem = new OneToOneRule();	
//	private Map<String, Integer> singleItemset = singleItem.get11Rules(); //set for 1 itemset: TestId  // get the rules for single itemset
//	private Map<Integer, String> itemsetS = singleItem.getItemsetS();
//	
//	private double delta = 0.5;
//	
//	//store one item set information
//	private Map<Integer, Set<Integer>> singleRuleMap = new HashMap<Integer, Set<Integer>>();
//	private List<Set<Integer>> list = new ArrayList<Set<Integer>>();
//	
//	private int total = 0;
//	private int one2oneNums = 0;
//	
//	public void getRules()
//	{
////		for(String s: singleItemset.keySet())
////		{
////			System.out.println(s + ":" + singleItemset.get(s));;
////		}
//	try
//	{
////		
////		FileReader fs = new FileReader("../data/allRules.txt"); // the commits contains test suites that has failure history(does not mean it fails)
//		FileReader fs = new FileReader("../data/SMLFail408.txt");
//		BufferedReader br = new BufferedReader(fs);
//		
//		String testInfo = br.readLine();
//		String temp;
//		String[] eachRow;
//		String[] eachLeft;
//		String[] eachRight;
//		double confidence;
//		while(testInfo!=null &&!testInfo.isEmpty())
//		{		
//			Set<Integer> left = new HashSet<Integer>();
//			Set<Integer> right = new HashSet<Integer>();
//			
//			total ++;
//			
////			temp = testInfo.replaceAll("\\s","");			 //1.5272=F92==>5273=F92conf:(1)
////			System.out.println(temp);
//			temp = testInfo;
//			confidence = Double.parseDouble(temp.substring(temp.indexOf("(")+1,temp.indexOf(")")));  //0.5
////			System.out.println(confidence);			
////			System.out.println(temp);
//			eachRow = temp.split("\\.")[1].split("==>"); //befor "==>"   328=F813==>102=F503=F14conf:(0 
////			System.out.println(eachRow[1]);
//			
//			/*
//			 * The following are used to put Test ids in the left to "left" set; and test ids in the right to the "right" set
//			 */
////			eachLeft = eachRow[0].split("=F");
//			eachLeft = eachRow[0].split(" ");
//			for(int i=1; i<eachLeft.length-1; i++)
//			{
////				System.out.print(eachLeft[i] + ",");
////				left.add(Integer.parseInt(eachLeft[i]));
//				left.add(singleItemset.get(eachLeft[i]));
//			}
////			System.out.println();
//			
////			eachRight = eachRow[1].split("=F");
//			eachRight = eachRow[1].split("c")[0].trim().split(" ");
//			
//			for(int i=0; i<eachRight.length-1; i++)
//			{
////				System.out.print(eachRight[i] + ",");
////				System.out.print(": " + singleItemset.get(eachRight[i]));
////				right.add(Integer.parseInt(eachRight[i]));
//				right.add(singleItemset.get(eachRight[i]));
//			}
////			System.out.println();
////			for(Integer i: left)
////			{
////				System.out.print(i+",");
////			}
//////			System.out.print("====");
////			for(Integer i: right)
////			{
////				System.out.print(i+",");
////			}
////			System.out.println();
//		
//			
//			/*
//			 * This part is used to store the relationship between single rules
//			 */
//			int key=0;
//			int value=0;
//			String keyS = "";
//			String valueS = "";
////			System.out.println("size" + left.size() + "," + right.size());
//			if(left.size() == 1 && right.size()==1 && confidence >= delta) // this means the rule left==> rule right are 1 rule ==> 1 rule
//			{
//				one2oneNums++;
//				Set<Integer> set;
//				Set<String> setS;
//				for(Integer k: left) 
//				{
//					key = k;
//				}
//					
//				for(Integer v: right)
//					value = v;
////				System.out.println("***********"+key + ", " + value);
//				if(!singleRuleMap.containsKey(key))
//				{
//					set = new HashSet<Integer>();
//					set.add(value);
//					singleRuleMap.put(key, set);
//				}
//				else
//				{
//					set = singleRuleMap.get(key);
//					set.add(value);
//					singleRuleMap.put(key, set);
//				}
//			}
//						
//			testInfo = br.readLine();			
//		
//		}
//		System.out.println("No.of all rules: " + total);	
//		System.out.println("No. of one to one rule: " + one2oneNums);
//		
//		for(Integer i: singleRuleMap.keySet())
//		{
////			System.out.print(i + "==>");
//			System.out.print(itemsetS.get(i)  + "==>");
//			for(Integer j: singleRuleMap.get(i))
//			{
////				System.out.print(j + ", ");
//				System.out.print( itemsetS.get(j)+ ", ");
//			}				
//			System.out.println();
//		}
//		
////		for(Integer i: singleRuleMap.keySet())
////		{
////			System.out.print(i + "==>");
////			for(Integer j: singleRuleMap.get(i))
////			{
////				System.out.println(j);
////				if(singleRuleMap.containsKey(j))
////				{
////					if(singleRuleMap.get(j).contains(i))
////					{
////						Set<Integer> pair = new HashSet<Integer>();  //each pair both directs each other
////						pair.add(i);
////						pair.add(j);
////						list.add(pair);
////						
////						Set<Integer> tempset = singleRuleMap.get(i);
////						tempset.remove(j);
////						singleRuleMap.put(i, tempset);
////						
////						tempset = singleRuleMap.get(j);
////						tempset.remove(i);
////						singleRuleMap.put(i, tempset);
////					}
////				}
////			}	
//////				
////			System.out.println();
////		}
//		
//		
//		
//	}
//	catch(Exception e)
//	{
//		System.out.print(e.toString());
//	}
//	}
//
//}
