package databaseInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInformation 
{
	/*
	 * connecting cse server
	 */
//	public static final String url = "jdbc:mysql://cse.unl.edu/jliang";
//	public static final String username = "jliang";
//	public static final String password = "wNp3sY";
	
//	/*
//	 * local server for googleDatabase, jliang
//	 */
//	public static final String url = "jdbc:mysql://localhost:3306/jliang";
//	public static final String username = "root";
//	public static final String password = "";
//	
	/*
	 * local server for TravisDatabase, Travis_CI
	 */
//	public static final String url = "jdbc:mysql://localhost:3306/Travis_CI";
//	public static final String username = "root";
//	public static final String password = "";
//	
	/*
	 * local server, test
	 */	
//	public static final String url = "jdbc:mysql://localhost:3306/test";
//	public static final String username = "root";
//	public static final String password = "";
//	
		public ResultSet connectDatabase(String sql, String url, String username, String password) throws ClassNotFoundException, SQLException
		{	
//			DatabaseInformation dbInfo = new DatabaseInformation();
			Connection conn = null;
			
			//STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");
			//STEP 3: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(url,username,password);
			System.out.println("\nSuccessfully connected to database...");
			//STEP 4: Execute a query
			System.out.println("Creating statement...");
//			stmt = conn.createStatement();
				
			// make sure autocommit is off
			conn.setAutoCommit(false);
			Statement st = conn.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_READ_ONLY);
			// Turn use of the cursor on.
			st.setFetchSize(Integer.MIN_VALUE);
			ResultSet rs = st.executeQuery(sql);
			
			return rs;			
		}
}
