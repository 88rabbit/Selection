//package calculationMethods;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import changeRequest.ReadMatrix;
//import executeTS.Accumulation;
//import testSuites.TestSuite;
//
//public class CalculateBestCaseSave 
//{
//	
//	private int id;
////	private List<TestSuite> fail = new ArrayList<TestSuite>(); //record test suites with failure history
//	private List<TestSuite> failIsFail = new ArrayList<TestSuite>(); // record test suites that are actually fail
////	private List<TestSuite> notFail = new ArrayList<TestSuite>();
//	
//	private TestSuite shortTs; // record the shortest time for the failed test suties
//	private long shortTime = -1;
//	
//		
//	public void update(TestSuite ts, List<Integer> failTest, Accumulation accumulateExe, String selectedStage)
//	{
//		this.id = ts.getChangeRequest();
//		if(failTest.contains(ts.getTsId()))
//		{
//			if(ts.isFail())   // test suites that are not fail will be skipped
//			{
//				failIsFail.add(ts);
//				if(shortTime < 0)
//				{
//					shortTs = ts;
//					shortTime = ts.getLast_executionTime();
//				}
//				else
//				{
//					if(ts.getLast_executionTime() < shortTime)
//					{
//						shortTs = ts;
//						shortTime = ts.getLast_executionTime();
//					}
//				}
//			}
//					
//		}
//		else
//		{
//			accumulateExe.counting_exe(ts, selectedStage);// execute all the test suites has no failure history
//		}
//		
//		
//			
//		
//	}
//	
//	public void selectSmallest(Accumulation accumulateExe, String selectedStage)
//	{
//		
//		accumulateExe.counting_exe(shortTs, selectedStage);
//	}
//	
//	
//	
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public long getShortTime() {
//		return shortTime;
//	}
//
//	public void setShortTime(long shortTime) {
//		this.shortTime = shortTime;
//	}
//
//	
//	
//	
//	
//
//}
