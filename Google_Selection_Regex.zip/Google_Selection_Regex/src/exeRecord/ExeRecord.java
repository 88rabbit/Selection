package exeRecord;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import testSuites.TestSuite;

public class ExeRecord 
{
	private boolean[] isExecuted;
	private boolean[] isFail ;
	
	private int[] tsId;
	private String[] stage;
	private String[] status;
	private Timestamp[] last_launchTime;
	private  Timestamp[] last_failTime;
	
	//Used for counting execution times and failure times
	private double[] timesSinceLastExe;
	private double[] timesSinceLastFail;
	
	private double[] numOfFail;
	private double[] numOfExe;
	private double exeAfterFail=0; //total
	
	
	//calculate the distances
	private ArrayList<Double> distance_list = new ArrayList<Double>();
	private double dis = 0;
	private double failNo = 0;
	
	private double[] pf_num; //count number of Pass->Fail transiotn
	private double[] pf_percent; // count the percent of Pass->Fail transition
	
	private double[] pre_pass_times;
	private double[] pre_fail_times;
	
	private double[] min_p;
	private double[] max_p;
	private double[] max_f;
	
	private boolean[] hasMin_p;
	private boolean[] hasMax_f;
	
	private List<Deque<String>> transition_dq;
	
	private double[] recordPrePass;;
//	private List<Deque<String>> p_dq;
	
	private double[] preExeTimes;
	private double failNumberWithinWindow; //(all test suite) get the number of fails within the history window
	
	private int[] numberOfFailTimesWithinWindow; //(each test suite)get the number of times that this certain ts in the history window
	
	public void initializeRecord(int distinctTsNum)
	{
		isExecuted = new boolean[distinctTsNum];
		isFail = new boolean[distinctTsNum];
		tsId = new int[distinctTsNum];
		stage= new String[distinctTsNum];
		status=new String[distinctTsNum];
		last_launchTime = new  Timestamp[distinctTsNum];
		last_failTime = new  Timestamp[distinctTsNum];
		
		timesSinceLastExe = new double[distinctTsNum];
		timesSinceLastFail = new double[distinctTsNum];
		
		numOfFail = new double[distinctTsNum];
		numOfExe = new double[distinctTsNum];
		
		pf_num = new double[distinctTsNum];
		pf_percent = new double[distinctTsNum];
		
		pre_pass_times = new double[distinctTsNum];
		pre_fail_times = new double[distinctTsNum];
		
		min_p = new double[distinctTsNum];
		max_f = new double[distinctTsNum];
		max_p = new double[distinctTsNum];
		hasMin_p = new boolean[distinctTsNum];
		hasMax_f = new boolean[distinctTsNum];
		
		transition_dq = new ArrayList<Deque<String>>(distinctTsNum);
		recordPrePass = new double[distinctTsNum];
		preExeTimes = new double[distinctTsNum];
//		p_dq = new ArrayList<Deque<String>>(distinctTsNum);
		
		numberOfFailTimesWithinWindow = new int[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
			isExecuted[i] = false;
			isFail[i] = false;
			
			tsId[i]=i;
			stage[i] = "N";
			status[i] = "N";	
			
			timesSinceLastExe[i] = 0;
			timesSinceLastFail[i] = -1;
			
			numOfFail[i]=0;
			numOfExe[i]=0;
			
			pf_num[i] = 0;
			pf_percent[i] = 0;
			
			pre_pass_times[i] = 0;
			pre_fail_times[i] = 0;
			
			min_p[i] = Double.MAX_VALUE;
			max_f[i] = Double.MIN_VALUE;
			max_p[i] = Double.MIN_VALUE;
			
			hasMin_p[i] = false;
			hasMax_f[i] = false;
			
			transition_dq.add(new LinkedList<String>());
			recordPrePass[i] = 0;
			preExeTimes[i] =0;
			
			numberOfFailTimesWithinWindow[i] = 0;
//			p_dq.add(new LinkedList<String>());
		}
	}
		
	public void updateTsRecord(boolean movingWindow,TestSuite ts)
	{
		timesSinceLastExe[ts.getTsId()]=0;
		numOfExe[ts.getTsId()]++;
		preExeTimes[ts.getTsId()] ++;
		this.isExecuted[ts.getTsId()] = true;
		
		this.stage[ts.getTsId()] = ts.getLast_stage();
		
		if(this.status[ts.getTsId()].equals("PASSED") && ts.isFail()==true)  // if previous is passed and current is failed ==> transition PF
		{
			pf_num[ts.getTsId()] ++;
			pf_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/numOfExe[ts.getTsId()];
//			System.out.println(pf_percent[ts.getTsId()]);
		}
		this.status[ts.getTsId()] = ts.getLast_status();
		this.last_launchTime[ts.getTsId()] =ts.getLast_launchTime();
		
		
		
		if(ts.isFail()==true || isFail[ts.getTsId()]==true)
		{
			exeAfterFail++;
		}
		
		
		
		if(ts.isFail()==true)
		{
			this.last_failTime[ts.getTsId()] = ts.getLast_failTime();
			this.isFail[ts.getTsId()] = true;
			
			timesSinceLastFail[ts.getTsId()]=1;
			numOfFail[ts.getTsId()]++;
			

			distance_list.add((Double)dis);
			failNo++;
			dis=0;
		}
		else
		{
//			System.out.println(0);
			if(timesSinceLastFail[ts.getTsId()]>=0)
			{
				timesSinceLastFail[ts.getTsId()]++;
			}
			
			dis++;	
		}
		
		movingWindow(movingWindow, ts, false);
			
	}
	
	public void updateSkip(boolean movingWindow, TestSuite ts)
	{
//		System.out.println(ts.getTsId());
		
		timesSinceLastExe[ts.getTsId()]++;
		
		if(timesSinceLastFail[ts.getTsId()]>=0)
		{
			timesSinceLastFail[ts.getTsId()]++;
		}
		
		movingWindow(movingWindow, ts, true);

	}
	
	public void movingWindow(boolean isMoving, TestSuite currentTs, boolean isSkip)
	{	
		int id = currentTs.getTsId();	
		String currentTsStatus = currentTs.getLast_status().equals("FAILED")? "F":"P";
		
		if(isSkip)
			currentTsStatus = "P";
		
		Deque<String> q;
		String firstStatus;
		if(isMoving) // move and add   isSame is to check whether the previous status is the same as current
		{
			q = transition_dq.get(id);
			firstStatus = q.pollFirst();
			q.offerLast(currentTsStatus);
			transition_dq.set(id, q); // move the oldest
			if(firstStatus.equals(currentTsStatus))
			{
				//skip --> no need to change  PffP or FppF
			}
			else
			{
				if(firstStatus.equals("P")) // it means current is 'F'    ppp -> ppf     from 0 to 1 fails
				{
					numberOfFailTimesWithinWindow[id] ++;
					failNumberWithinWindow ++;
				}
				else // it means current is 'P'   fpp -> ppp  from 1 to 0 fails 
				{
					numberOfFailTimesWithinWindow[id] --;
					failNumberWithinWindow --;
				}
					
			}
		}
		else// accumulate until 30%
		{
//			System.out.println("in: "+ transition_dq.get(id).size());
			q = transition_dq.get(id);
			q.offerLast(currentTsStatus);
			transition_dq.set(id, q); // push the current status into the queue	
//			System.out.println("out: "+ transition_dq.get(id).size());
			/*
			 * count number of fails within the window
			 */
			if(currentTsStatus.equals("F"))
			{
				numberOfFailTimesWithinWindow[id] ++;
				failNumberWithinWindow ++;
			}
			else{//skip
			}
		}
		
		
		Deque<String> curTemp = transition_dq.get(id);
		Deque<String> temp = new LinkedList<String>();
//		TestSuite tempTs; 
//		System.out.println(curTemp.size());
		
		pre_pass_times[id] = 0;
		pre_pass_times[id] = 0;
		
		min_p[id] = Double.MAX_VALUE;
		max_f[id] = Double.MIN_VALUE;
		max_p[id] = Double.MIN_VALUE;
		boolean curIsFail = false;
//		System.out.println(curTemp.size());
//		failNumberWithinWindow = 0; //reset the number
		while(!curTemp.isEmpty())
		{
			String tempStatus = curTemp.pollFirst();
			temp.offerLast(tempStatus);
			
			curIsFail = tempStatus.equals("F")? true: false;		
			if(curIsFail==true)
			{
//				failNumberWithinWindow ++;
				/*
				 * update min_p
				 */
				if(min_p[id] > pre_pass_times[id]+1)
				{
					min_p[id] = pre_pass_times[id]+1;	
					hasMin_p[id] = true;
				}
								
				/*
				 * update max_p
				 */
				if(max_p[id] < pre_pass_times[id]+1)
				{
					max_p[id] = pre_pass_times[id]+1;	
				}
				
			
				/*
				 * update continuousPass/continuousFail
				 */
				pre_fail_times[id] ++;
				pre_pass_times[id] = 0;
				
			}
			else
			{	
				/*
				 * update max_f
				 */
				if(pre_fail_times[id] > 0) // has fail history
				{
					if(max_f[id] < pre_fail_times[id]+1)
					{
						max_f[id] = pre_fail_times[id]+1;
						hasMax_f[id] = true;
					}
				}					
		
				/*
				 * update continuousPass/continuousFail
				 */
				pre_fail_times[id] = 0;
				pre_pass_times[id] ++;		
//				System.out.println(pre_pass_times[id]);
			}
			
		}
		curTemp = temp;
		transition_dq.set(id, curTemp);
		
//		if(!this.isFail[id])
//		{
//			min_p[id] = pre_pass_times[id];
//			max_p[id] = pre_pass_times[id];
//		}
	}
	
	public double getMinOfMaxPass()
	{	
		double minOfMaxPass = Double.MAX_VALUE;
		
		for (int i = 0; i < max_p.length; i++)
		{
		    if (max_p[i] > Double.MIN_VALUE &&  max_p[i] < minOfMaxPass)
		    {
//		    	System.out.println(max_p[i]);
		    	minOfMaxPass = max_p[i];
		        
		    }
		}
//		System.out.println(minOfMaxPass);
		return minOfMaxPass;
	}
	
	/*
	 * PREVIOUS updataeTsRecord
	 */
	
//	public void updateTsRecord(boolean movingWindow,TestSuite ts)
//	{
//		timesSinceLastExe[ts.getTsId()]=0;
//		numOfExe[ts.getTsId()]++;
//		
//		this.isExecuted[ts.getTsId()] = true;
//		
//		this.stage[ts.getTsId()] = ts.getLast_stage();
//		
//		if(this.status[ts.getTsId()].equals("PASSED") && ts.isFail()==true)  // if previous is passed and current is failed ==> transition PF
//		{
//			pf_num[ts.getTsId()] ++;
//			pf_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/numOfExe[ts.getTsId()];
////			System.out.println(pf_percent[ts.getTsId()]);
//		}
//		this.status[ts.getTsId()] = ts.getLast_status();
//		this.last_launchTime[ts.getTsId()] =ts.getLast_launchTime();
//		
//		
//		
//		if(ts.isFail()==true || isFail[ts.getTsId()]==true)
//		{
//			exeAfterFail++;
//		}
//		
//		
//		
//		if(ts.isFail()==true)
//		{
//			this.last_failTime[ts.getTsId()] = ts.getLast_failTime();
//			this.isFail[ts.getTsId()] = true;
//			
//			timesSinceLastFail[ts.getTsId()]=1;
//			numOfFail[ts.getTsId()]++;
//			
//
//			distance_list.add((Double)dis);
//			failNo++;
//			dis=0;
//			
//			/*
//			 * update min_p
//			 */
//			if(min_p[ts.getTsId()] > pre_pass_times[ts.getTsId()])
//			{
//				min_p[ts.getTsId()] = pre_pass_times[ts.getTsId()];	
//				hasMin_p[ts.getTsId()] = true;
//			}
//				
//			
//			/*
//			 * update continuousPass/continuousFail
//			 */
//			pre_fail_times[ts.getTsId()] ++;
//			pre_pass_times[ts.getTsId()] = 0;
//			
//			
//		}
//		else
//		{
////			System.out.println(0);
//			if(timesSinceLastFail[ts.getTsId()]>=0)
//			{
//				timesSinceLastFail[ts.getTsId()]++;
//			}
//			
//			dis++;
//			
//			/*
//			 * update max_f
//			 */
//			if(pre_fail_times[ts.getTsId()] > 0) // has fail history
//			{
//				if(max_f[ts.getTsId()] < pre_fail_times[ts.getTsId()])
//				{
//					max_f[ts.getTsId()] = pre_fail_times[ts.getTsId()];
//					hasMax_f[ts.getTsId()] = true;
//				}
//			}	
//	
//			/*
//			 * update continuousPass/continuousFail
//			 */
//			pre_fail_times[ts.getTsId()] = 0;
//			pre_pass_times[ts.getTsId()] ++;
//			
//			
//		}
//		
//		
//			
//	}
//	
//	public void updateSkip(boolean movingWindow,TestSuite ts)
//	{
////		System.out.println(ts.getTsId());
//		
//		timesSinceLastExe[ts.getTsId()]++;
//		
//		if(timesSinceLastFail[ts.getTsId()]>=0)
//		{
//			timesSinceLastFail[ts.getTsId()]++;
//		}
//		
//		/*
//		 * update max_f
//		 */
//		if(pre_fail_times[ts.getTsId()] > 0) // has fail history
//		{
//			if(max_f[ts.getTsId()] < pre_fail_times[ts.getTsId()])
//			{
//				max_f[ts.getTsId()] = pre_fail_times[ts.getTsId()];
//				hasMax_f[ts.getTsId()] = true;
//			}
//		}	
//		
//		pre_fail_times[ts.getTsId()] = 0;
//		pre_pass_times[ts.getTsId()] ++;
//		
//
//	}
	
	public double getMean()
	{
		double size = this.distance_list.size();
		double totalDis = 0;
		for(int i=0; i<size; i++)
		{
			totalDis +=this.distance_list.get(i);
//			System.out.println(totalDis);
		}
		double mean = (double)(totalDis/size);
		return mean;
	}
	
	public double getVariance()
	{
		double size = this.distance_list.size();
		double mean = getMean();
		double totalSquaredDis=0;
		for(int i=0; i<size; i++)
		{
			totalSquaredDis += Math.pow(this.distance_list.get(i)-mean, 2);
		}
		double variance = (double)(totalSquaredDis/size);
		return variance;
	}
	
	public double getStandardDeviation()
	{
		return Math.sqrt(getVariance());
	}
	
	public double getSkewness()
	{
		double n = this.distance_list.size();
		double temp = 0;
		double mean = getMean();
		
		for(int i=0; i<n; i++)
		{
			temp += Math.pow(this.distance_list.get(i)-mean, 3);
		}
		double cubSD = Math.pow(getStandardDeviation(), 3);
		double skewness = (double)(n*temp)/(double)((n-1)*(n-2)*cubSD);
		return skewness;
	}
	
	public double getKurtosis()
	{
		double n = this.distance_list.size();
		double temp = 0;
		double mean = getMean();
		
		for(int i=0; i<n; i++)
		{
			temp += Math.pow(this.distance_list.get(i)-mean, 4);
		}
		double doubleSquareSD = Math.pow(getStandardDeviation(), 4);
		double kurtosis_1 = (double)(n*(n+1)*temp)/(double)(((n-1)*(n-2)*(n-3)*doubleSquareSD));
		double kurtosis_2= (double)(3*Math.pow(n-1,2))/(double)((n-2)*(n-3));
		
		double kurtosis = kurtosis_1 - kurtosis_2;	
		return kurtosis;
	}
	
	
	
	public ArrayList<Double> getDistance_list() {
		return distance_list;
	}

	public void setDistance_list(ArrayList<Double> distance_list) {
		this.distance_list = distance_list;
	}

	public double getFailNo() {
		return failNo;
	}

	public void setFailNo(int failNo) {
		this.failNo = failNo;
	}

	public boolean[] getIsExecuted() {
		return isExecuted;
	}
	
	public boolean[] getIsFail() {
		return isFail;
	}

	public int[] getTsId() {
		return tsId;
	}
	
	public String[] getStage() {
		return stage;
	}

	public String[] getStatus() {
		return status;
	}

	public Timestamp[] getLast_launchTime() {
		return last_launchTime;
	}

	public Timestamp[] getLast_failTime() {
		return last_failTime;
	}

	public double[] getTimesSinceLastExe() {
		return timesSinceLastExe;
	}

	public void setTimesSinceLastExe(double[] timesSinceLastExe) {
		this.timesSinceLastExe = timesSinceLastExe;
	}

	public double[] getTimesSinceLastFail() {
		return timesSinceLastFail;
	}

	public void setTimesSinceLastFail(double[] timesSinceLastFail) {
		this.timesSinceLastFail = timesSinceLastFail;
	}

	public double[] getNumOfFail() {
		return numOfFail;
	}

	public void setNumOfFail(double[] numOfFail) {
		this.numOfFail = numOfFail;
	}

	public double[] getNumOfExe() {
		return numOfExe;
	}

	public void setNumOfExe(int i, double numOfExe) {
		this.numOfExe[i] = numOfExe;
	}

	public double getExeAfterFail() {
		return exeAfterFail;
	}

	public void setExeAfterFail(double exeAfterFail) {
		this.exeAfterFail = exeAfterFail;
	}

	public double[] getPf_percent() {
		return pf_percent;
	}

	public void setPf_percent(double[] pf_percent) {
		this.pf_percent = pf_percent;
	}

	public double[] getPf_num() {
		return pf_num;
	}

	public void setPf_num(int id, double pf_num) {
		this.pf_num[id] = pf_num;
	}

	public double[] getPre_pass_times() {
		return pre_pass_times;
	}

	public void setPre_pass_times(double[] pre_pass_times) {
		this.pre_pass_times = pre_pass_times;
	}

	public double[] getPre_fail_times() {
		return pre_fail_times;
	}

	public void setPre_fail_times(double[] pre_fail_times) {
		this.pre_fail_times = pre_fail_times;
	}

	public double[] getMin_p() {
		return min_p;
	}

	public void setMin_p(double[] min_p) {
		this.min_p = min_p;
	}

	public double[] getMax_f() {
		return max_f;
	}

	public void setMax_f(double[] max_f) {
		this.max_f = max_f;
	}

	public boolean[] getHasMin_p() {
		return hasMin_p;
	}

	public void setHasMin_p(boolean[] hasMin_p) {
		this.hasMin_p = hasMin_p;
	}

	public boolean[] getHasMax_f() {
		return hasMax_f;
	}

	public void setHasMax_f(boolean[] hasMax_f) {
		this.hasMax_f = hasMax_f;
	}

	public double[] getMax_p() {
		return max_p;
	}

	public void setMax_p(double[] max_p) {
		this.max_p = max_p;
	}

	public double getRecordPrePass(int id) {
		return recordPrePass[id];
	}

	public void setRecordPrePass(int id) {
		this.recordPrePass[id] = pre_pass_times[id];
	}

	public double[] getPreExeTimes() {
		return preExeTimes;
	}

	public void setPreExeTimes(int i, double numOfExe) {
		this.preExeTimes[i] = numOfExe;
	}

	public double getFailNumberWithinWindow() {
		return failNumberWithinWindow;
	}

	public void setFailNumberWithinWindow(double failNumberWithinWindow) {
		this.failNumberWithinWindow = failNumberWithinWindow;
	}

	public int[] getNumberOfFailTimesWithinWindow() {
		return numberOfFailTimesWithinWindow;
	}

	public void setNumberOfFailTimesWithinWindow(int[] numberOfFailTimesWithinWindow) {
		this.numberOfFailTimesWithinWindow = numberOfFailTimesWithinWindow;
	}

	
}
