package testSuites;

import java.sql.Timestamp;

public class TestSuite_Travis 
{
	private boolean isExecuted=false;
	
	private boolean isFail_Ts=false;
	private boolean isError_Ts = false;
	private boolean isFailError_Ts = false;
	private String initialFailTime = "Inf.";
	
	private Timestamp Ts_failTime; //Ts_start_time
	private Timestamp Ts_errorTime;
	private Timestamp Ts_failErrorTime;
	private String Ts_state;
	
	private int TsId;
	private int Ts_order_in_job;
	private double Ts_duration;	 //Ts execution time
	private int Ts_runs;
	private int Ts_assertions;
	private int Ts_failures;
	private int Ts_errors;
	private int Ts_skips;
	private Timestamp Ts_start_time; //Ts launch time
	
	private int Build_id;
	private int Build_number;
	private String Build_state;
	private Timestamp Build_start_time;
	private Timestamp Build_finish_time;
	private double Build_duration;
	
	private int Job_id;
	private int Job_number;
	private String Job_state;
	private Timestamp Job_start_time;
	private Timestamp Job_finish_time;
	
	private int Repository_id;
	private int Commit_id;
	private String Commit_sha;
	private String Commit_short_sha;
	
	private boolean Job_allow_failure;
	

	//for initialization
	public TestSuite_Travis(int tsId) {
		super();
		TsId = tsId;
		Ts_state = "N";
		
	}
	
	//if each Ts is executed, the related record will be updated
	public TestSuite_Travis(int tsId, double ts_duration, int ts_runs, int ts_assertions, int ts_failures,
			int ts_errors, int ts_skips, Timestamp ts_start_time, int build_number, String build_state,
			Timestamp build_start_time, Timestamp build_finish_time, double build_duration, int job_id,
			 String job_state, Timestamp job_start_time, Timestamp job_finish_time, int job_allow_failure,
			 String commit_sha) {
		super();
		
	   
		if(ts_failures>0 && ts_errors>0)
		{
			Ts_state = "failed and errored";
			this.Ts_failErrorTime = ts_start_time;
			this.isFailError_Ts = true;
		}
		else if(ts_failures>0)
		{
			Ts_state = "failed";
			this.Ts_failTime = ts_start_time;
			this.isFail_Ts =true;
		}
		else if(ts_errors>0)
		{
			Ts_state = "errored";
			this.Ts_errorTime = ts_start_time;
			this.isError_Ts=true;
		}
		else
		{
			Ts_state = "passed";
		}
			
		TsId = tsId;
//		Ts_order_in_job = ts_order_in_job;
		Ts_duration = ts_duration;
		Ts_runs = ts_runs;
		Ts_assertions = ts_assertions;
		Ts_failures = ts_failures;
		Ts_errors = ts_errors;
		Ts_skips = ts_skips;
		Ts_start_time = ts_start_time;
//		Build_id = build_id;
		Build_number = build_number;
		Build_state = build_state;
		Build_start_time = build_start_time;
		Build_finish_time = build_finish_time;
		Build_duration = build_duration;
		Job_id = job_id;
//		Job_number = job_number;
		Job_state = job_state;
		Job_start_time = job_start_time;
		Job_finish_time = job_finish_time;
//		Job_duration = job_duration;
//		Repository_id = repository_id;
//		Commit_id = commit_id;
		this.Job_allow_failure = (job_allow_failure == 1) ? true: false;
		Commit_sha = commit_sha;
//		Commit_short_sha = commit_short_sha;
	}

	
	public Timestamp getTs_start_time() {
		return Ts_start_time;
	}

	public void setTs_start_time(Timestamp ts_start_time) {
		Ts_start_time = ts_start_time;
	}
	
	public boolean isExecuted() {
		return isExecuted;
	}

	public void setExecuted(boolean isExecuted) {
		this.isExecuted = isExecuted;
	}

	public boolean isFail_Ts() {
		return isFail_Ts;
	}

	public void setFail_Ts(boolean isFail_Ts) {
		this.isFail_Ts = isFail_Ts;
	}

	public boolean isError_Ts() {
		return isError_Ts;
	}

	public void setError_Ts(boolean isError_Ts) {
		this.isError_Ts = isError_Ts;
	}

	public String getInitialFailTime() {
		return initialFailTime;
	}

	public void setInitialFailTime(String initialFailTime) {
		this.initialFailTime = initialFailTime;
	}

	public Timestamp getTs_failTime() {
		return Ts_failTime;
	}

	public void setTs_failTime(Timestamp ts_failTime) {
		Ts_failTime = ts_failTime;
		this.isFail_Ts = true; // also update this.isFail
		this.Ts_state ="failed";
	}

	public String getTs_state() {
		return Ts_state;
	}

	public void setTs_state(String ts_state) {
		Ts_state = ts_state;
	}

	public int getTsId() {
		return TsId;
	}

	public void setTsId(int tsId) {
		TsId = tsId;
	}

	public double getTs_duration() {
		return Ts_duration;
	}

	public void setTs_duration(double ts_duration) {
		Ts_duration = ts_duration;
	}

	public int getTs_runs() {
		return Ts_runs;
	}

	public void setTs_runs(int ts_runs) {
		Ts_runs = ts_runs;
	}

	public int getTs_assertions() {
		return Ts_assertions;
	}

	public void setTs_assertions(int ts_assertions) {
		Ts_assertions = ts_assertions;
	}

	public int getTs_failures() {
		return Ts_failures;
	}

	public void setTs_failures(int ts_failures) {
		Ts_failures = ts_failures;
	}

	public int getTs_errors() {
		return Ts_errors;
	}

	public void setTs_errors(int ts_errors) {
		Ts_errors = ts_errors;
	}

	public int getTs_skips() {
		return Ts_skips;
	}

	public void setTs_skips(int ts_skips) {
		Ts_skips = ts_skips;
	}


	public int getBuild_id() {
		return Build_id;
	}

	public void setBuild_id(int build_id) {
		Build_id = build_id;
	}

	public int getBuild_number() {
		return Build_number;
	}

	public void setBuild_number(int build_number) {
		Build_number = build_number;
	}

	public String getBuild_state() {
		return Build_state;
	}

	public void setBuild_state(String build_state) {
		Build_state = build_state;
	}

	public Timestamp getBuild_start_time() {
		return Build_start_time;
	}

	public void setBuild_start_time(Timestamp build_start_time) {
		Build_start_time = build_start_time;
	}

	public Timestamp getBuild_finish_time() {
		return Build_finish_time;
	}

	public void setBuild_finish_time(Timestamp build_finish_time) {
		Build_finish_time = build_finish_time;
	}

	public double getBuild_duration() {
		return Build_duration;
	}

	public void setBuild_duration(double build_duration) {
		Build_duration = build_duration;
	}

	public int getJob_id() {
		return Job_id;
	}

	public void setJob_id(int job_id) {
		Job_id = job_id;
	}

	public int getJob_number() {
		return Job_number;
	}

	public void setJob_number(int job_number) {
		Job_number = job_number;
	}

	public String getJob_state() {
		return Job_state;
	}

	public void setJob_state(String job_state) {
		Job_state = job_state;
	}

	public Timestamp getJob_start_time() {
		return Job_start_time;
	}

	public void setJob_start_time(Timestamp job_start_time) {
		Job_start_time = job_start_time;
	}

	public Timestamp getJob_finish_time() {
		return Job_finish_time;
	}

	public void setJob_finish_time(Timestamp job_finish_time) {
		Job_finish_time = job_finish_time;
	}

//	public double getJob_duration() {
//		return Job_duration;
//	}
//
//	public void setJob_duration(double job_duration) {
//		Job_duration = job_duration;
//	}

	public int getRepository_id() {
		return Repository_id;
	}

	public void setRepository_id(int repository_id) {
		Repository_id = repository_id;
	}

	public int getCommit_id() {
		return Commit_id;
	}

	public void setCommit_id(int commit_id) {
		Commit_id = commit_id;
	}

	public String getCommit_sha() {
		return Commit_sha;
	}

	public void setCommit_sha(String commit_sha) {
		Commit_sha = commit_sha;
	}

	public String getCommit_short_sha() {
		return Commit_short_sha;
	}

	public void setCommit_short_sha(String commit_short_sha) {
		Commit_short_sha = commit_short_sha;
	}

	public boolean isJob_allow_failure() {
		return Job_allow_failure;
	}

	public void setJob_allow_failure(boolean job_allow_failure) {
		Job_allow_failure = job_allow_failure;
	}


	public int getTs_order_in_job() {
		return Ts_order_in_job;
	}

	public void setTs_order_in_job(int ts_order_in_job) {
		Ts_order_in_job = ts_order_in_job;
	}

	public boolean isFailError_Ts() {
		return isFailError_Ts;
	}

	public void setFailError_Ts(boolean isFailError_Ts) {
		this.isFailError_Ts = isFailError_Ts;
	}

	public Timestamp getTs_errorTime() {
		return Ts_errorTime;
	}

	public void setTs_errorTime(Timestamp ts_errorTime) {
		Ts_errorTime = ts_errorTime;
	}

	public Timestamp getTs_failErrorTime() {
		return Ts_failErrorTime;
	}

	public void setTs_failErrorTime(Timestamp ts_failErrorTime) {
		Ts_failErrorTime = ts_failErrorTime;
	}

	

   


	

}
