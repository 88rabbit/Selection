package executeTS;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

import changeRequest.ReadFailJavaTs;
import exeRecord.ExeRecord;
import testSuites.TestSuite;

public class SimulateCommitsExecution 
{
	private Accumulation accumulateExe;
	private StoreCommits storeCommits;
//	private Deque<Commit> allCommits; // it contains all the commits from the database
	
	private double percentOfCurrentTime;
//	private double currentTime; // millisecond
	private double totalTimeLine; // total Time Line --> real time
	
	private Commit curExeCommit;
	private double curExeCommit_restTime;
	
	
	private String selectedStage;
	
	//for APFD
	private double commitFailApfd = 0;
	private double commitAllApfd = 0;
	private int failCommits=0;
    private int detectedFailCommits = 0;
	
	//for testing
    private int totalNumOfCommits;
	private int numOfCommitExe;
	private double lastPercent_time = 0;
	private double expected_time = 0;
	private double curPercent_time = 0;
	private double totalExeTime;
	private boolean isOccupied;
	private UpdateExeRecord updateExeRecords;
	private Calendar calForFail;
	private Timestamp currentTime;
	
	private PriorityQueue<Commit> allCommits;// get all the commits from store commits method
	private PriorityQueue<Commit> queue; // nomal queue used for system out the result of % of time and queue size
	
	private double maxTime =0;
	private int maxSize = 0;
	private int numP=0;
	/*
	 * calculate commit apfd
	 */
	private double cApfd = 0;
	private double fApfd = 0;
	
	private boolean isIntra;
	
	public SimulateCommitsExecution(StoreCommits storeCommits, double totalTimeLine, boolean isIntra) 
	{
		super();
		this.accumulateExe = new Accumulation();
		this.storeCommits = storeCommits;
//		this.allCommits = this.storeCommits.getPq();
		this.percentOfCurrentTime = 0;
//		this.currentTime = 0;
		this.totalTimeLine = totalTimeLine;
		this.selectedStage = storeCommits.getSelectedStage();
//		if(this.selectedStage.equals("pres"))
//			this.totalExeTime = 129710672783.0; // commit duration of the real time
//		else
//			this.totalExeTime = 3088989904.0; // commit duration of the real time (post is even more than pres
		this.updateExeRecords = new UpdateExeRecord();
		
//		this.queue = new LinkedList<Commit>();
//		this.totalNumOfCommits = allCommits.size();
		this.allCommits = storeCommits.getPq();
		this.calForFail = Calendar.getInstance();
		this.isIntra = isIntra;
//		this.pq = 
		// this queue is for % of time generating
		this.queue = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
			public int compare(Commit c1, Commit c2)
			{
				
				Timestamp c1_exeStart = c1.getExeStartTime();
				Timestamp c2_exeStart = c2.getExeStartTime();
				
				if(c1_exeStart.before(c2_exeStart))
					return -1;
				else if(c1_exeStart.equals(c2_exeStart))
					return 0;
				else 
					return 1;	
			}
		});
	}
	
	
	public void calculateAvgArrivalInterval()
	{
			
			Timestamp lastArrivalTime;
			Timestamp cuArrivalTime;
			double interval = 0;
			
			
			Timestamp firstCommitArrivalTime = allCommits.poll().getCommitArrivalTime();
//			System.out.println(firstCommitArrivalTime);
			lastArrivalTime = firstCommitArrivalTime;
			cuArrivalTime = lastArrivalTime;
			
//			boolean isChange = false;
			int count = 1;
			while(!allCommits.isEmpty())
			{
				Commit curCmt = allCommits.poll();
				count ++;
				
				cuArrivalTime = curCmt.getCommitArrivalTime();
				interval += cuArrivalTime.getTime() - lastArrivalTime.getTime();
				
//				boolean isChange = false;
				while(!allCommits.isEmpty() && (allCommits.peek().getCommitArrivalTime().equals(cuArrivalTime))) 
				{	
					allCommits.poll();
					count ++;
					
					interval += cuArrivalTime.getTime() - lastArrivalTime.getTime();
				}
				
				lastArrivalTime = cuArrivalTime;
			}
			
			System.out.println(count);
			System.out.println("avgArrivalInterval = " + interval/(double)count);
	}
	
	
	public void setNewArrivalTime(double arrivalRate)
	{
//		double avgArrivalInterval
		
		PriorityQueue<Commit> temp = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
			public int compare(Commit c1, Commit c2)
			{				
				Timestamp c1_Arrive = c1.getCommitArrivalTime();
				Timestamp c2_Arrive = c2.getCommitArrivalTime();
//				System.out.println(c1_Arrive + ";" + c2_Arrive);
				if(c1_Arrive.before(c2_Arrive))
					return -1;
				else if(c1_Arrive.equals(c2_Arrive))
					return 0;
				else 
					return 1;	
			}
		});
			
//		double avgArrivalRate = 0;
		
		Timestamp lastArrivalTime;
		Timestamp cuArrivalTime;
		Timestamp updateCurTime;
		Timestamp preUpdateCurTime;
		Timestamp oldTime;
		double interval = 0;
		double intraInter = 0;
		
		double calInterval = 0;
		Calendar tempCal = Calendar.getInstance();
		
		Commit curCmt = allCommits.poll();
		Timestamp firstCommitArrivalTime = curCmt.getCommitArrivalTime();
		calForFail.setTime(new Date(firstCommitArrivalTime.getTime()));	
		
		lastArrivalTime = firstCommitArrivalTime;
		cuArrivalTime = lastArrivalTime;
		
		updateCurTime = cuArrivalTime;
		preUpdateCurTime = cuArrivalTime;
		
		temp.offer(curCmt);
		int count = 1;
		while(!allCommits.isEmpty())
		{
			curCmt = allCommits.poll();
			count ++;
			
			cuArrivalTime = curCmt.getCommitArrivalTime();
			oldTime = cuArrivalTime;
			interval = (cuArrivalTime.getTime() - lastArrivalTime.getTime()) * arrivalRate;	
			
//			System.out.println("orig"+cuArrivalTime);
			
			calForFail.add(Calendar.MILLISECOND, (int)interval); 			
		
			curCmt.setCommitArrivalTime(new Timestamp(calForFail.getTime().getTime()));	
			
			intraInter = oldTime.getTime() - curCmt.getCommitArrivalTime().getTime();
			double commitDur = curCmt.getDuration();
			double commitSumExe = curCmt.getCommit_totalExeTime();
			for(TestSuite ts: curCmt.getAllTests())
			{
//				System.out.print(ts.getLast_launchTime());
				tempCal.setTime(ts.getLast_launchTime());
				tempCal.add(Calendar.MILLISECOND, -(int)intraInter);
				ts.setLast_launchTime(new Timestamp(tempCal.getTime().getTime()));
				
//				System.out.println("old: " + ts.getLast_executionTime());
				double newExeTime = ((double)ts.getLast_executionTime()/(double)commitSumExe)*commitDur;
				ts.setResetExeTime(newExeTime);
				
//				System.out.println(";" + ts.getLast_executionTime());
			}
							
			temp.offer(curCmt);
			
//			System.out.println();
//			System.out.println();
			
			updateCurTime = curCmt.getCommitArrivalTime();
			calInterval += updateCurTime.getTime() - preUpdateCurTime.getTime();
//			System.out.println(calInterval);
			while(!allCommits.isEmpty() && (allCommits.peek().getCommitArrivalTime().equals(cuArrivalTime))) 
			{	
				curCmt = allCommits.poll();
				count ++;
		
				curCmt.setCommitArrivalTime(new Timestamp(calForFail.getTime().getTime()));		
				
				intraInter = oldTime.getTime() - curCmt.getCommitArrivalTime().getTime();
				commitDur = curCmt.getDuration();
				commitSumExe = curCmt.getCommit_totalExeTime();
				for(TestSuite ts: curCmt.getAllTests())
				{
//					System.out.print(ts.getLast_launchTime());
					tempCal.setTime(ts.getLast_launchTime());
					tempCal.add(Calendar.MILLISECOND, -(int)intraInter);
					ts.setLast_launchTime(new Timestamp(tempCal.getTime().getTime()));
					
					double newExeTime = ((double)ts.getLast_executionTime()/(double)commitSumExe)*commitDur;
					ts.setResetExeTime(newExeTime);
				}
							
				temp.offer(curCmt);
				
				calInterval += updateCurTime.getTime() - preUpdateCurTime.getTime();
			}
			
			lastArrivalTime = cuArrivalTime;
			preUpdateCurTime = updateCurTime;
		}
		
//		System.out.println(count);
//		System.out.println("avgArrivalInterval = " + calInterval/(double)count);
		
		this.allCommits = temp;
	}
	
	/*
	 * Simulate: % of time versiont
	 */
//	public void simulateProcess(PrioritizeCommits prioritizeCommits, ExeRecord exeRec, int failWindow, int executionWindow,  int numOfProcessor, 
//			List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, boolean[]> isSizeFail, double rate)
//	{
//		double wholeRestTime = this.totalTimeLine;    // the whole timer
////		System.out.println("restTime" + wholeRestTime);
//		
////		Timestamp lastArrivalTime;
////		Timestamp cuArrivalTime;
//		double interval = 0;
//		double curPeriod = 0;
//		double totalFail = 267;
//		if(this.selectedStage.equals("pres"))
//			totalFail = 267;
//		else
//			totalFail = 1022;
//		
////		calculateAvgArrivalInterval();// calculate interval
//		setNewArrivalTime(rate);
//		
//		/*
//		 * initialize the required number of processors
//		 */
//		List<Processor> processors = new ArrayList<Processor>();
//		int availProNum = numOfProcessor;
//		for(int i=0; i<numOfProcessor; i++)
//		{
//			Processor temp = new Processor();
//			processors.add(temp);
//		}
//		
//		Commit firstCommit = allCommits.poll();//get the first commit
//		totalNumOfCommits ++;
//		prioritizeCommits.updateCommits(firstCommit);
//
//		Timestamp buildStartTime = prioritizeCommits.getPq().peek().getCommitArrivalTime();
////		System.out.println(buildStartTime);
//					
//		calForFail.setTime(new Date(buildStartTime.getTime()));			 
//		currentTime =  new Timestamp(calForFail.getTime().getTime());
//		
////		while(!prioritizeCommits.getPq().isEmpty() || !allCommits.isEmpty())
//		while(!prioritizeCommits.getPq().isEmpty() || !allCommits.isEmpty() || wholeRestTime > 0)
//		{
//			curPeriod = ((double)currentTime.getTime()-(double)buildStartTime.getTime());
////			boolean isChange = false;
//			// if the commit arrival time is current time then push it into the queue.
//			while(!allCommits.isEmpty() && (allCommits.peek().getCommitArrivalTime().equals(currentTime) || allCommits.peek().getCommitArrivalTime().before(currentTime))) 
//			{	
//				Commit temp = allCommits.poll();
////				System.out.println("failNum:"+temp.getFailNumber());
//				totalNumOfCommits ++;
//				prioritizeCommits.updateCommits(temp);
////				System.out.println("come:"+temp.getId() +"; "+ currentTime);
//			}
//			
//			// if the queue is not empty, and there exists available processors
//			while(!prioritizeCommits.getPq().isEmpty() && availProNum > 0)
//			{
//				prioritizeCommits.updateInformInnerCommits(selectedStage, exeRec, failWindow, executionWindow, failTest, javaTs, isSizeFail, numOfCommitExe);
//				numOfCommitExe ++;
//				curExeCommit = prioritizeCommits.getPq().poll();	
////				System.out.println("exe: "+curExeCommit.getId() +"; "+ currentTime);
//				curExeCommit.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, numOfCommitExe);
//				
//				commitAllApfd ++; 
////				cApfd += (double)curPeriod/(double)(1000*60*60); // new for commits hours
//				if(curExeCommit.isCheckFail())
//				{
//					commitFailApfd += commitAllApfd;
//					failCommits ++;
//					detectedFailCommits ++;
//					fApfd += (double)curPeriod/(double)(1000*60*60);
//				}
//				
////				Processor tempProcessor;
//				for(Processor p: processors)
//				{
//					if(p.isAvalable())
//					{
//						curExeCommit.calculateDuration();
//						p.startProcessing(curExeCommit, curExeCommit.getDuration());
////						System.out.println(curExeCommit.getDuration()+ ","+p.getRestTime());
//						availProNum --;
//						break;
//					}						
//				}
//			}	
//			
//			
////			System.out.println(availProNum);
//			/*
//			 * For each of processor, set the timer. "-1 millisecond"
//			 */
//			availProNum = 0;
//			for(Processor pTmp: processors)
//			{
//				if(!pTmp.isAvalable())
//					pTmp.setTimer();
//				if(pTmp.isAvalable())
//					availProNum ++;
//			}
//				
//			
//			curPercent_time = curPeriod/totalTimeLine;
//			
//			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
//			{
////				System.out.println((int)(expected_time*1000) + ","+ countFailNumber);
////				System.out.println((int)(expected_time*1000) + ": commits in the queue " +queue.size() + ": not arriving commits: " + allCommits.size());
////				System.out.println((double)(expected_time*100) + "," + prioritizeCommits.getPq().size() );
////				System.out.println((double)(expected_time*100) + "," +failCommits);
//				System.out.println((double)failCommits/totalFail);
////				System.out.println((double)failCommits);
////				System.out.println(prioritizeCommits.getPq().size() );
//				expected_time += 0.001;				
//			}
//			
//			lastPercent_time = curPercent_time;			
//			//update
////			calForFail.setTime(new Date(buildStartTime.getTime()));			
//			calForFail.add(Calendar.MILLISECOND, 1); 
//												
//			currentTime =  new Timestamp(calForFail.getTime().getTime());	
//			wholeRestTime --;
//				
//			
//		}
////		System.out.println("avgInterval= " + interval/(double)totalNumOfCommits);
//	}
////	
	/*
	 * Simulate the process with queues
	 */
//	private List<Double> results;
	public void simulateProcess(PrioritizeCommits prioritizeCommits, ExeRecord exeRec, int failWindow, int executionWindow,  int numOfProcessor, 
			List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, boolean[]> isSizeFail, double rate)
	{	
//		results = new ArrayList<Double>();
		
		double timePassed = 0;
		double totalFail = 267;
		double totalFailTests = 1579;
		
		
		double totalTime =0;
		if(this.selectedStage.equals("pres"))
		{
			totalFail = 267;
			totalFailTests = 1579;
		}
		else
		{
			totalFail = 1022;
			totalFailTests = 4926;
		}
				
		double totalQueueSize = 0;
		double timesQueue =0;

		double curPeriod = 0;
		setNewArrivalTime(rate);
		/*
		 * initialize the required number of processors
		 */
		List<Processor> processors = new ArrayList<Processor>();
		int availProNum = numOfProcessor;
		for(int i=0; i<numOfProcessor; i++)
		{
			Processor temp = new Processor();
			processors.add(temp);
		}
		
		Commit firstCommit = allCommits.poll();//get the first commit
		totalNumOfCommits ++;
		prioritizeCommits.updateCommits(firstCommit);

		Timestamp buildStartTime = prioritizeCommits.getPq().peek().getCommitArrivalTime();
		
//		lastArrivalTime = buildStartTime;
//		cuArrivalTime = lastArrivalTime;
//		System.out.println(buildStartTime);
		
		
					
		calForFail.setTime(new Date(buildStartTime.getTime()));			 
		currentTime =  new Timestamp(calForFail.getTime().getTime());
		
		while(!prioritizeCommits.getPq().isEmpty() || !allCommits.isEmpty())
		{					
			curPeriod = ((double)currentTime.getTime()-(double)buildStartTime.getTime());
						
			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
			{
				/*
				 * Commit
				 */
//				System.out.println((double)(expected_time*100)+","+(double)failCommits*100/totalFail);
				System.out.println(((double)failCommits*100/totalFail));
				
				/*
				 * Tests
				 */
//				System.out.println((double)(expected_time*100)+","+(double)accumulateExe.getCountFailNumber()*100/totalFailTests);
//				System.out.println((double)accumulateExe.getCountFailNumber()*100/totalFailTests);
				
				/*
				 * queue size
				 */
//				System.out.println((double)(expected_time*100)+","+prioritizeCommits.getPq().size());
//				System.out.println(prioritizeCommits.getPq().size());
//				totalQueueSize +=prioritizeCommits.getPq().size();
//				timesQueue ++;
				
				expected_time += 0.01;				
			}
			else if(curPercent_time > expected_time )
			{
				while(expected_time < curPercent_time)
				{
					/*
					 * Commit
					 */
//					System.out.println((double)(expected_time*100)+","+(double)failCommits*100/totalFail);
					System.out.println(((double)failCommits*100/totalFail));
					
					/*
					 * Tests
					 */
//					System.out.println((double)(expected_time*100)+","+(double)accumulateExe.getCountFailNumber()*100/totalFailTests);
//					System.out.println((double)accumulateExe.getCountFailNumber()*100/totalFailTests);
					
					/*
					 * queue size
					 */
//					System.out.println((double)(expected_time*100)+","+prioritizeCommits.getPq().size());
//					System.out.println(prioritizeCommits.getPq().size());
//					totalQueueSize +=prioritizeCommits.getPq().size();
//					timesQueue ++;
					
					expected_time += 0.01;		
				}
			}
			lastPercent_time = curPercent_time;		//update
			
			
			// if the commit arrival time is current time then push it into the queue.
			while(!allCommits.isEmpty() && (allCommits.peek().getCommitArrivalTime().equals(currentTime) || allCommits.peek().getCommitArrivalTime().before(currentTime))) 
			{	
				Commit temp = allCommits.poll();
				totalNumOfCommits ++;
//				temp.setCommitEnterQueueTime(System.currentTimeMillis());
				temp.setCommitEnterQueueTime(curPercent_time);
				prioritizeCommits.updateCommits(temp);	
				
//				System.out.println("come:"+temp.getId() +"; " + currentTime);
			}
						
			// if the queue is not empty, and there exists available processors
			while(!prioritizeCommits.getPq().isEmpty() && availProNum > 0)
			{
				
//				System.out.println("xxx");
				long startTime = System.currentTimeMillis();
				
				prioritizeCommits.updateInformInnerCommits(selectedStage, exeRec, failWindow, executionWindow, failTest, javaTs, isSizeFail, numOfCommitExe);				
				long endTime   = System.currentTimeMillis();
				totalTime += endTime - startTime;
//				long pTime = endTime - startTime;;
//				System.err.println(totalTime);
				numP++;
				
				int size = prioritizeCommits.getPq().size();
//				System.err.println(totalTime);
				//max
				if(maxSize < size)
				{
					maxTime = endTime - startTime;
					maxSize = size;
				}
				
				
				numOfCommitExe ++;
				curExeCommit = prioritizeCommits.getPq().poll();	
//				long commitExitTime = System.currentTimeMillis();
				long commitExitTime = endTime;
//				long totalTime1 = commitExitTime - curExeCommit.getCommitEnterQueueTime();
				double totalTime1 = curPercent_time - curExeCommit.getCommitEnterQueueTime();
//				System.err.println(numOfCommitExe + ","+ totalTime1);
				System.err.println(totalTime1);
				
//				if(numOfCommitExe == 750)
//					System.err.println("numOfCommitExe: " + numOfCommitExe + ", TimePassed: " + timePassed +", numOfFailingCommits: " + failCommits + ", number tests: "+accumulateExe.getCountNumber());
				
				if(!isIntra)
					curExeCommit.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, numOfCommitExe, curPeriod);
				else
					curExeCommit.updateProcessCommit_Intra(accumulateExe, selectedStage, exeRec, updateExeRecords, numOfCommitExe, curPeriod, failWindow, executionWindow);
					
				commitAllApfd ++; 
//				cApfd += (double)curPeriod/(double)(1000*60*60); // new for commits hours
				if(curExeCommit.isCheckFail())
				{
					commitFailApfd += commitAllApfd;
					failCommits ++;
					detectedFailCommits ++;
					fApfd += (double)curPeriod/(double)(1000*60*60);
				}
//				else
//				{
//					curExeCommit.calculateDuration();
//					System.err.println(curExeCommit.getDuration());
//				}
				
//				Processor tempProcessor;
				for(Processor p: processors)
				{
					if(p.isAvalable())
					{
						curExeCommit.calculateDuration();
						p.startProcessing(curExeCommit, curExeCommit.getDuration());
//						System.out.println(curExeCommit.getId()+ ","+p.getRestTime());
						availProNum --;
						break;
					}						
				}
				if(!prioritizeCommits.getPq().isEmpty())
					numP++;
			}
			

			/*
			 * jump to the next commit exe time
			 */
			double nextTime = 0;
			boolean isFirst = true;
			for(int i=0; i<processors.size(); i++)
			{
				if(!processors.get(i).isAvalable())
				{
					if(isFirst)
					{
						isFirst = false;
						nextTime = processors.get(i).getRestTime();
					}
					else
					{
						if(processors.get(i).getRestTime() < nextTime)
						{
							nextTime = processors.get(i).getRestTime();
						}
					}
				}	
			}
			
			if(!allCommits.isEmpty())
			{
				double tempPeriod = allCommits.peek().getCommitArrivalTime().getTime() - currentTime.getTime();
//				System.out.println(tempPeriod);
				if(isFirst)
					nextTime = tempPeriod;
			}
//			System.out.println(nextTime);
//			if(!isFirst) // this means there is processor is released
			{
				availProNum = 0;
				for(Processor p: processors) // reset all the timer
				{
					if(!p.isAvalable())
					{
						p.setTimer(nextTime);						
					}
					if(p.isAvalable())
						availProNum ++;
				}
				calForFail.add(Calendar.MILLISECOND, (int)nextTime); 				
				currentTime =  new Timestamp(calForFail.getTime().getTime());	
			}
//			
			
			
			timePassed += nextTime;
			
			curPercent_time = timePassed/totalTimeLine;					
		}
		/*
		 * Commit
		 */
//		System.out.println((double)(expected_time*100)+","+(double)failCommits*100/totalFail);
		System.out.println(((double)failCommits*100/totalFail));
//		
		/*
		 * Tests
		 */
//		System.out.println((double)(expected_time*100)+","+(double)accumulateExe.getCountFailNumber()*100/totalFailTests);
//		System.out.println((double)accumulateExe.getCountFailNumber()*100/totalFailTests);
		
		/*
		 * queue size
		 */
//		System.out.println((double)(expected_time*100)+","+prioritizeCommits.getPq().size());
//		System.out.println(prioritizeCommits.getPq().size());
//		totalQueueSize +=prioritizeCommits.getPq().size();
//		timesQueue ++;
		
		System.out.println();
		
//		System.err.println("numOfCommitExe: " + numOfCommitExe + ", TimePassed: " + timePassed  + ", numOfFailingCommits: " + failCommits + ", number tests: "+accumulateExe.getCountNumber());
//		System.out.println("avg queue size: "+ (double)(totalQueueSize/timesQueue));
//		System.out.println("totalTime= " + timePassed );
		
		
//		System.err.println("maxTime: "+ maxTime +"; queueSize: " + maxSize);
//		double avgPrioritizTime = totalTime/(double)numP;	
//		System.err.println(numP + ","+ avgPrioritizTime);
		System.err.println("number of times that the algorithms is called: "+numP);
		
	}
////	
	
	/*
	 * Optimal
	 */
//	
//	public void simulateProcess(PrioritizeCommits prioritizeCommits, ExeRecord exeRec, int failWindow, int executionWindow,  int numOfProcessor, 
//			List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, boolean[]> isSizeFail, double rate)
//	{
//		/*
//		 * initialize the required number of processors
//		 */
//		List<Processor> processors = new ArrayList<Processor>();
//		int availProNum = numOfProcessor;
//		for(int i=0; i<numOfProcessor; i++)
//		{
//			Processor temp = new Processor();
//			processors.add(temp);
//		}
//		
////		Commit firstCommit = allCommits.poll();//get the first commit
////		totalNumOfCommits ++;
//		
//		
//		double timePassed = 0;
//		double totalFail = 267;
//		if(this.selectedStage.equals("pres"))
//			totalFail = 267;
//		else
//			totalFail = 1022;
//		
//		
//		while(!allCommits.isEmpty())
//		{					
////			curPeriod = ((double)currentTime.getTime()-(double)buildStartTime.getTime());
//			// if the commit arrival time is current time then push it into the queue.
//			while(!allCommits.isEmpty() && availProNum > 0) 
//			{	
//				numOfCommitExe ++;
//				curExeCommit = allCommits.poll();
//				curExeCommit.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, numOfCommitExe);
//
////				System.out.println(curExeCommit.isCheckFail());
//				totalNumOfCommits ++;	
//				
//				commitAllApfd ++; 
////				cApfd += (double)curPeriod/(double)(1000*60*60); // new for commits hours
//				if(curExeCommit.isCheckFail())
//				{
//					commitFailApfd += commitAllApfd;
//					failCommits ++;
//					detectedFailCommits ++;
//					fApfd += (double)timePassed/(double)(1000*60*60);
////					System.out.println(timePassed*100/totalTimeLine + ","+ (double)detectedFailCommits/totalFail);
////					System.out.println(timePassed);
//				}
//				
////				Processor tempProcessor;
//				for(Processor p: processors)
//				{
//					if(p.isAvalable())
//					{
////						curExeCommit.calculateDuration();
////						System.out.println("dur:" + curExeCommit.getDuration());
//						p.startProcessing(curExeCommit, curExeCommit.getDuration());
////						System.out.println(curExeCommit.getId()+ ","+p.getRestTime());
//						availProNum --;
//						break;
//					}						
//				}
////				System.out.println("come:"+temp.getId() +"; " + currentTime);
//			}
//			
//
//			/*
//			 * jump to the next commit exe time
//			 */
//			double nextTime = 0;
//			boolean isFirst = true;
//			for(int i=0; i<processors.size(); i++)
//			{
//				if(!processors.get(i).isAvalable())
//				{
//					if(isFirst)
//					{
//						isFirst = false;
//						nextTime = processors.get(i).getRestTime();
//					}
//					else
//					{
//						if(processors.get(i).getRestTime() < nextTime)
//						{
//							nextTime = processors.get(i).getRestTime();
//						}
//					}
//				}	
//			}
//			
////			if(!allCommits.isEmpty())
////			{
////				double tempPeriod = allCommits.peek().getCommitArrivalTime().getTime() - currentTime.getTime();
////				if(isFirst)
////					nextTime = tempPeriod;
////			}
////			System.out.println(nextTime);
//			if(!isFirst) // this means there is processor is released
//			{
////				availProNum = 0;
//				for(Processor p: processors) // reset all the timer
//				{
//					if(!p.isAvalable())
//					{
//						p.setTimer(nextTime);	
//						
//						if(p.isAvalable())
//						{
//							availProNum ++;
//						}
//					}
//					
//				}
//				timePassed += nextTime;
////				System.out.println(nextTime + ":"+timePassed + "; commit num: " + numOfCommitExe);
//			}
//			
//			curPercent_time = timePassed/totalTimeLine;
////			
//			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
//			{
//				System.out.println((double)failCommits*100/totalFail);
////				System.out.println((double)(expected_time*100)+","+(double)failCommits*100/totalFail);
////				System.out.println((double)failCommits);
////				System.out.println(prioritizeCommits.getPq().size() );
//				expected_time += 0.001;				
//			}
//			else if(curPercent_time > expected_time )
//			{
//				while(expected_time < curPercent_time)
//				{
//					System.out.println((double)failCommits*100/totalFail);
////					System.out.println((double)(expected_time*100)+","+(double)failCommits*100/totalFail);
//					expected_time += 0.001;		
//				}
//			}
//			
//			lastPercent_time = curPercent_time;			
//			//update
////			calForFail.setTime(new Date(buildStartTime.getTime()));			
////			calForFail.add(Calendar.MILLISECOND, 1); 
//												
////			currentTime =  new Timestamp(calForFail.getTime().getTime());	
////			wholeRestTime --;
////			
////					
//		}
//		
////		System.out.println("avgInterval= " + interval/(double)totalNumOfCommits);
//	}
////		
	
	/*
	 * Get the % of time and queue size
	 */
	public void simulateProcess()
	{
		double restTime = this.totalTimeLine;
		System.out.println("restTime" + restTime);
		
		int periodNumExeCommits = 0;
//		
//		int total = 0;		
//		while(!allCommits.isEmpty())
//		{
//			Commit temp = allCommits.poll();
//			System.out.println(temp.getExeStartTime() + "," + temp.getCommitArrivalTime() + "," + temp.getDuration() +";" + tem);
////			total += (temp.commitShiftEndTime().getTime() - temp.getCommitArrivalTime().getTime());
//			total ++;
//		}
////		System.out.println(totalExeTime);
//		System.out.println(total);
		
		Commit firstCommit = allCommits.poll();//get the first commit
		queue.offer(firstCommit);
//		System.out.println(firstCommit.getId());
		curExeCommit = queue.poll();
		
		isOccupied = true;
		numOfCommitExe ++;
		
		periodNumExeCommits ++;
		
//		restTime = curExeCommit.getDuration()-1;
//		System.out.println(currentTime + ":" + numOfCommitExe);

		Timestamp buildStartTime = curExeCommit.getCommitArrivalTime();
		System.out.println(buildStartTime);
					
		calForFail.setTime(new Date(buildStartTime.getTime()));			 
		currentTime =  new Timestamp(calForFail.getTime().getTime());
		
		while(!queue.isEmpty() || !allCommits.isEmpty() || restTime > 0)
		{		
//			percentOfCurrentTime = ((double)currentTime.getTime()-(double)buildStartTime.getTime())/totalExeTime;
			
//			// if the current commit has finished, then check if the queue is empty; if not then pop new one to execute
//			if(restTime <= 0)
////			if(curExeCommit.commitShiftEndTime().before(currentTime))
//			{
//				isOccupied = false;
//			}
			
			// if the commit arrival time is current time then push it into the queue.
			while(!allCommits.isEmpty() && (allCommits.peek().getCommitArrivalTime().equals(currentTime) || allCommits.peek().getCommitArrivalTime().before(currentTime))) 
			{
				Commit temp = allCommits.poll();
				queue.offer(temp);
//				System.out.println("exe2222: "+temp.getId() + " : "+ temp.getPercentStartTime());
			}
			
			// if the commit is executed, then pop it out
			while(!queue.isEmpty() && (queue.peek().getExeStartTime().equals(currentTime) || queue.peek().getExeStartTime().before(currentTime)))
			{
				Commit t = queue.poll();
//				System.out.println("poll 1: " + numOfCommitExe +"; exe Commit time: " + t.getExeStartTime() + "; exe Commit arrivale time: " + t.getCommitArrivalTime() +"; currentTime:" + currentTime  + "; restTime:" + restTime);				
				numOfCommitExe ++;
				periodNumExeCommits ++;
			}
					
			curPercent_time = ((double)currentTime.getTime()-(double)buildStartTime.getTime())/totalTimeLine;
			
			if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
			{
//				System.out.println((int)(expected_time*1000) + ","+ countFailNumber);
//				System.out.println((int)(expected_time*1000) + ": commits in the queue " +queue.size() + ": not arriving commits: " + allCommits.size());
				System.out.println((double)(expected_time*100) + "," + queue.size() );
//				System.out.println((double)(expected_time*100) + "," + periodNumExeCommits );
				periodNumExeCommits = 0;
				
				expected_time += 0.01;				
			}
			
			lastPercent_time = curPercent_time;			
			//update
//			calForFail.setTime(new Date(buildStartTime.getTime()));			
			calForFail.add(Calendar.MILLISECOND, 1); 
												
			currentTime =  new Timestamp(calForFail.getTime().getTime());	
			restTime --;
//			curExeCommit_restTime --;
		}
	}
	
	
	
	
	
	
	
//	//to get the concurrent commits
//	public void setConcurrent()
//	{
//		int number = 0;
//		Commit commit;
//		Stack<Commit> stack = new Stack<Commit>();
//		Commit temp;
//		while(!allCommits.isEmpty())
//		{
//			commit = allCommits.pollFirst();
//			while(!allCommits.isEmpty() && allCommits.peekFirst().getExeStartTime().before(commit.getExeEndTime()))
//			{
//				temp = allCommits.pollFirst();
//				commit.addConcurrentNum();// add one to the commit
//				temp.addConcurrentNum(); // add one the temp
//				stack.push(temp);
//			}
//	//		pq.offer(commit); 
////			System.out.println(commit.getId() + "," + commit.getConcurrentNum());
//			while(!stack.isEmpty())
//			{
//				temp = stack.pop();
//				allCommits.offerFirst(temp);
//			}
//			number += 1;
//		}
//		
//		System.out.println(number);
//		
////		while(allCommit.offerLast(exeCommit))
//	}
	
	
	
	
//	public void simulateProcess(PrioritizeCommits prioritizeCommits, ExeRecord exeRec, int failWindow, int executionWindow,  List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, boolean[]> isSizeFail)
//	{
//		Commit firstCommit = allCommits.poll();//get the first commit
//		prioritizeCommits.updateCommits(firstCommit);
////		curExeCommit_restTime = 0;
//		currentTime = 0; 
//		while(!prioritizeCommits.getPq().isEmpty() || !allCommits.isEmpty())
//		{
//			percentOfCurrentTime = currentTime/totalTimeLine;
//			
//			// put all the arrived commits into the queue
//			while(!allCommits.isEmpty() && allCommits.peek().getPercentStartTime() <= percentOfCurrentTime ) 
//			{
//				Commit temp = allCommits.poll();
//				prioritizeCommits.updateCommits(temp);
////				System.out.println("exe2222: "+temp.getId() + " : "+ temp.getPercentStartTime());
//			}
//						
//			if(!prioritizeCommits.getPq().isEmpty()) // if the queue is not empty, then pop the one and execut it
//			{
//				prioritizeCommits.updateInformInnerCommits(selectedStage, exeRec, failWindow, executionWindow, failTest, javaTs, isSizeFail, numOfCommitExe);	
//				numOfCommitExe ++;	
//				curExeCommit = prioritizeCommits.getPq().poll();
//				currentTime += curExeCommit.getCommit_totalExeTime();
//				curExeCommit.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, numOfCommitExe);
//								
//				commitAllApfd ++; 
//				if(curExeCommit.isCheckFail())
//				{
//					commitFailApfd += commitAllApfd;
//					failCommits ++;
//					detectedFailCommits ++;
//				}
////					System.out.println(failCommits);
//	//				System.out.println("fail ratio: "+ c.getFailRatio()
//	//							   + ", exe ratio: " + c.getExeRatio() 
//	//							   + ", % of fail: " + c.getRatio_fail());
////				curExeCommit_restTime = curExeCommit.getCommit_totalExeTime();		
//				//for testing
////				System.out.println(numOfCommitExe);
////				System.out.println("exe: "+curExeCommit.getId() + " : "+curExeCommit.getPercentStartTime());
//			}
//			else if(!allCommits.isEmpty())
//			{
////				prioritizeCommits.updateInformInnerCommits(selectedStage, exeRec, failWindow, executionWindow, cf, failTest, javaTs, isSizeFail, exeNumOfCommit);	
//				numOfCommitExe ++;	
//				curExeCommit = allCommits.poll();
//				currentTime = allCommits.peek().getPercentStartTime()*totalTimeLine + curExeCommit.getCommit_totalExeTime();
//				curExeCommit.updateProcessCommit(accumulateExe, selectedStage, exeRec, updateExeRecords, numOfCommitExe);
//				
//				commitAllApfd ++; 
//				if(curExeCommit.isCheckFail())
//				{
//					commitFailApfd += commitAllApfd;
//					failCommits ++;
//					detectedFailCommits ++;
//				}
////					System.out.println(failCommits);
//	//				System.out.println("fail ratio: "+ c.getFailRatio()
//	//							   + ", exe ratio: " + c.getExeRatio() 
//	//							   + ", % of fail: " + c.getRatio_fail());
////				curExeCommit_restTime = curExeCommit.getCommit_totalExeTime();		
//				//for testing
////				System.out.println(numOfCommitExe);
////				if()
//			}
//			
//		}
//	
//	}
	
	

	public int getNumOfCommitExe() {
		return numOfCommitExe;
	}

	public void setNumOfCommitExe(int numOfCommitExe) {
		this.numOfCommitExe = numOfCommitExe;
	}

	public Queue<Commit> getQueue() {
		return queue;
	}

//	public void setQueue(Queue<Commit> queue) {
//		this.queue = queue;
//	}


	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}


	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}

	public double getCommitFailApfd() {
		return commitFailApfd;
	}


	public void setCommitFailApfd(double commitFailApfd) {
		this.commitFailApfd = commitFailApfd;
	}


	public double getCommitAllApfd() {
		return commitAllApfd;
	}


	public void setCommitAllApfd(double commitAllApfd) {
		this.commitAllApfd = commitAllApfd;
	}


	public int getFailCommits() {
		return failCommits;
	}


	public void setFailCommits(int failCommits) {
		this.failCommits = failCommits;
	}


	public int getDetectedFailCommits() {
		return detectedFailCommits;
	}


	public void setDetectedFailCommits(int detectedFailCommits) {
		this.detectedFailCommits = detectedFailCommits;
	}


	public int getTotalNumOfCommits() {
		return totalNumOfCommits;
	}


	public void setTotalNumOfCommits(int totalNumOfCommits) {
		this.totalNumOfCommits = totalNumOfCommits;
	}


//	public double getcApfd() {
//		return cApfd;
//	}
//
//
//	public void setcApfd(double cApfd) {
//		this.cApfd = cApfd;
//	}


	public double getfApfd() {
		return fApfd;
	}


	public void setfApfd(double fApfd) {
		this.fApfd = fApfd;
	}


}
