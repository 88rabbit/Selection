#!/bin/bash

libDir=../lib
srcDir=../src
binDir=../bin


inputParameter_1=96   #failWindow
inputParameter_2=1	  #exeWindow
inputParameter_3=hours	#failmmhh
inputParameter_4=hours # exemmhh
inputParameter_7=1 #repetitiveWindow
inputParameter_8=hours #repetitivemmhh

inputParameter_5=post	
inputParameter_6=post   #selected stage

inputParameter_9=8       #coeff_f: previous coeff1 (previous b) failue  ------time since last fail failurs
inputParameter_10=800	   # coeff_e: previous coeff3. a constant a (previous h) decay  ------- time since last fail
inputParameter_11=3     # compared number
inputParameter_12=2    #coeff_s: previous coeff2   skip

# for inputParameter_12 in 2 8 32 128 512 2048
# for inputParameter_12 in 4096 8192
# do
		# coeff3
		# for inputParameter_10 in 70
		for inputParameter_10 in 55
		# for inputParameter_10 in 1 2 4 5 10 100
		do
			#coeff1
			# for inputParameter_9 in 1 2 4 5 10 100
			for inputParameter_9 in 100
			# for inputParameter_9 in 256
			do
		#compile the program
		javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

		# with option -h, the list of options will show up
		java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

		#run the program with parameters
		java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=travisDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -x=$inputParameter_7 -y=$inputParameter_8 -B=$inputParameter_9 -H=$inputParameter_10 -C=$inputParameter_11 -t=$inputParameter_12

        done 
	done
# done