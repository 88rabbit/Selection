package executeTS;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Random;

import exeRecord.ExeRecord;
import readFile.ReadInFailedTestSuiteRegularPatterns;
import testSuites.TestSuite;

public class SelectTestSuites 
{	
	//for counting number of all TestSuites
	private Accumulation accumulateAll;
			
	//for counting number of executed TestSuites
	private Accumulation accumulateExe;
	
	private Accumulation accumulateExeTemp;
	
	private UpdateExeRecord updateExeRecords = new UpdateExeRecord();
	
	private double windowSize = 0;
	
	public SelectTestSuites(int distinctTsNum) {
		super();
		this.accumulateAll = new Accumulation(distinctTsNum);
		this.accumulateExe = new Accumulation(distinctTsNum);
		this.accumulateExeTemp = new Accumulation(distinctTsNum);
		
	}
	
	/*
	 * We+Wf+TF 
	 */
	
	public void selectTs(TestSuite lastTs,Timestamp failStartTime,Timestamp executeStartTime, String selectedStage, 
			ExeRecord exeRec, String alwaysExecutedStage, double percent, double deltaFail, Map<Integer, Integer[]> id_max_min )
	{
		/*
		 * update the number of TestSuite and the execution time of TestSuite
		 */
		//counting
//		this.accumulateAll.counting(lastTs, selectedStage);		
//		double totalNum = 0;
//		double percent = 0.30;
		if(selectedStage.equals("post"))
		{
//			totalNum = 1460531.0;
			windowSize = percent * 257; //30% of median number of test suites execution times
		}
		else 
		{
//			totalNum = 1045345.0;
			windowSize = percent * 193; //30% of median number of test suites execution times
		}
		
				
		/*
		 * Dynamic range case
		 */
		double min_p = 1;
		double max_f = 1;
//		double max_p = 1;
		double min_p_delta = 1;
		if(lastTs.getLast_stage().equals(selectedStage))  // for only posts or pres
		{
//			count ++;
//			executedPercent = count*100/totalNum;
//			if(executedPercent < 30)
//			{
//				updateExeRecords.updateDetails(false, exeRec, lastTs, accumulateExeTemp, selectedStage, true);
//				exeRec.setRecordPrePass(lastTs.getTsId());
//			}
//			else
			{
//				this.accumulateAll.counting(lastTs, selectedStage);		
				
//				/*
//				 * if the test suite has failure history
//				 */
//				if(exeRec.getHasMin_p()[lastTs.getTsId()])
//				{
//					min_p_delta = exeRec.getMin_p()[lastTs.getTsId()];
//					max_p = exeRec.getMax_p()[lastTs.getTsId()];
//				}
//				else
//				{
//					min_p_delta = deltaExe;
//					max_p = exeRec.getMinOfMaxPass();
////					System.out.println(max_p);
//				}
//				double failRatioWithinWindow = (double)exeRec.getNumberOfFailTimesWithinWindow()[lastTs.getTsId()]*100/(double)windowSize;

				min_p_delta = Math.min(windowSize, exeRec.getMin_p()[lastTs.getTsId()]);
				/*
				 * Min(Max_p) from F
				 */
//				max_p = exeRec.getMinOfMaxPass();
				
				if(exeRec.getHasMax_f()[lastTs.getTsId()])
					max_f = exeRec.getMax_f()[lastTs.getTsId()];
				{
				//1. for new tests and warm up
				if(exeRec.getIsExecuted()[lastTs.getTsId()] == false || exeRec.getNumOfExe()[lastTs.getTsId()] < windowSize )
				{	
					updateExeRecords.updateDetails(false, exeRec, lastTs, accumulateExeTemp, selectedStage, true);	
					exeRec.setPreExeTimes(lastTs.getTsId(), 0);
					exeRec.setPf_num(lastTs.getTsId(), 0);
					accumulateAll.setStatus(lastTs.getTsId(), lastTs.getLast_status());
					accumulateExe.setStatus(lastTs.getTsId(), lastTs.getLast_status());
				}
//				//for execution Window selection
////				else if(exeRec.getTimesSinceLastExe()[lastTs.getTsId()] >= min_p_delta 
////						|| (exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[lastTs.getTsId()]<=deltaFail))
//				else if(exeRec.getTimesSinceLastExe()[lastTs.getTsId()] >= min_p_delta)
//				{
//						this.accumulateAll.counting(lastTs, selectedStage);
//						updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, true);	
////						if(lastTs.isFail())
//							countExe ++;
//				}			
				else if(!exeRec.getIsFail()[lastTs.getTsId()] 
						&& exeRec.getTimesSinceLastExe()[lastTs.getTsId()] >= ((exeRec.getPreExeTimes()[lastTs.getTsId()]*0.5+1)*windowSize))
				{
						this.accumulateAll.counting(lastTs, selectedStage);
						updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, true);
//						
				}
				else if(exeRec.getIsFail()[lastTs.getTsId()] 
						&& exeRec.getTimesSinceLastExe()[lastTs.getTsId()] >= min_p_delta)
				{
					this.accumulateAll.counting(lastTs, selectedStage);
					updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, true);	
				}
				else if(exeRec.getNumberOfFailTimesWithinWindow()[lastTs.getTsId()] > 0)
//				else if(failRatioWithinWindow > random_zeroToOne)
//				else if (exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>exeRec.getNumberOfFailTimesWithinWindow()[lastTs.getTsId()])
//				else if((exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[lastTs.getTsId()]<=deltaFail))			
				{
					this.accumulateAll.counting(lastTs, selectedStage);
					updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, true);	
				}
//				for regex
				else 
				{	
					this.accumulateAll.counting(lastTs, selectedStage);
					
					if(exeRec.getHasMin_p()[lastTs.getTsId()])
						min_p = exeRec.getMin_p()[lastTs.getTsId()];
						
					if(exeRec.getHasMax_f()[lastTs.getTsId()])
						max_f = exeRec.getMax_f()[lastTs.getTsId()];
						/*
						 * Key: test id
						 * 
						 * Condition:
						 * if ti.numContinuousPass == min_p || 0 < ti.numContinuousFail < max_f
						 * 		execute
						 * else
						 * 		skip
						 * 
						 */
					if(exeRec.getIsFail()[lastTs.getTsId()] && exeRec.getPre_pass_times()[lastTs.getTsId()] == min_p) //min_p
					{
						updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, true);
					}
					else if(exeRec.getPre_fail_times()[lastTs.getTsId()] > 0 && exeRec.getPre_fail_times()[lastTs.getTsId()] < max_f ) //max_f
//					else if(exeRec.getPre_fail_times()[lastTs.getTsId()] > 0)
					{
						updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, true);	
					}
					else
					{
						updateExeRecords.updateDetails(true, exeRec, lastTs, accumulateExe, selectedStage, false);	
					}
				}
			}
				
		}
		}
	}
	

	public Accumulation getAccumulateAll() {
		return accumulateAll;
	}

	public void setAccumulateAll(Accumulation accumulateAll) {
		this.accumulateAll = accumulateAll;
	}

	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}

	

	
	
	
}
