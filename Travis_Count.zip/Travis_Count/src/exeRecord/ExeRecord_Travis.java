package exeRecord;

import java.sql.Timestamp;
import testSuites.TestSuite_Travis;

public class ExeRecord_Travis 
{
	//for decay
	private double[] Ck;
	private int[] Ts_recordNum; // to record the execution times of a certain Ts
	
	
	private boolean[] isExecuted;
	private boolean[] isFail_Ts ;
	private boolean[] isError_Ts;
	private boolean[] isFailError_Ts;
	
	private Timestamp[] Ts_failTime; //Ts_start_time
	private Timestamp[] Ts_errorTime;
	private Timestamp[] Ts_failErrorTime;
	
	private String[] Ts_state;
	
	private int[] TsId;
	private double[] Ts_duration;	 //Ts execution time
	private int[] Ts_runs;
	private int[] Ts_assertions;
	private int[] Ts_failures;
	private int[] Ts_errors;
	private int[] Ts_skips;
	private Timestamp[] Ts_start_time; //Ts launch time
	
	private int[] Build_id;
	private int[] Build_number;
	private String[] Build_state;
	private Timestamp[] Build_start_time;
	private Timestamp[] Build_finish_time;
	private double[] Build_duration;
	
	private int[] Job_id;
	private int[] Job_number;
	private String[] Job_state;
	private Timestamp[] Job_start_time;
	private Timestamp[] Job_finish_time;
//	private double[] Job_duration;
	
	private int[] Repository_id;
	private int[] Commit_id;
	private String[] Commit_sha;
	private String[] Commit_short_sha;
	
	
	//For decay's
	private double[] Ck_s;
	private double[] Ck_f;
	
	
	private int[] consecutiveExe;
	private int[] consecutiveSkip;
	private int[] consecutiveFail;
	
	private int distinctTsNum;
		
	
	//Used for counting execution times and failure times
	private double[] timesSinceLastExe;
	private double[] timesSinceLastFail;
	private double[] timesSinceLastError;
	private double[] timesSinceLastFailError;
		
//	private double[] numOfFail;
//	private double[] numOfExe;
//	private double exeAfterFail=0; //total
	
	private double[] Ts_exeNum;
		
	private double[] pf_num; //count number of Pass->Fail transiotn
	private double[] pe_num; //count number of Pass->Error transiotn
	private double[] pef_num; //count number of Pass->FailError transiotn
	
	private double[] pf_num1; //count number of Pass->Fail transiotn
	private double[] pe_num1; //count number of Pass->Error transiotn
	private double[] pef_num1; //count number of Pass->FailError transiotn
	
	private double[] pf_percent; // count the percent of Pass->Fail transition
	private double[] pe_percent; // count the percent of Pass->Error transition
	private double[] pef_percent; // count the percent of Pass->FailError transition
	
	
	
	public void initializeRecord(int distinctTsNum)
	{
		this.distinctTsNum = distinctTsNum;
		
		//for decay
		Ck = new double[distinctTsNum];
		Ts_recordNum = new int[distinctTsNum];
		
		isExecuted = new boolean[distinctTsNum];
		
		isFail_Ts = new boolean[distinctTsNum];
		isError_Ts = new boolean[distinctTsNum];
		isFailError_Ts = new boolean[distinctTsNum];
		
		Ts_failTime = new Timestamp[distinctTsNum]; //Ts_start_time
		Ts_errorTime = new Timestamp[distinctTsNum];
		Ts_failErrorTime =  new Timestamp[distinctTsNum];
		
		Ts_state = new String[distinctTsNum];
		
		TsId = new int[distinctTsNum];
		Ts_duration = new double[distinctTsNum];	 //Ts execution time
		Ts_runs = new int[distinctTsNum];
		Ts_assertions=new int[distinctTsNum];
		Ts_failures = new int[distinctTsNum];
		Ts_errors = new int[distinctTsNum];
		Ts_skips = new int[distinctTsNum];
		Ts_start_time = new Timestamp[distinctTsNum]; //Ts launch time
		
		Build_id = new int[distinctTsNum];
		Build_number = new int[distinctTsNum];
		Build_state = new String[distinctTsNum];
		Build_start_time = new Timestamp[distinctTsNum];
		Build_finish_time = new Timestamp[distinctTsNum];
		Build_duration = new double[distinctTsNum];
		
		Job_id = new int[distinctTsNum];
		Job_number = new int[distinctTsNum];
		Job_state = new String[distinctTsNum];
		Job_start_time = new Timestamp[distinctTsNum];
		Job_finish_time = new Timestamp[distinctTsNum];
//		Job_duration = new double[distinctTsNum];
		
		Repository_id = new int[distinctTsNum];
		Commit_id = new int[distinctTsNum];
		Commit_sha = new String[distinctTsNum];
		Commit_short_sha = new String[distinctTsNum];
		
		//For decays
		Ck_s = new double[distinctTsNum]; //skip
		Ck_f = new double[distinctTsNum]; //fail
		
		consecutiveExe = new int[distinctTsNum];
		consecutiveSkip = new int[distinctTsNum];
		consecutiveFail = new int[distinctTsNum];
		
		//Used for counting execution times and failure times
		timesSinceLastExe = new double[distinctTsNum];
		timesSinceLastFail = new double[distinctTsNum];
		timesSinceLastError = new double[distinctTsNum];
		timesSinceLastFailError = new double[distinctTsNum];
		
		Ts_exeNum = new double[distinctTsNum];
		
		pf_num = new double[distinctTsNum];
		pe_num = new double[distinctTsNum];
		pef_num = new double[distinctTsNum];
		
		pf_num1 = new double[distinctTsNum];
		pe_num1 = new double[distinctTsNum];
		pef_num1 = new double[distinctTsNum];
		
		pf_percent = new double[distinctTsNum];
		pe_percent = new double[distinctTsNum];
		pef_percent = new double[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
			isExecuted[i] = false;
			
			isFail_Ts[i] = false ;
			isError_Ts[i] = false;	
			isFailError_Ts[i] = false;
			
			Ts_state[i] = "N";			
			TsId[i] = i;	
			
			Ts_recordNum[i] =0;
			Ck[i]=0;  //initialization
			
			//When initialized, they are set as zero
			Ck_s[i]=0;
			Ck_f[i]=0;
			
			consecutiveExe[i] =0;
			consecutiveSkip[i] =0;
			consecutiveFail[i]=0;
			
			//Used for counting execution times and failure times
			timesSinceLastExe[i] = 0;
			timesSinceLastFail[i] = -1;
			timesSinceLastError[i] = -1;
			timesSinceLastFailError[i] = -1;
			
			Ts_exeNum[i]=0;
			
			pf_num[i] = 0;
			pe_num[i] = 0;
			pef_num[i] = 0;
			
			pf_num1[i] = 0;
			pe_num1[i] = 0;
			pef_num1[i] = 0;
			
			pf_percent[i] = 0;
			pe_percent[i] = 0;
			pef_percent[i] = 0;
			
			
		}
	}
		
	public void updateTsRecord(TestSuite_Travis ts)
	{
		this.Ts_recordNum[ts.getTsId()]++;
		
		this.isExecuted[ts.getTsId()] = true;
		
		Ts_exeNum[ts.getTsId()]++;
		/*
		 * Others->Fail(or Error or FailError)
		 */
		if(!this.Ts_state[ts.getTsId()].equals(ts.getTs_state()))
		{
			if(ts.isFail_Ts() == true)  // if previous is passed and current is failed ==> transition PF
			{
				pf_num[ts.getTsId()] ++;
				pf_num1[ts.getTsId()] ++;
				pf_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/Ts_exeNum[ts.getTsId()];
//				System.out.println(pf_percent[ts.getTsId()]);
			}
			else if(ts.isError_Ts() == true)// if previous is passed and current is ERRORED ==> transition PE
			{
				pe_num[ts.getTsId()] ++;
				pe_num1[ts.getTsId()] ++;
				pe_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/Ts_exeNum[ts.getTsId()];
			}
			else if(ts.isFailError_Ts() == true)// if previous is passed and current is FAILERROR ==> transition PFE
			{
				pef_num[ts.getTsId()] ++;
				pef_num1[ts.getTsId()] ++;
				pef_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/Ts_exeNum[ts.getTsId()];
			}
		}
		
//	/*	
//	 * Pass->Fail(or Error or FailError)
//	 */
//		if(this.Ts_state[ts.getTsId()].equals("passed") )
//		{
//			if(ts.isFail_Ts() == true)  // if previous is passed and current is failed ==> transition PF
//			{
//				pf_num[ts.getTsId()] ++;
//				pf_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/Ts_exeNum[ts.getTsId()];
////				System.out.println(pf_percent[ts.getTsId()]);
//			}
//			else if(ts.isError_Ts() == true)// if previous is passed and current is ERRORED ==> transition PE
//			{
//				pe_num[ts.getTsId()] ++;
//				pe_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/Ts_exeNum[ts.getTsId()];
//			}
//			else if(ts.isFailError_Ts() == true)// if previous is passed and current is FAILERROR ==> transition PFE
//			{
//				pef_num[ts.getTsId()] ++;
//				pef_percent[ts.getTsId()] = pf_num[ts.getTsId()]*100/Ts_exeNum[ts.getTsId()];
//			}
//		}
		
		this.Ts_state[ts.getTsId()] = ts.getTs_state();
		
		this.Ts_duration[ts.getTsId()] = ts.getTs_duration();	 //Ts execution time
		this.Ts_runs[ts.getTsId()]= ts.getTs_runs();
		this.Ts_assertions[ts.getTsId()]=ts.getTs_assertions();
		this.Ts_failures[ts.getTsId()] = ts.getTs_failures();
		this.Ts_errors[ts.getTsId()] = ts.getTs_errors();
		this.Ts_skips[ts.getTsId()] = ts.getTs_skips();
		this.Ts_start_time[ts.getTsId()] = ts.getTs_start_time(); //Ts launch time
		
		timesSinceLastExe[ts.getTsId()]=0;
		
		//update isFail_Ts and isError_Ts
		if(ts.isFail_Ts()==true)
		{		
			this.Ts_failTime[ts.getTsId()] = ts.getTs_start_time();
			this.isFail_Ts[ts.getTsId()] = true;
					
			timesSinceLastFail[ts.getTsId()]=0;
					
			if(timesSinceLastError[ts.getTsId()]>=0) 
				timesSinceLastError[ts.getTsId()]++;
			if(timesSinceLastFailError[ts.getTsId()] >= 0)
				timesSinceLastFailError[ts.getTsId()] ++;
		}
		else if(ts.isError_Ts()==true)
		{	
			this.Ts_errorTime[ts.getTsId()] = ts.getTs_start_time();
			this.isError_Ts[ts.getTsId()] = true;
					
			timesSinceLastError[ts.getTsId()] = 0;
					
			if(timesSinceLastFail[ts.getTsId()]>=0)
				timesSinceLastFail[ts.getTsId()]++;
			if(timesSinceLastFailError[ts.getTsId()] >= 0)
				timesSinceLastFailError[ts.getTsId()] ++;
		}		
		else if(ts.isFailError_Ts()==true)
		{
			this.Ts_failErrorTime[ts.getTsId()] = ts.getTs_start_time();
			this.isFailError_Ts[ts.getTsId()] = true;
					
			timesSinceLastFailError[ts.getTsId()] = 0;
					
			if(timesSinceLastFail[ts.getTsId()]>=0)
				timesSinceLastFail[ts.getTsId()]++;
			if(timesSinceLastError[ts.getTsId()]>=0) 
				timesSinceLastError[ts.getTsId()]++;
		}
		else
		{
			if(timesSinceLastFail[ts.getTsId()]>=0)
				timesSinceLastFail[ts.getTsId()]++;
			if(timesSinceLastError[ts.getTsId()]>=0) 
				timesSinceLastError[ts.getTsId()]++;
			if(timesSinceLastFailError[ts.getTsId()] >= 0)
				timesSinceLastFailError[ts.getTsId()] ++;
		}
		
//		//update isFail_Ts and isError_Ts
//		if(ts.isFail_Ts()==true && ts.isError_Ts()==true)
//		{		
//			this.Ts_failTime[ts.getTsId()] = ts.getTs_failTime();
//			
//			this.isFail_Ts[ts.getTsId()] = true;
//			this.isError_Ts[ts.getTsId()] = true;
//
//			timesSinceLastFail[ts.getTsId()]=0;
//		}
//		else if(ts.isFail_Ts()==true)
//		{		
//			this.Ts_failTime[ts.getTsId()] = ts.getTs_failTime();
//			
//			this.isFail_Ts[ts.getTsId()] = true;
//			
//			timesSinceLastFail[ts.getTsId()]=0;
//						
//			
//		}
//		else if(ts.isError_Ts()==true)
//		{		
//			this.isError_Ts[ts.getTsId()] = true;
//		
//		}		
//		else
//		{
//			if(timesSinceLastFail[ts.getTsId()]>=0)
//			{
//				timesSinceLastFail[ts.getTsId()]++;
//			}
//			
//		}
		
		
		this.Build_id[ts.getTsId()] = ts.getBuild_id();
		this.Build_number[ts.getTsId()] = ts.getBuild_number();
		this.Build_state[ts.getTsId()] = ts.getBuild_state();
		this.Build_start_time[ts.getTsId()] = ts.getBuild_start_time();
		this.Build_finish_time[ts.getTsId()] = ts.getBuild_finish_time();
		this.Build_duration[ts.getTsId()] = ts.getBuild_duration();
		
		this.Job_id[ts.getTsId()] = ts.getJob_id();
		this.Job_number[ts.getTsId()] = ts.getJob_number();
		this.Job_state[ts.getTsId()] = ts.getJob_state();
		this.Job_start_time[ts.getTsId()] = ts.getJob_start_time();
		this.Job_finish_time[ts.getTsId()] = ts.getJob_finish_time();
//		this.Job_duration[ts.getTsId()] = ts.getJob_duration();
		
		this.Repository_id[ts.getTsId()] = ts.getRepository_id();
		this.Commit_id[ts.getTsId()] = ts.getCommit_id();
		this.Commit_sha[ts.getTsId()] = ts.getCommit_sha();
		this.Commit_short_sha[ts.getTsId()] = ts.getCommit_short_sha();
			
	}
	
	//for decay
	public void updateGrow(TestSuite_Travis ts )
	{			
		timesSinceLastExe[ts.getTsId()]++;
		
		if(timesSinceLastFail[ts.getTsId()]>=0)
			timesSinceLastFail[ts.getTsId()]++;
		if(timesSinceLastError[ts.getTsId()]>=0) 
			timesSinceLastError[ts.getTsId()]++;
		if(timesSinceLastFailError[ts.getTsId()] >= 0)
			timesSinceLastFailError[ts.getTsId()] ++;
		
//		if(timesSinceLastFail[ts.getTsId()]>=0)
//		{
//			timesSinceLastFail[ts.getTsId()]++;
//		}
		
	}
	
	
	public int countDistinctFails()
	{
		int numOfDistinctFails=0;
		for(int i=0;i<distinctTsNum; i++)
		{
			if(isFail_Ts[i])
			{
				numOfDistinctFails++;
			}
		}
		return numOfDistinctFails;
	}
	

	public boolean[] getIsExecuted() {
		return isExecuted;
	}

	public void setIsExecuted(boolean[] isExecuted) {
		this.isExecuted = isExecuted;
	}

	public boolean[] getIsFail_Ts() {
		return isFail_Ts;
	}

	public void setIsFail_Ts(boolean[] isFail_Ts) {
		this.isFail_Ts = isFail_Ts;
	}

	public boolean[] getIsError_Ts() {
		return isError_Ts;
	}

	public void setIsError_Ts(boolean[] isError_Ts) {
		this.isError_Ts = isError_Ts;
	}

	public Timestamp[] getTs_failTime() {
		return Ts_failTime;
	}

	public void setTs_failTime(Timestamp[] ts_failTime) {
		Ts_failTime = ts_failTime;
	}

	public String[] getTs_state() {
		return Ts_state;
	}

	public void setTs_state(String[] ts_state) {
		Ts_state = ts_state;
	}

	public int[] getTsId() {
		return TsId;
	}

	public void setTsId(int[] tsId) {
		TsId = tsId;
	}

	public double[] getTs_duration() {
		return Ts_duration;
	}

	public void setTs_duration(double[] ts_duration) {
		Ts_duration = ts_duration;
	}

	public int[] getTs_runs() {
		return Ts_runs;
	}

	public void setTs_runs(int[] ts_runs) {
		Ts_runs = ts_runs;
	}

	public int[] getTs_assertions() {
		return Ts_assertions;
	}

	public void setTs_assertions(int[] ts_assertions) {
		Ts_assertions = ts_assertions;
	}

	public int[] getTs_failures() {
		return Ts_failures;
	}

	public void setTs_failures(int[] ts_failures) {
		Ts_failures = ts_failures;
	}

	public int[] getTs_errors() {
		return Ts_errors;
	}

	public void setTs_errors(int[] ts_errors) {
		Ts_errors = ts_errors;
	}

	public int[] getTs_skips() {
		return Ts_skips;
	}

	public void setTs_skips(int[] ts_skips) {
		Ts_skips = ts_skips;
	}

	public Timestamp[] getTs_start_time() {
		return Ts_start_time;
	}

	public void setTs_start_time(Timestamp[] ts_start_time) {
		Ts_start_time = ts_start_time;
	}

	public int[] getBuild_id() {
		return Build_id;
	}

	public void setBuild_id(int[] build_id) {
		Build_id = build_id;
	}

	public int[] getBuild_number() {
		return Build_number;
	}

	public void setBuild_number(int[] build_number) {
		Build_number = build_number;
	}

	public String[] getBuild_state() {
		return Build_state;
	}

	public void setBuild_state(String[] build_state) {
		Build_state = build_state;
	}

	public Timestamp[] getBuild_start_time() {
		return Build_start_time;
	}

	public void setBuild_start_time(Timestamp[] build_start_time) {
		Build_start_time = build_start_time;
	}

	public Timestamp[] getBuild_finish_time() {
		return Build_finish_time;
	}

	public void setBuild_finish_time(Timestamp[] build_finish_time) {
		Build_finish_time = build_finish_time;
	}

	public double[] getBuild_duration() {
		return Build_duration;
	}

	public void setBuild_duration(double[] build_duration) {
		Build_duration = build_duration;
	}

	public int[] getJob_id() {
		return Job_id;
	}

	public void setJob_id(int[] job_id) {
		Job_id = job_id;
	}

	public int[] getJob_number() {
		return Job_number;
	}

	public void setJob_number(int[] job_number) {
		Job_number = job_number;
	}

	public String[] getJob_state() {
		return Job_state;
	}

	public void setJob_state(String[] job_state) {
		Job_state = job_state;
	}

	public Timestamp[] getJob_start_time() {
		return Job_start_time;
	}

	public void setJob_start_time(Timestamp[] job_start_time) {
		Job_start_time = job_start_time;
	}

	public Timestamp[] getJob_finish_time() {
		return Job_finish_time;
	}

	public void setJob_finish_time(Timestamp[] job_finish_time) {
		Job_finish_time = job_finish_time;
	}

//	public double[] getJob_duration() {
//		return Job_duration;
//	}
//
//	public void setJob_duration(double[] job_duration) {
//		Job_duration = job_duration;
//	}

	public int[] getRepository_id() {
		return Repository_id;
	}

	public void setRepository_id(int[] repository_id) {
		Repository_id = repository_id;
	}

	public int[] getCommit_id() {
		return Commit_id;
	}

	public void setCommit_id(int[] commit_id) {
		Commit_id = commit_id;
	}

	public String[] getCommit_sha() {
		return Commit_sha;
	}

	public void setCommit_sha(String[] commit_sha) {
		Commit_sha = commit_sha;
	}

	public String[] getCommit_short_sha() {
		return Commit_short_sha;
	}

	public void setCommit_short_sha(String[] commit_short_sha) {
		Commit_short_sha = commit_short_sha;
	}

	public double[] getCk() {
		return Ck;
	}

	public void setCk(double[] ck) {
		Ck = ck;
	}
	

	public int[] getTs_recordNum() {
		return Ts_recordNum;
	}

	public void setTs_recordNum(int[] ts_recordNum) {
		Ts_recordNum = ts_recordNum;
	}

	public double[] getCk_s() {
		return Ck_s;
	}

	public void setCk_s(double[] ck_s) {
		Ck_s = ck_s;
	}

	public double[] getCk_f() {
		return Ck_f;
	}

	public void setCk_f(double[] ck_f) {
		Ck_f = ck_f;
	}

	public int[] getConsecutiveFail() {
		return consecutiveFail;
	}

	public void setConsecutiveFail(int[] consecutiveFail) {
		this.consecutiveFail = consecutiveFail;
	}
		
	public int[] getConsecutiveExe() {
		return consecutiveExe;
	}

	public void setConsecutiveExe(int i, int consecutiveExe) {
		this.consecutiveExe[i] = consecutiveExe;
	}

	public int[] getConsecutiveSkip() {
		return consecutiveSkip;
	}

	public void setConsecutiveSkip(int i, int consecutiveSkip) {
		this.consecutiveSkip[i] = consecutiveSkip;
	}
	
	public double[] getTimesSinceLastExe() {
		return timesSinceLastExe;
	}

	public void setTimesSinceLastExe(double[] timesSinceLastExe) {
		this.timesSinceLastExe = timesSinceLastExe;
	}

	public double[] getTimesSinceLastFail() {
		return timesSinceLastFail;
	}

	public void setTimesSinceLastFail(double[] timesSinceLastFail) {
		this.timesSinceLastFail = timesSinceLastFail;
	}

	public boolean[] getIsFailError_Ts() {
		return isFailError_Ts;
	}

	public void setIsFailError_Ts(boolean[] isFailError_Ts) {
		this.isFailError_Ts = isFailError_Ts;
	}

	public Timestamp[] getTs_errorTime() {
		return Ts_errorTime;
	}

	public void setTs_errorTime(Timestamp[] ts_errorTime) {
		Ts_errorTime = ts_errorTime;
	}

	public Timestamp[] getTs_failErrorTime() {
		return Ts_failErrorTime;
	}

	public void setTs_failErrorTime(Timestamp[] ts_failErrorTime) {
		Ts_failErrorTime = ts_failErrorTime;
	}

	public int getDistinctTsNum() {
		return distinctTsNum;
	}

	public void setDistinctTsNum(int distinctTsNum) {
		this.distinctTsNum = distinctTsNum;
	}

	public double[] getTimesSinceLastError() {
		return timesSinceLastError;
	}

	public void setTimesSinceLastError(double[] timesSinceLastError) {
		this.timesSinceLastError = timesSinceLastError;
	}

	public double[] getTimesSinceLastFailError() {
		return timesSinceLastFailError;
	}

	public void setTimesSinceLastFailError(double[] timesSinceLastFailError) {
		this.timesSinceLastFailError = timesSinceLastFailError;
	}

	public double[] getTs_exeNum() {
		return Ts_exeNum;
	}

	public void setTs_exeNum(double[] ts_exeNum) {
		Ts_exeNum = ts_exeNum;
	}

	public double[] getPf_num() {
		return pf_num;
	}

	public void setPf_num(int id, double pf_num) {
		this.pf_num[id] = pf_num;
	}

	public double[] getPe_num() {
		return pe_num;
	}

	public void setPe_num(int id, double pe_num) {
		this.pe_num[id] = pe_num;
	}

	public double[] getPef_num() {
		return pef_num;
	}

	public void setPef_num(int id, double pef_num) {
		this.pef_num[id] = pef_num;
	}
	
	
	

	public double[] getPf_percent() {
		return pf_percent;
	}

	public void setPf_percent(double[] pf_percent) {
		this.pf_percent = pf_percent;
	}

	public double[] getPe_percent() {
		return pe_percent;
	}

	public void setPe_percent(double[] pe_percent) {
		this.pe_percent = pe_percent;
	}

	public double[] getPef_percent() {
		return pef_percent;
	}

	public void setPef_percent(double[] pef_percent) {
		this.pef_percent = pef_percent;
	}

	
	public double[] getPf_num1() {
		return pf_num1;
	}

	public void setPf_num1(int id, double pf_num) {
		this.pf_num1[id] = pf_num;
	}

	public double[] getPe_num1() {
		return pe_num1;
	}

	public void setPe_num1(int id, double pe_num) {
		this.pe_num1[id] = pe_num;
	}

	public double[] getPef_num1() {
		return pef_num1;
	}

	public void setPef_num1(int id, double pef_num) {
		this.pef_num1[id] = pef_num;
	}
	public void setConsecutiveExe(int[] consecutiveExe) {
		this.consecutiveExe = consecutiveExe;
	}

	public void setConsecutiveSkip(int[] consecutiveSkip) {
		this.consecutiveSkip = consecutiveSkip;
	}
	
	
//	

}
