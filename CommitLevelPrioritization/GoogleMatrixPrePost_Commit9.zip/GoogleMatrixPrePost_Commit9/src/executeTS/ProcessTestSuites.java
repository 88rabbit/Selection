//package executeTS;
//
//import java.sql.Timestamp;
//
//import exeRecord.ExeRecord;
//import testSuites.TestSuite;
//
//public class ProcessTestSuites 
//{
//
//	
//
//	public void processTestSuites(TestSuite lastTs,Timestamp failStartTime,Timestamp executeStartTime, String selectedStage, 
//			ExeRecord exeRec, String alwaysExecutedStage, double deltaExe, double deltaFail, UpdateExeRecord updateExeRecords,Accumulation accumulateExe)
//	{
////		if(lastTs.getLast_stage().equals(selectedStage))  // for only posts or pres
//		{
//			//1. for new tests
//			if(exeRec.getIsExecuted()[lastTs.getTsId()] == false)
//			{	
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
//				
//			}
//			//for execution selection
//			else if(exeRec.getNumSinceLastExe()>=deltaExe 
//					|| (exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[lastTs.getTsId()]<=deltaFail))
//			{
//				
//				
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
//				
//			
//			}
//			// for skip selection
//			else
//			{
////				System.out.println("a");
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, false);	
//			}
//							
//		}
//	}
//
//}
