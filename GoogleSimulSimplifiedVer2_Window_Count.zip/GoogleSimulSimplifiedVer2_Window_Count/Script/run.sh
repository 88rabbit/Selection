libDir=../lib
srcDir=../src
binDir=../bin

inputParameter_1=11  #failure
inputParameter_2=48  #execution
inputParameter_3=minutes #failuremmhh
inputParameter_4=hours  #executionmmhh
inputParameter_5=    #always
inputParameter_6=pres   #selection

inputParameter_7=50  #exeSinceLast
inputParameter_8=50  #failSinceLast

for inputParameter_6 in post pres
do
	for inputParameter_7 in 50
	# for inputParameter_7 in 1 2 4 5 10 100
	# for inputParameter_7 in 1 2 4 5 10 100
	do
		for inputParameter_8 in 1 2 4 5 10 100
		# for inputParameter_8 in 100
		do
			#compile the program
			javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

			# with option -h, the list of options will show up
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

			#run the program with parameters
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -E=$inputParameter_7 -F=$inputParameter_8
		done
    done 
done

