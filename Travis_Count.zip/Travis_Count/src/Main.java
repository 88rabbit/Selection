import java.sql.SQLException;

import parsingCommandLine.Cli;
import simulate.Simulation;


public class Main 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{	
		Cli cli = new Cli(args);
		cli.parse();
		String[] newString = cli.getArgs();
		
		//for googleDataset
		if(newString[0].equals("googleDataset"))
		{
//			System.out.println("dataset = " + args[0]);
//			GoogleDataset googleDataset = new GoogleDataset();	
//			googleDataset.getGoogleDataset(newString);
		}
//		//for travisDataset
		else if(newString[0].equals("travisDataset"))
		{
			System.out.println("dataset = " + args[0]);
			TravisDataset travisDataset = new TravisDataset();
			travisDataset.getTravisDataset(args);
		}
	
		
	}
}
						
