package exeRecord;

import java.util.ArrayList;
import java.util.HashSet;

import testSuites.TestSuite;

public class RecordCR 
{
	
	
	private int cr;
	private ArrayList<TestSuite> ts = new ArrayList<TestSuite>();
	private ArrayList<Integer> tsId= new ArrayList<Integer>();
	private ArrayList<Integer> pf=new ArrayList<Integer>();
	private ArrayList<String> size = new ArrayList<String>();
	
	/*
	 * record failure number, [0] record total, [1] record fail number
	 */
	private int[] smallSize = {0, 0};   
	private int[] medianSize = {0, 0}; 
	private int[] largeSize = {0, 0}; 
	
	//to test wheter tsId in a cr is unique
	private HashSet<Integer> tsIdUnique = new HashSet<Integer>();

	
	public RecordCR(int cr) {
		super();
		this.cr = cr;
	}

	public void updateCRr(TestSuite ts) 
	{
		this.cr = ts.getChangeRequest(); //CR id
		this.ts.add(ts);
		this.tsId.add(ts.getTsId());
		this.tsIdUnique.add(ts.getTsId());
		this.size.add(ts.getSize());
		
		if(ts.getSize().equals("SMALL"))
		{
			smallSize[0] ++;
			if(ts.isFail())
			{
				smallSize[1] ++;
			}			
		}
		else if(ts.getSize().equals("MEDIUM"))
		{
			medianSize[0] ++;
			if(ts.isFail())
			{
				medianSize[1] ++;
			}			
		}
		else if(ts.getSize().equals("LARGE"))
		{
			largeSize[0] ++;
			if(ts.isFail())
			{
				largeSize[1] ++;
			}			
		}
		
		
		if(ts.isFail())
		{
			this.pf.add(0);//fail
		}
		else
		{
			this.pf.add(1);//pass
		}
		
	}

	public int getSize()
	{
		return tsId.size();
	}

	public int getCr() {
		return cr;
	}

	public void setCr(int cr) {
		this.cr = cr;
	}

	public ArrayList<Integer> getTsId() {
		return tsId;
	}

	public void setTsId(ArrayList<Integer> tsId) {
		this.tsId = tsId;
	}

	public ArrayList<Integer> getPf() {
		return pf;
	}

	public void setPf(ArrayList<Integer> pf) {
		this.pf = pf;
	}

	public HashSet<Integer> getTsIdUnique() {
		return tsIdUnique;
	}

	public void setTsIdUnique(HashSet<Integer> tsIdUnique) {
		this.tsIdUnique = tsIdUnique;
	}

	public ArrayList<TestSuite> getTs() {
		return ts;
	}

	public void setTs(ArrayList<TestSuite> ts) {
		this.ts = ts;
	}

	public void setSize(ArrayList<String> size) {
		this.size = size;
	}

	public int[] getSmallSize() {
		return smallSize;
	}

	public void setSmallSize(int[] smallSize) {
		this.smallSize = smallSize;
	}

	public int[] getMedianSize() {
		return medianSize;
	}

	public void setMedianSize(int[] medianSize) {
		this.medianSize = medianSize;
	}

	public int[] getLargeSize() {
		return largeSize;
	}

	public void setLargeSize(int[] largeSize) {
		this.largeSize = largeSize;
	}
	
	
	

}
