package readFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class readConcurrentNum 
{
	private Map<Integer,Integer> map = new HashMap<Integer, Integer>();
	private int total = 0;
//	private int eachCR;
	private int commitId;
	private int numOfConcurrent;
		
	public Map<Integer,Integer> getNumOfConcurrent()
	{		
		try
		{		
			FileReader fs = new FileReader("../data/concurrentNum.txt"); // the commits contains test suites that has failure history(does not mean it fails)
	
			BufferedReader br = new BufferedReader(fs);
			
			String testInfo = br.readLine();
		
			while(testInfo!=null &&!testInfo.isEmpty())
			{		
				total ++;
				String[] line = testInfo.split(",");
				//parse file contents
				commitId = Integer.parseInt(line[0]);
				numOfConcurrent = Integer.parseInt(line[1]);
				
				map.put(commitId, numOfConcurrent);
				testInfo = br.readLine();			
			
			}
	//		System.out.println("No.of commits that contains test suites with fail history(does not mean it fails)" + total);	
	//		System.out.println(c + "records have been inserted");
		}
		catch(Exception e)
		{
			System.out.print(e.toString());
		}
	return map;
	}

}
