import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashSet;
import java.util.Set;

import exeRecord.ExeRecord;
import parsingCommandLine.Cli;
import simulate.Simulation;


public class Main 
{
	
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, ParseException, FileNotFoundException, IOException 
	{	
		//adding options for command lines
		/*
		 * -a,--failureWindow <arg>        set the failureWindow(integers)
			 -b,--executionWindow <arg>      set the executionWindow(integers)
			 -c,--failmmhh <arg>             set the minutes or hours for failure
			                                 window('minutes' or 'hours')
			 -d,--executemmhh <arg>          set the minutes or hours for execution
			                                 window('minutes' or 'hours')
			 -e,--alwaySelectedStage <arg>   set the stage('pres' or 'post' or '') in
			                                 which the tests will always execute.
			 -h,--help                       show help
			 -s,--selectedStage <arg>        set the selected stage('pres' or 'post'
			                                 or 'presAndPost')
		 */
				
		
		Cli cli = new Cli(args);
		cli.parse();
		
		String[] newString = cli.getArgs();
		
		int distinctTsNum = 5557;
		
		String alwaysExecutedStage = newString[0];
		
		int failWindow=Integer.parseInt(newString[1]);
		int executionWindow=Integer.parseInt(newString[2]);
		
		// setting the followings, Strings should be "minutes" or "hours"
		String failmmhh= newString[3];
		String executemmhh = newString[4];
		
		// setting the phase of testSuites
		String selectedStage = newString[5];	
		
		int numberOfProcessor = Integer.parseInt(newString[6]);
		
		double rate = Double.parseDouble(newString[7]);
		
		boolean isIntra = Boolean.parseBoolean(newString[8]);
		
		//setting the sql;
//		String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number,  TestId FROM AllData WHERE Stage = '" +selectedStage+"' AND LaunchTime <'2014-01-16' ORDER BY LaunchTime, T_number, Shared_number";
//		String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, ChangeRequest, T_number,  TestId FROM AllData WHERE Stage = 'post' ORDER BY ChangeRequest, LaunchTime, T_number, Shared_number";
		
		//according to commits most recently
		String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, ChangeRequest, T_number,  TestId FROM AllData WHERE Stage = '" +selectedStage+"' AND LaunchTime <'2014-01-16' ORDER BY ChangeRequest, LaunchTime, T_number, Shared_number";

		//optimal
//		String sql = "SELECT a.ChangeRequest, a.Stage, a.Status_test, a.LaunchTime, a.ExecutionTime, a.size, a.Shared_number, a.Run_number, a.Language_test, a.T_number,  a.TestId FROM AllData AS a INNER JOIN crPercent as cr on a.ChangeRequest = cr.changerequest WHERE a.Stage = '" +selectedStage+"' AND a.LaunchTime <'2014-01-16' ORDER BY cr.percent DESC, a.LaunchTime, a.T_number, a.Shared_number";
		
		// pres as info and post as queue up
//		String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, ChangeRequest, T_number,  TestId FROM AllData ORDER BY ChangeRequest, LaunchTime, T_number, Shared_number";
		
		
		
//		String sql = "SELECT a.TestSuite, a.ChangeRequest, a.Stage, a.Status_test, a.LaunchTime, a.ExecutionTime,size, a.Shared_number, a.Run_number, a.Language_test, a.ChangeRequest, a.T_number,  a.TestId FROM AllData AS a INNER JOIN crTable as cr on a.ChangeRequest = cr.changerequest WHERE a.Stage = 'pres'  ORDER BY cr.failurecount DESC, a.LaunchTime, a.T_number, a.Shared_number";
		
		
		
		
		
		Simulation simulation = new Simulation();
	
		ExeRecord exeRec = new ExeRecord();
		exeRec.initializeRecord(distinctTsNum);
		
//		simulation.simulate2(sql, failWindow, executionWindow, failmmhh, executemmhh, selectedStage, distinctTsNum, alwaysExecutedStage, prioritizeQueue, exeRec);
//		exeRec = simulation.getExeRec();
		
//		System.out.println(alwaysExecutedStage);
		simulation = new Simulation();
		simulation.simulate(sql, failWindow, executionWindow, failmmhh, executemmhh, selectedStage, distinctTsNum, alwaysExecutedStage, numberOfProcessor, exeRec, rate, isIntra);		
	}
}
						
