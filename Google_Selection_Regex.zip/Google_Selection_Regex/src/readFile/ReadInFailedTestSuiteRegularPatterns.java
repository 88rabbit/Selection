package readFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ReadInFailedTestSuiteRegularPatterns {
	
	private int total = 0;
	
	private int max_f = 0;
	private int min_f = 0;
	private int max_p = 0;
	private int min_p = 0;
	
	public Map<Integer, Integer[]> ReadInIdAndRepeatRange(String selectPhase)
	{
//		Set<Integer> failedIds = new HashSet<Integer>();
		Map<Integer, Integer[]> id_max_min = new HashMap<Integer, Integer[]>();
		try
		{
			FileReader fs = selectPhase.equals("post")? new FileReader("../data/Post_Id_Regex.txt") : new FileReader("../data/Pres_Id_Regex.txt");
			    
			BufferedReader br = new BufferedReader(fs);
			
			String testInfo = br.readLine();
			int testId = 0;
			String[] content;
			
			//testInfo example: 69,p:276;f:2;p:140
			while(testInfo!=null &&!testInfo.isEmpty())
			{		
				total ++;
				content = testInfo.split(",");
				//parse file contents
				testId = Integer.parseInt(content[0]);
				String[] all_patterns = content[1].split(";");
				max_f = 0;
				min_f = 0;
				max_p = 0;
				min_p = 0;
				for(int i=0; i<all_patterns.length; i++)
				{
					String[] each_pattern = all_patterns[i].split(":");
					updateMaxMin(each_pattern);
				}
				Integer[] max_min = {max_p, min_p, max_f, min_f};
				
				id_max_min.put(testId, max_min);
		
				testInfo = br.readLine();			
			
			}
//			System.out.println("total number of distinct fail test suite is: " + total);
//			for(Integer x: id_max_min.keySet())
//			{
//				System.out.println(x + "," + Arrays.toString(id_max_min.get(x)));
//			}
		}
		catch(Exception e)
		{
			System.out.print(e.toString());
		}
		
		return id_max_min;
	}
	
	public void updateMaxMin(String[] each_pattern)
	{
		if(each_pattern[0].equals("p"));   //p:11
		{
			int repeatTimes = Integer.parseInt(each_pattern[1]);
			if(max_p == min_p && max_p == 0)
			{
				max_p = min_p = repeatTimes;
			}
			else
			{
				max_p = max_p > repeatTimes ? max_p: repeatTimes;
				min_p = min_p < repeatTimes ? min_p: repeatTimes;
			}
		}
		
		if(each_pattern[0].equals("f"))
		{
			int repeatTimes = Integer.parseInt(each_pattern[1]);
			if(max_f == min_f && max_f == 0)
			{
				max_f = min_f = repeatTimes;
			}
			else
			{
				max_f = max_f > repeatTimes ? max_f: repeatTimes;
				min_f = min_f < repeatTimes ? min_f: repeatTimes;
			}
		}
	}
	

}

