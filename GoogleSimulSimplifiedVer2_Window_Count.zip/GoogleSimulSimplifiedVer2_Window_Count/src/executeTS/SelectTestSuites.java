package executeTS;

import java.sql.Timestamp;
import java.util.Map;
import java.util.Random;

import exeRecord.ExeRecord;
import readFile.ReadInFailedTestSuiteRegularPatterns;
import testSuites.TestSuite;



public class SelectTestSuites 
{	
	//for counting number of all TestSuites
		private Accumulation accumulateAll;
				
		//for counting number of executed TestSuites
		private Accumulation accumulateExe;
		
		private Accumulation accumulateTemp;
		
	
	private UpdateExeRecord updateExeRecords = new UpdateExeRecord();
	
	Random r = new Random();
	double random_zeroToOne;
	
	int x = 0;
	int y = 0;
	
	int countExe = 0;
	int countFail = 0;
	int countMinP = 0;
	int countMaxF = 0;
	
//	double warmUpNum = 0;
	private double windowSize = 0;//warm up
	
	
	
	public SelectTestSuites(int distinctTsNum) {
		super();
		this.accumulateAll = new Accumulation(distinctTsNum);
		this.accumulateExe = new Accumulation(distinctTsNum);
		this.accumulateTemp = new Accumulation(distinctTsNum);
		
	}
	/*
	 * We+Wf+TF 
	 */
	public void selectTs(TestSuite lastTs,Timestamp failStartTime,Timestamp executeStartTime, String selectedStage, 
			ExeRecord exeRec, String alwaysExecutedStage, double deltaExe, double deltaFail, Map<Integer, Integer[]> id_max_min )
	{
//		if(selectedStage.equals("post"))
//			warmUpNum = 60;
//		else
//			warmUpNum = 52;
		/*
		 * update the number of TestSuite and the execution time of TestSuite
		 */
		//counting
//		this.accumulateAll.counting(lastTs, selectedStage);

		/*
		 * WE+WF+TF_Transistion
		 */
		if(lastTs.getLast_stage().equals(selectedStage))  // for only posts or pres
		{
			/*
			 * for Warmups
			 */
//			deltaExe = warmUpNum;
			double totalNum = 0;
			double percent = 0.30;
			if(selectedStage.equals("post"))
			{
				totalNum = 1460531.0;
				windowSize = percent * 257; //30% of median number of test suites execution times
			}
			else 
			{
				totalNum = 1045345.0;
				windowSize = percent * 193; //30% of median number of test suites execution times
			}
			
			/*
			 * For 1% selection
			 */
//			double totalTs = 0;
//			if(selectedStage.equals("post"))
//		    {
//				totalTs = 1044287.0;
//		    }
//		    else 
//		    {
//		    	totalTs = 733502.0;// just 1. pass->fail  2. after 30%
//		    }	
//			double percentOfSelection = accumulateExe.getCountNumber()*100/totalTs;
//			if(percentOfSelection > 1)
//			{
//				//skip
////				System.out.println(accumulateExe.getCountNumber() + ","+ accumulateAll.getCountNumber());
//			}
//			else
			{
				
				
//			/*
//			 * warm up part
//			 */
//			if(exeRec.getIsExecuted()[lastTs.getTsId()] == false || exeRec.getNumOfExe()[lastTs.getTsId()] < windowSize)
//			{
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateTemp, selectedStage, true);	
////				exeRec.setExeTimes(lastTs.getTsId(), 0);
//				exeRec.setPf_num1(lastTs.getTsId(), 0);
////				System.out.println("all");
//				accumulateAll.setStatus(lastTs.getTsId(), lastTs.getLast_status());
////				System.out.println("exe");
//				accumulateExe.setStatus(lastTs.getTsId(), lastTs.getLast_status());
//			}
//			else
			{
			
			this.accumulateAll.counting(lastTs, selectedStage);
			random_zeroToOne = r.nextInt(1001)*100/ 1000; // random number
			//1. for new tests
			if(exeRec.getIsExecuted()[lastTs.getTsId()] == false)
			{	
				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
			}
			//for execution selection
			else if(exeRec.getTimesSinceLastExe()[lastTs.getTsId()]>=deltaExe )
			{
				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
				if(lastTs.isFail())
					countExe ++;
			}
			else if (exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[lastTs.getTsId()]<=deltaFail)
			{	
				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
				if(lastTs.isFail())
					countFail ++;
			}
//			/*
//			 * Add one more pf% condition
//			 */
//			else if(exeRec.getPf_percent()[lastTs.getTsId()] >= random_zeroToOne) // one more condition for P->F transition
//			{
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);
////				System.out.println("++++");
//			}
			// for skip selection
			else
			{
//				System.out.println("a");
				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, false);	
			}
			} 
							
		}
		}
		
//		Integer[] max_min = id_max_min.get(lastTs.getTsId());
//		if(lastTs.getLast_stage().equals(selectedStage))  // for only posts or pres
//		{
//			//1. for new tests
//			if(exeRec.getIsExecuted()[lastTs.getTsId()] == false)
//			{	
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
//				
//			}
////			else if(id_max_min.containsKey(lastTs.getTsId()) && exeRec.getPre_pass_times()[lastTs.getTsId()] >= max_min[0]) 
////			{
//////				Integer[] max_min = id_max_min.get(lastTs.getTsId());
////				/*
////				 * Key: test id
////				 * Value: max_p, min_p, max_f, min_f
////				 */
////				
//////					System.out.println("a");
////					updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, false);	
////				
////			}
//			//for execution selection
//			else if(exeRec.getTimesSinceLastExe()[lastTs.getTsId()]>=deltaExe 
//					|| (exeRec.getTimesSinceLastFail()[lastTs.getTsId()]>=0 && exeRec.getTimesSinceLastFail()[lastTs.getTsId()]<=deltaFail))
//			{
//				/*
//				 * skip
//				 */
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
//			
//			}
////			for regex
//			else if(id_max_min.containsKey(lastTs.getTsId())) 
//			{
////				Integer[] max_min = id_max_min.get(lastTs.getTsId());
//				/*
//				 * Key: test id
//				 * Value: max_p, min_p, max_f, min_f
//				 */
//				if(exeRec.getPre_pass_times()[lastTs.getTsId()] == max_min[1] ) //min_p
//				{ 
//					updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
//
//					if(lastTs.isFail())
//						x ++;
//					System.out.println("x:"+x);
//				}
//				else if(exeRec.getPre_fail_times()[lastTs.getTsId()] >= 1 && exeRec.getPre_fail_times()[lastTs.getTsId()] <= max_min[3] ) //min_f
//				{
//					updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, true);	
//					y ++;
//					System.out.println("y:"+y);
//				}
//				else
//				{
////					System.out.println("a");
//					updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, false);	
//				}
//			}
//			// for skip selection
//			else
//			{
////				System.out.println("a");
//				updateExeRecords.updateDetails(exeRec, lastTs, accumulateExe, selectedStage, false);	
//			}
//							
//		}
	}

	public Accumulation getAccumulateAll() {
		return accumulateAll;
	}

	public void setAccumulateAll(Accumulation accumulateAll) {
		this.accumulateAll = accumulateAll;
	}

	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}

	public int getCountExe() {
		return countExe;
	}

	public void setCountExe(int countExe) {
		this.countExe = countExe;
	}

	public int getCountFail() {
		return countFail;
	}

	public void setCountFail(int countFail) {
		this.countFail = countFail;
	}

	public int getCountMinP() {
		return countMinP;
	}

	public void setCountMinP(int countMinP) {
		this.countMinP = countMinP;
	}

	public int getCountMaxF() {
		return countMaxF;
	}

	public void setCountMaxF(int countMaxF) {
		this.countMaxF = countMaxF;
	}

	
	
	
}
