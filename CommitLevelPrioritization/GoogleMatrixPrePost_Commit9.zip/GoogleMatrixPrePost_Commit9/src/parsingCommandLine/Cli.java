package parsingCommandLine;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

@SuppressWarnings("deprecation")
public class Cli 
{
	private String[] args = null;
	private Options options = new Options();
	
	public Cli(String[] args)
	{
		this.args = args;
		
		//-h or --help is used to show a list of options
		this.options.addOption("h", "help", false, "show help");
		
		this.options.addOption("e", "alwaySelectedStage", true, "set the stage('pres' or 'post' or '') in which the tests will always execute.");
		this.options.addOption("a", "failureWindow", true, "set the failureWindow(integers)");
		this.options.addOption("b", "executionWindow", true, "set the executionWindow(integers)");
		this.options.addOption("c", "failmmhh", true, "set the minutes or hours for failure window('minutes' or 'hours')");
		this.options.addOption("d", "executemmhh", true, "set the minutes or hours for execution window('minutes' or 'hours')");
		this.options.addOption("s", "selectedStage", true, "set the selected stage('pres' or 'post' or 'pres and post')");	
		this.options.addOption("q", "selectedStage", true, "set the size of the prioritize queue(integers)");	
		this.options.addOption("t", "training set size", true, "set the training set size(double)");
		this.options.addOption("i", "intra_commit option", true, "if intra_commit prioritization is needed, set 'true'; else set 'false'");
	}
	
	private void help()
	{
		HelpFormatter formater = new HelpFormatter();
		//formater.printHelp("Main", options);
		System.exit(0);
	}
	
	public void parse()
	{
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd = null;
		try 
		{
			cmd = parser.parse(options, args);
			
			if(cmd.hasOption("h"))
				help();
			
			if(cmd.hasOption("e"))
			{
				args[0] = cmd.getOptionValue("e");
			}
			
			if(cmd.hasOption("a"))
			{
				args[1] = cmd.getOptionValue("a");
			}
			
			if(cmd.hasOption("b"))
			{
				args[2] = cmd.getOptionValue("b");
			}
			
			if(cmd.hasOption("c"))
			{
				args[3] = cmd.getOptionValue("c");
			}
			
			if(cmd.hasOption("d"))
			{
				args[4] = cmd.getOptionValue("d");
			}
			
			if(cmd.hasOption("s"))
			{
				args[5] = cmd.getOptionValue("s");
			}
			
			if(cmd.hasOption("q"))
			{
				args[6] = cmd.getOptionValue("q");
			}
			
			if(cmd.hasOption("t"))
			{
				args[7] = cmd.getOptionValue("t");
			}
			
			if(cmd.hasOption("i"))
			{
				args[8] = cmd.getOptionValue("i");
			}
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	public String[] getArgs() {
		return args;
	}

	public void setArgs(String[] args) {
		this.args = args;
	}
}
