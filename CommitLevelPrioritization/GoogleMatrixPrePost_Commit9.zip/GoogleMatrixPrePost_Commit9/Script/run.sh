libDir=../lib
srcDir=../src
binDir=../bin

inputParameter_1=11  #failure
inputParameter_2=48  #execution
inputParameter_3=hours #failuremmhh
inputParameter_4=hours  #executionmmhh
inputParameter_5=   #always
# inputParameter_6=pres   #selection
inputParameter_6=post

inputParameter_7=9 # set the number of processors
inputParameter_8=1 # rate arrival rate


inputParameter_9=false      # Intra_commit prioritization

for inputParameter_6 in pres
# for inputParameter_6 in pres post
do
	for inputParameter_8 in 1
	# for inputParameter_8 in 0.25 0.5 0.75 1
	do
		# for inputParameter_7 in 1 2 4 8 16
		# for inputParameter_7 in 2 3 4 8 16
		for inputParameter_7 in 1
			do
				for inputParameter_2 in 500
				# for inputParameter_2 in 1000
				do
					# for inputParameter_1 in 50 100 200 500 1000
					for inputParameter_1 in 500
					do
						#compile the program
						javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.1.39-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

						# with option -h, the list of options will show up
						java -Xmx2g -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.1.39-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

						#run the program with parameters
						java -Xmx2g -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.1.39-bin.jar:$libDir/hamcrest-core-1.3.jar Main -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -q=$inputParameter_7 -t=$inputParameter_8 -i=$inputParameter_9
					done
				done 
		done
	done
done
