package executeTS;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import changeRequest.ReadFailJavaTs;
import exeRecord.ExeRecord;
import testSuites.TestSuite;

/*
 * This class is not an effective function
 */
public class Commit 
{
	private int id;
//	private int commitNum; //record the ith executed number of the commit
	private List<TestSuite> fail = new ArrayList<TestSuite>();
//	private List<TestSuite> notFail = new ArrayList<TestSuite>();
	private List<TestSuite> allTests = new ArrayList<TestSuite>();
	private String selectedStage;
	
	private List<Integer> failTest; 
//	private Map<Integer, boolean[]> isSizeFail;
	
	private boolean hasSmall;
	private boolean hasMedium;
	private boolean hasLarge;
	
//	private boolean isFailCommit;
	
	
	//for early stop
	private List<TestSuite> allTests_small = new ArrayList<TestSuite>();
	private List<TestSuite> allTests_medium = new ArrayList<TestSuite>();
	private List<TestSuite> allTests_large = new ArrayList<TestSuite>();
	
	
	private int s = 0;
	private long sExe = 0;
	private int m = 0;
	private long mExe = 0;
	private int l = 0;
	private long lExe = 0;
	
	private int total = 0;
	private long totalExe = 0;	
	
//	private PriorityQueue<TestSuite> pqTests;
	
	
	
	//used for recording java test suite
	
	private Map<Integer, int[]> map = new HashMap<Integer, int[]>();
	private Map<Integer, String> failTestLanguage = new HashMap<Integer, String>();
	
	private int failNumber;
	
	private boolean checkFail;
	
	private int numTsSatisfy_fail;
	private int numTsSatisfy_exe;
	private int totalNum;
	private List<TestSuite> notExe = new ArrayList<TestSuite>();
//	private CountFailures cf;
	
	
	double failRatio = 0; // possible fail
	double exeRatio = 0; // possible fail
	double ratio_fail = 0; // fail ratio
	private double commit_totalExeTime;
	
	private boolean isEarliest;
	private TestSuite lastTest;
	private Timestamp exeStartTime; //earliest ts launch time
	private Timestamp exeEndTime;	//last ts finishe time
	private double duration; // millisecond --> duration of the commit
	private Timestamp commitArrivalTime; // calculate the arrival time of the commit
//	private Timestamp commitShiftEndTime;
	private Calendar calForFail;
	private Calendar tempEnd;	
//	private double avgCommitExeTime;
	private Calendar calForFailArrive;	
	private int concurrentNum; // used to generate
	private int numOfConcurrent; // after generated just read it from concurrentNum.txt file and set it 
//	private double delta;
//	private long commitEnterQueueTime;
	private double commitEnterQueueTime;  
	
//	private boolean[] isFirstFailTest;
	private int[] eachTestFailTimes;
	
	public void init(TestSuite ts, List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, 
			boolean[]> isSizeFail, int numOfConcurrent, int[] testFails)
	{
		this.id = ts.getChangeRequest();
//		this.delta = delta;
//		this.commitNum = commitNum;
		this.failTest = failTest;
		this.selectedStage = ts.getLast_stage();
		map = javaTs.getMap();
		failTestLanguage = javaTs.getFailTestLanguage();
		numTsSatisfy_fail = 0;
		numTsSatisfy_exe = 0;
		//for dynamic queue
//		this.containsExeTs = new HashSet<Integer>();
//		this.containsFailTs = new HashSet<Integer>();
		this.isEarliest = true;
		this.calForFail = Calendar.getInstance();
		this.calForFailArrive = Calendar.getInstance();
		this.tempEnd = Calendar.getInstance();
//		this.calForFailEnd =  Calendar.getInstance();
//		this.avgCommitExeTime = 
		this.concurrentNum = 1; // when initialized, it is one
		this.numOfConcurrent = numOfConcurrent; 
		
//		pqTests = new PriorityQueue<TestSuite>(1, new Comparator<TestSuite>(){
//			public int compare(TestSuite p1, TestSuite p2)
//			{	
//				if(p1.getLast_executionTime() < p2.getLast_executionTime())
//					return -1;
//				else if(p1.getLast_executionTime() == p2.getLast_executionTime())
//					return 0;
//				else 
//					return 1;
//				
//				//TODO return 1 if rhs should be before lhs 
//			     //     return -1 if lhs should be before rhs
//			     //     return 0 otherwise
//			}		
//			
//		});
//		isFirstFailTest = new boolean[5557];
//		for(int i=0; i<5557; i++)
//			isFirstFailTest[i] = true;
	
		this.eachTestFailTimes = testFails;
	}
	
	public void init(TestSuite ts, List<Integer> failTest, ReadFailJavaTs javaTs, Map<Integer, 
			boolean[]> isSizeFail, int numOfConcurrent)
	{
		this.id = ts.getChangeRequest();
//		this.delta = delta;
//		this.commitNum = commitNum;
		this.failTest = failTest;
		this.selectedStage = ts.getLast_stage();
		map = javaTs.getMap();
		failTestLanguage = javaTs.getFailTestLanguage();
		numTsSatisfy_fail = 0;
		numTsSatisfy_exe = 0;
		//for dynamic queue
//		this.containsExeTs = new HashSet<Integer>();
//		this.containsFailTs = new HashSet<Integer>();
		this.isEarliest = true;
		this.calForFail = Calendar.getInstance();
		this.calForFailArrive = Calendar.getInstance();
		this.tempEnd = Calendar.getInstance();
//		this.calForFailEnd =  Calendar.getInstance();
//		this.avgCommitExeTime = 
		this.concurrentNum = 1; // when initialized, it is one
		this.numOfConcurrent = numOfConcurrent; 
		
//		pqTests = new PriorityQueue<TestSuite>(1, new Comparator<TestSuite>(){
//			public int compare(TestSuite p1, TestSuite p2)
//			{	
//				if(p1.getLast_executionTime() < p2.getLast_executionTime())
//					return -1;
//				else if(p1.getLast_executionTime() == p2.getLast_executionTime())
//					return 0;
//				else 
//					return 1;
//				
//				//TODO return 1 if rhs should be before lhs 
//			     //     return -1 if lhs should be before rhs
//			     //     return 0 otherwise
//			}		
//			
//		});
		
	}
	
	/*
	 * Update without Intra method prioritize
	 */
	public void update(TestSuite ts, String selectedStage, ExeRecord exeRec, int deltaFail, int deltaExe, int previousExeCommitNum)
	{
//		if(isEarliest)
//			exeStart
		
		if(isEarliest)
		{
			exeStartTime = ts.getLast_launchTime();
			isEarliest = false;
			
//			maxEnd = ts; // initialize the first ts
		}		
		lastTest = ts; // update the last
			
		
		allTests.add(ts);
		totalNum ++;
		
		commit_totalExeTime += ts.getLast_executionTime();
		
		if(ts.isFail())
		{
			checkFail = true;
			failNumber ++;
		}
		
		//1. for new tests
		if(exeRec.getIsExecuted()[ts.getTsId()] == false)
		{	
			numTsSatisfy_exe++;	
//			notExe.add(ts);
		}
		//for execution selection
		else 
		{
			if(previousExeCommitNum - exeRec.getCommitsSinceLastExe()[ts.getTsId()]-1 >= deltaExe )
			{
				numTsSatisfy_exe++;
//				notExe.add(ts);
			}
			
			if (exeRec.getIsFail()[ts.getTsId()] && previousExeCommitNum - exeRec.getCommitsSinceLastFail()[ts.getTsId()] - 1<= deltaFail)
//			if (exeRec.getTimesSinceLastFail()[ts.getTsId()]>=0 )
			{			
				numTsSatisfy_fail ++;		
//				fail.add(ts);
			}
		}
//		else
//			notFail.add(ts);
				
	}	
	
	
	//No intra prioritize
	public void updateProcessCommit(Accumulation accumulateExe, String selectedStage, ExeRecord exeRec, UpdateExeRecord updateExeRecords, int commitNum, double timePassed)
	{
		for(TestSuite ts: allTests)
		{				
			updateExeRecords.updateDetails(exeRec, ts, accumulateExe, selectedStage, true, commitNum, timePassed);
//			containsExeTs.add(ts.getTsId()); //for dynamic queue
			
//			accumulateExe.counting_exe(ts, selectedStage);	// execute all tests which are all large test suites
//			apfd(ts);
			if(ts.isFail())
			{
				checkFail = true;
//				containsFailTs.add(ts.getTsId()); // for dynamic queue;
//				break;//early stop  random
			}
		}
		
	}
	
	
	//intra prioritize
	public void updateProcessCommit_Intra(Accumulation accumulateExe, String selectedStage, ExeRecord exeRec, UpdateExeRecord updateExeRecords, int commitNum, double timePassed,  int deltaFail, int deltaExe)
	{
		List<TestSuite> lowerPriority = new ArrayList<TestSuite>();
		List<TestSuite> higherPriority = new ArrayList<TestSuite>();
		
		for(TestSuite ts: allTests)
		{	
			//1. for new tests
			if(exeRec.getIsExecuted()[ts.getTsId()] == false)
			{
				higherPriority.add(ts);
			}
			else if((commitNum - exeRec.getCommitsSinceLastExe()[ts.getTsId()]-1 >= deltaExe) 
					||(exeRec.getIsFail()[ts.getTsId()] && commitNum - exeRec.getCommitsSinceLastFail()[ts.getTsId()] - 1<= deltaFail))
			{
				higherPriority.add(ts);
			}
			else
			{
				lowerPriority.add(ts);
			}			
		}
		
		for(TestSuite ts: higherPriority)
		{
			updateExeRecords.updateDetails(exeRec, ts, accumulateExe, selectedStage, true, commitNum, timePassed);
//			containsExeTs.add(ts.getTsId()); //for dynamic queue
			if(ts.isFail())
			{
				checkFail = true;
//				containsFailTs.add(ts.getTsId()); // for dynamic queue;
//				break;//early stop  random
			}
		}
		
		for(TestSuite ts: lowerPriority)
		{
			updateExeRecords.updateDetails(exeRec, ts, accumulateExe, selectedStage, true, commitNum, timePassed);
//			containsExeTs.add(ts.getTsId()); //for dynamic queue
			if(ts.isFail())
			{
				checkFail = true;
//				containsFailTs.add(ts.getTsId()); // for dynamic queue;
//				break;//early stop  random
			}
		}
	}
	
	

	/*
	 * For newly updated storeCommits and SimulateCommitsExecution class
	 */	
	public void storeTestsInCommit(TestSuite ts, String selectedStage)
	{
		// to record the start and end time of the commit
		if(isEarliest)
		{
			exeStartTime = ts.getLast_launchTime();
			isEarliest = false;
			
//			maxEnd = ts; // initialize the first ts
		}		
		lastTest = ts; // update the last
			
		
		allTests.add(ts);
		totalNum ++;
		commit_totalExeTime += ts.getLast_executionTime();
		if(ts.isFail())
		{
			checkFail = true;
			failNumber ++;
			
//			if(isFirstFailTest[ts.getTsId()])
//			{
//				isFirstFailTest[ts.getTsId()] = false;
//				this.eachTestFailTimes[ts.getTsId()] ++;
//			}
			
		}
	}
	
	
	
	private Timestamp maxEnd;
	private Timestamp curEnd;
	
	private Calendar resetStartTime =  Calendar.getInstance();
	private double gap;
	public void calculateDuration()
	{
		exeEndTime = lastTest.getLast_launchTime();
		calForFail.setTime(new Date(lastTest.getLast_launchTime().getTime()));	// set the last test of the commit's time
		calForFail.add(Calendar.MILLISECOND, (int)lastTest.getLast_executionTime());
		this.exeEndTime =  new Timestamp(calForFail.getTime().getTime());
		
//		System.out.println(exeStartTime + "; "+lastTest.getLast_launchTime() + ","+lastTest.getLast_executionTime() + this.exeEndTime);		
		this.duration = this.exeEndTime.getTime() - this.exeStartTime.getTime(); // total duration
//		System.out.print(this.duration + ": ");
	
		// get the gap
		calForFail.setTime(new Date(allTests.get(0).getLast_launchTime().getTime()));	// set the first test of the commit's time
		calForFail.add(Calendar.MILLISECOND, (int)allTests.get(0).getLast_executionTime());		
		this.maxEnd = new Timestamp(calForFail.getTime().getTime());
		
		boolean reset = false;
		for(TestSuite ts: allTests)
		{			
//			if(id == 330)
//				System.out.println(ts.getLast_launchTime());
//			
			tempEnd.setTime(new Date(ts.getLast_launchTime().getTime()));
			tempEnd.add(Calendar.MILLISECOND, (int)ts.getLast_executionTime());
			this.curEnd = new Timestamp(tempEnd.getTime().getTime());
			
			if(this.maxEnd.before(ts.getLast_launchTime()))
			{
				gap += ts.getLast_launchTime().getTime() - this.maxEnd.getTime();
				reset = true;
			}
			
			// reset the original Test suites' launch time
			if(reset)
			{			
				resetStartTime.setTime(new Date(ts.getLast_launchTime().getTime()));
				resetStartTime.add(Calendar.MILLISECOND, -(int)gap);
				ts.setLast_launchTime(new Timestamp(resetStartTime.getTime().getTime()));  
			
			}
			
			if(this.maxEnd.before(this.curEnd))
				this.maxEnd = this.curEnd;						
		}
		
//		double tempdur = this.maxEnd.getTime() - this.exeStartTime.getTime() - gap;
//		
//		this.duration = this.duration - gap;
//		
////		if(this.duration == tempdur)
////			System.out.println(id + "; old: " + this.duration + "; new: "+ tempdur);
//		
		this.duration = this.maxEnd.getTime() - this.exeStartTime.getTime() - gap;
//		System.out.println(this.duration);
//		System.out.println();
		updateTestSuiteTime();
	}
	
	public void updateTestSuiteTime()
	{
//		exeEndTime = lastTest.getLast_launchTime();
//		calForFail.setTime(new Date(lastTest.getLast_launchTime().getTime()));	// set the last test of the commit's time
//		calForFail.add(Calendar.MILLISECOND, (int)lastTest.getLast_executionTime());
//		this.exeEndTime =  new Timestamp(calForFail.getTime().getTime());
//		
////		System.out.println(exeStartTime + "; "+lastTest.getLast_launchTime() + ","+lastTest.getLast_executionTime() + this.exeEndTime);		
//		this.duration = this.exeEndTime.getTime() - this.exeStartTime.getTime(); // total duration
////		System.out.print(this.duration + ": ");
//	
//		// get the gap
//		calForFail.setTime(new Date(allTests.get(0).getLast_launchTime().getTime()));	// set the first test of the commit's time
//		calForFail.add(Calendar.MILLISECOND, (int)allTests.get(0).getLast_executionTime());		
//		this.maxEnd = new Timestamp(calForFail.getTime().getTime());
		
//		boolean reset = false;
		double resetedExeTime =0;
		this.curEnd = allTests.get(0).getLast_launchTime();
		for(TestSuite ts: allTests)
		{			
//			if(id == 330)
//				System.out.println(ts.getLast_launchTime());
//			
			ts.setLast_launchTime(new Timestamp(this.curEnd.getTime()));  
//			System.out.print(ts.getChangeRequest() + "," + ts.getTsId() + ","+ ts.getLast_launchTime() + ", " + ts.getLast_executionTime() + ", ");
			tempEnd.setTime(new Date(ts.getLast_launchTime().getTime()));
			resetedExeTime = (double)(ts.getLast_executionTime()/commit_totalExeTime)*this.duration;
			ts.setResetExeTime((int)resetedExeTime);
			ts.setLast_executionTime((int)resetedExeTime);
			
			tempEnd.add(Calendar.MILLISECOND, (int)resetedExeTime);
			
			this.curEnd = new Timestamp(tempEnd.getTime().getTime());
			
			
			
//			System.out.println(ts.getResetExeTime() + ","+ts.getLast_launchTime() + "," + this.duration);
						
		}
		for(TestSuite ts: allTests)
		{
//			System.out.println(ts.getTestName() +","+ts.getChangeRequest() +","+ts.getLast_stage() +","+ts.getLast_status()
//			+","+ ts.getLast_launchTime() +","+ ts.getResetExeTime() +","+ ts.getSize() +","+ ts.getShardNumber()
//			+","+ ts.getRunNumber() +","+ts.getLanguage());
		
		}
	}
	
		
	//calculate the duration of the commit
	/*
	 * Previous
	 */
//	public void calculateDuration()
//	{
////		exeEndTime = lastTest.getLast_launchTime();
//		calForFail.setTime(new Date(lastTest.getLast_launchTime().getTime()));	// set the last test of the commit's time
//		calForFail.add(Calendar.MILLISECOND, (int)lastTest.getLast_executionTime());
//		this.exeEndTime =  new Timestamp(calForFail.getTime().getTime());
//		
////		System.out.println(exeStartTime + "; "+lastTest.getLast_launchTime() + ","+lastTest.getLast_executionTime() + this.exeEndTime);
//		
//		this.duration = this.exeEndTime.getTime() - this.exeStartTime.getTime();
////		System.out.println(this.duration);
////		System.out.println(exeStartTime + "; "+ getCommitArrivalTime("pres"));
//	}

	/*
	 * commit_arrival = C_lauchtime - Avg(Commit duration) * x(#of concurrent commits)
	 */
	public Timestamp commitArrivalTime() 
	{
//		double day=0;
		calForFailArrive.setTime(new Date(exeStartTime.getTime())); // use original exe time as arrival time
//		if(selectedStage.equals("pres"))
//		{
////			day = 79188445*(double)numOfConcurrent*delta/(1000*60);
////			calForFailArrive.add(Calendar.MILLISECOND, -(int)(931796*(double)numOfConcurrent*delta));
////			calForFailArrive.add(Calendar.MILLISECOND, (int)(-931796*(double)0.5));
//			calForFailArrive.add(Calendar.MILLISECOND, (int)(-931796));
//		}
//		else
//		{
////			calForFailArrive.add(Calendar.MILLISECOND, -(int)(501852*(double)numOfConcurrent*delta));
////			calForFailArrive.add(Calendar.MILLISECOND, (int)(-501852*(double)0.5));
//			calForFailArrive.add(Calendar.MILLISECOND, (int)(-501852));
//		}
		
		this.commitArrivalTime =  new Timestamp(calForFailArrive.getTime().getTime());
//		System.out.println(numOfConcurrent + ":" + delta);
//		System.out.println(exeStartTime + "; " + commitArrivalTime + "; " + (int)(79188445*(double)numOfConcurrent*delta) + "; "+ (int)day);
		
		return this.commitArrivalTime;
	}
	
//	public Timestamp commitShiftEndTime()
//	{
//		calForFailEnd.setTime(new Date(commitArrivalTime.getTime()));
//		calForFailEnd.add(Calendar.MILLISECOND, (int)duration);
//		
//		Timestamp commitShiftEndTime = new Timestamp(calForFailEnd.getTime().getTime());
//		return commitShiftEndTime;
//	}
//	
//	/*
//	 * For newly updated storeCommits and SimulateCommitsExecution class
//	 */
//	public void updateInofo(TestSuite ts, String selectedStage, ExeRecord exeRec, int deltaFail, int deltaExe, int previousExeCommitNum)
//	{
//		if(exeRec.getIsExecuted()[ts.getTsId()] == false)
//		{	
//			numTsSatisfy_exe++;	
////			notExe.add(ts);
//		}
//		//for execution selection
//		else 
//		{
//			if(previousExeCommitNum - exeRec.getCommitsSinceLastExe()[ts.getTsId()]-1 >= deltaExe )
//			{
//				numTsSatisfy_exe++;
////				notExe.add(ts);
//			}
//			
//			if (exeRec.getIsFail()[ts.getTsId()] && previousExeCommitNum - exeRec.getCommitsSinceLastFail()[ts.getTsId()] - 1<= deltaFail)
////			if (exeRec.getTimesSinceLastFail()[ts.getTsId()]>=0 )
//			{			
//				numTsSatisfy_fail ++;		
////				fail.add(ts);
//			}
//		}
////		else
////			notFail.add(ts);
//	}
//		
	
	
// use this method to set the concurrentNum
	public void addConcurrentNum() 
	{
		this.concurrentNum ++;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public int getS() {
		return s;
	}

	public void setS(int s) {
		this.s = s;
	}

	public long getsExe() {
		return sExe;
	}

	public void setsExe(long sExe) {
		this.sExe = sExe;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public long getmExe() {
		return mExe;
	}
	public void setmExe(long mExe) {
		this.mExe = mExe;
	}

	public int getL() {
		return l;
	}


	public void setL(int l) {
		this.l = l;
	}


	public long getlExe() {
		return lExe;
	}

	public void setlExe(long lExe) {
		this.lExe = lExe;
	}


	public int getTotal() {
		return total;
	}


	public void setTotal(int total) {
		this.total = total;
	}


	public long getTotalExe() {
		return totalExe;
	}

	public void setTotalExe(long totalExe) {
		this.totalExe = totalExe;
	}
	public Map<Integer, int[]> getMap() {
		return map;
	}
	public void setMap(Map<Integer, int[]> map) {
		this.map = map;
	}

//	public boolean isFailCommit() {
//		return isFailCommit;
//	}
//
//	public void setFailCommit(boolean isFailCommit) {
//		this.isFailCommit = isFailCommit;
//	}

	public boolean isHasSmall() {
		return hasSmall;
	}

	public void setHasSmall(boolean hasSmall) {
		this.hasSmall = hasSmall;
	}

	public boolean isHasMedium() {
		return hasMedium;
	}

	public void setHasMedium(boolean hasMedium) {
		this.hasMedium = hasMedium;
	}

	public boolean isHasLarge() {
		return hasLarge;
	}

	public void setHasLarge(boolean hasLarge) {
		this.hasLarge = hasLarge;
	}

	public Map<Integer, String> getFailTestLanguage() {
		return failTestLanguage;
	}

	public void setFailTestLanguage(Map<Integer, String> failTestLanguage) {
		this.failTestLanguage = failTestLanguage;
	}
	public List<TestSuite> getAllTests_small() {
		return allTests_small;
	}

	public void setAllTests_small(List<TestSuite> allTests_small) {
		this.allTests_small = allTests_small;
	}

	public List<TestSuite> getAllTests_medium() {
		return allTests_medium;
	}

	public void setAllTests_medium(List<TestSuite> allTests_medium) {
		this.allTests_medium = allTests_medium;
	}

	public List<TestSuite> getAllTests_large() {
		return allTests_large;
	}

	public void setAllTests_large(List<TestSuite> allTests_large) {
		this.allTests_large = allTests_large;
	}

	public List<TestSuite> getFail() {
		return fail;
	}

	public void setFail(List<TestSuite> fail) {
		this.fail = fail;
	}

	public List<TestSuite> getAllTests() {
		return allTests;
	}

	public void setAllTests(List<TestSuite> allTests) {
		this.allTests = allTests;
	}

	public boolean isCheckFail() {
		return checkFail;
	}

	public void setCheckFail(boolean checkFail) {
		this.checkFail = checkFail;
	}

	public int getNumTsSatisfy_fail() {
		return numTsSatisfy_fail;
	}

	public void setNumTsSatisfy_fail(int numTsSatisfy_fail) {
		this.numTsSatisfy_fail = numTsSatisfy_fail;
	}

	public int getNumTsSatisfy_exe() {
		return numTsSatisfy_exe;
	}

	public void setNumTsSatisfy_exe(int numTsSatisfy_exe) {
		this.numTsSatisfy_exe = numTsSatisfy_exe;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}

	public double getFailRatio() 
	{
		this.failRatio = (double)numTsSatisfy_fail/(double)totalNum;
		
		return failRatio;
	}

	public double getExeRatio() 
	{
		this.exeRatio = (double)numTsSatisfy_exe/(double)totalNum;
		
		return exeRatio;
	}

	public double getRatio_fail() 
	{
		this.ratio_fail = (double)failNumber/(double)totalNum;
		return ratio_fail;
	}

//	public double getPercentStartTime() {
//		return percentStartTime;
//	}
//
//	public void setPercentStartTime(double percentStartTime) {
//		this.percentStartTime = percentStartTime;
//	}
	public double getCommit_totalExeTime() {
		return commit_totalExeTime;
	}
	public void setCommit_totalExeTime(double commit_totalExeTime) {
		this.commit_totalExeTime = commit_totalExeTime;
	}

	public Timestamp getExeStartTime() {
		return exeStartTime;
	}

	public void setExeStartTime(Timestamp exeStartTime) {
		this.exeStartTime = exeStartTime;
	}

	public Timestamp getExeEndTime() {
		return exeEndTime;
	}

	public void setExeEndTime(Timestamp exeEndTime) {
		this.exeEndTime = exeEndTime;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public int getNumOfConcurrent() {
		return numOfConcurrent;
	}

	public String getSelectedStage() {
		return selectedStage;
	}

	public void setSelectedStage(String selectedStage) {
		this.selectedStage = selectedStage;
	}

//	public double getDelta() {
//		return delta;
//	}
//
//	public void setDelta(double delta) {
//		this.delta = delta;
//	}

	public Timestamp getCommitArrivalTime() {
		return commitArrivalTime;
	}

	public void setCommitArrivalTime(Timestamp commitArrivalTime) {
		this.commitArrivalTime = commitArrivalTime;
	}

	public int getFailNumber() {
		return failNumber;
	}

	public void setFailNumber(int failNumber) {
		this.failNumber = failNumber;
	}

	public double getCommitEnterQueueTime() {
		return commitEnterQueueTime;
	}

	public void setCommitEnterQueueTime(double commitEnterQueueTime) {
		this.commitEnterQueueTime = commitEnterQueueTime;
	}

//	public long getCommitEnterQueueTime() {
//		return commitEnterQueueTime;
//	}
//
//	public void setCommitEnterQueueTime(long commitEnterQueueTime) {
//		this.commitEnterQueueTime = commitEnterQueueTime;
//	}
	
	
}
