package executeTS;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class GetStartTime 
{
	public Timestamp window_Google(Timestamp launchTime, int setTime, String mmhh)
	{
		Date time = new Date(launchTime.getTime());
		Calendar calForFail = Calendar.getInstance();
		calForFail.setTime(time);
		calForFail.set(Calendar.YEAR, 2014);
		if(mmhh.equals("hours"))
		{
			calForFail.add(Calendar.HOUR, -setTime); 	
		}
		else if(mmhh.equals("minutes"))
		{
			calForFail.add(Calendar.MINUTE, -setTime); 	
		}					
		time = calForFail.getTime();					
		Timestamp startTime = new Timestamp(time.getTime());	
		
		return startTime;
	}
	
	public Timestamp window_Travis(Timestamp Ts_start_time, int setTime, String mmhh)
	{
		
		Calendar calForFail = Calendar.getInstance();
		calForFail.setTime(new Date(Ts_start_time.getTime()));	
		if(mmhh.equals("hours"))
		{
			calForFail.add(Calendar.HOUR, -setTime); 
			
//			System.out.println(setTime);
//			System.out.println(Ts_start_time+" VS " );
		}
		else if(mmhh.equals("minutes"))
		{
			calForFail.add(Calendar.MINUTE, -setTime);	
		}													
		Timestamp startTime =  new Timestamp(calForFail.getTime().getTime());	
//		System.out.println(startTime);
		
		return startTime;
	}
	
}
